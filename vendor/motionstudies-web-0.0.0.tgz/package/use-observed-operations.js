import { useEffect, useState } from 'react';
/** Poll after each response settles, retaining only the current source's data. */
export function useObservedOperations(endpoint, enabled, refreshMilliseconds = 30_000) {
    if (!Number.isFinite(refreshMilliseconds) || refreshMilliseconds <= 0) {
        throw new Error('Observation refresh interval must be positive');
    }
    const [stored, setStored] = useState({ endpoint, loading: false, error: false });
    const state = stored.endpoint === endpoint ? stored : { endpoint, loading: false, error: false };
    if (stored.endpoint !== endpoint)
        setStored(state);
    useEffect(() => {
        if (!enabled)
            return;
        const controller = new AbortController();
        let refresh;
        function update(patch) {
            if (!controller.signal.aborted) {
                setStored((current) => current.endpoint === endpoint ? { ...current, ...patch } : current);
            }
        }
        const load = async () => {
            update({ loading: true });
            try {
                const response = await fetch(endpoint, { cache: 'no-store', signal: controller.signal });
                if (!response.ok)
                    throw new Error(`Observed operations returned ${response.status}`);
                const snapshot = await response.json();
                update({ snapshot, error: false });
            }
            catch {
                update({ error: true });
            }
            finally {
                update({ loading: false });
                if (!controller.signal.aborted)
                    refresh = window.setTimeout(() => void load(), refreshMilliseconds);
            }
        };
        void load();
        return () => {
            controller.abort();
            window.clearTimeout(refresh);
        };
    }, [enabled, endpoint, refreshMilliseconds]);
    return { snapshot: state.snapshot, loading: enabled && state.loading, error: state.error };
}
