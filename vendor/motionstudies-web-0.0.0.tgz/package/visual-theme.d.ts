import type { VisualTheme } from '@motionstudies/core/theme';
export declare function applyVisualTheme(theme: VisualTheme, root?: HTMLElement): void;
