import { type ReactNode } from 'react';
import type { MotionStudyEdition } from '@motionstudies/core/edition';
export declare function mountMotionStudy(edition: MotionStudyEdition, application: ReactNode): void;
