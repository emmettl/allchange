/** The consumer supplies its asset root; packages do not own deployment paths. */
export function createDataUrlResolver(dataRoot) {
    const root = dataRoot.endsWith('/') ? dataRoot : `${dataRoot}/`;
    return (fileName) => `${root}${fileName}`;
}
