import { useMemo } from 'react';
import { adjacentRoadChunks, roadChunkForTime, roadSnapshotForChunk, } from '@motionstudies/core/domain/road-day';
import { useProgressiveChunks } from './use-progressive-chunks.js';
const adapter = {
    chunkForTime: roadChunkForTime,
    adjacentChunks: adjacentRoadChunks,
    readChunk: (response) => response.json(),
    optional: true,
};
export function useProgressiveRoadStudy(manifestFile, active, time, resolveAssetUrl) {
    const { chunk, ...state } = useProgressiveChunks(manifestFile, active, time, resolveAssetUrl, adapter);
    const snapshot = useMemo(() => state.manifest ? roadSnapshotForChunk(state.manifest, chunk) : undefined, [state.manifest, chunk]);
    return { ...state, snapshot };
}
