import type { DataUrlResolver } from './data-url.ts';
interface ChunkDescriptor {
    readonly id: string;
    readonly path: string;
}
interface ChunkManifest<Descriptor extends ChunkDescriptor> {
    readonly chunks: readonly Descriptor[];
}
export interface ProgressiveChunkAdapter<Manifest, Descriptor, Chunk> {
    readonly chunkForTime: (manifest: Manifest, time: number) => Descriptor;
    readonly adjacentChunks: (manifest: Manifest, current: Descriptor) => readonly Descriptor[];
    readonly readChunk: (response: Response, descriptor: Descriptor) => Promise<Chunk>;
    readonly optional?: boolean;
}
/** Internal lifecycle shared by the network, aircraft and road loaders. */
export declare function useProgressiveChunks<Descriptor extends ChunkDescriptor, Manifest extends ChunkManifest<Descriptor>, Chunk>(manifestFile: string, active: boolean, time: number, resolveAssetUrl: DataUrlResolver, adapter: ProgressiveChunkAdapter<Manifest, Descriptor, Chunk>): {
    manifest: Manifest | undefined;
    chunk: Chunk | undefined;
    chunkReady: boolean;
    loading: boolean;
    unavailable: boolean;
    error: boolean;
};
export {};
