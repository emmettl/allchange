import { jsx as _jsx } from "react/jsx-runtime";
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { applyVisualTheme } from './visual-theme.js';
export function mountMotionStudy(edition, application) {
    const root = document.getElementById('root');
    if (!root)
        throw new Error('Motion Studies entry point requires #root');
    document.documentElement.classList.add('motion-study');
    document.documentElement.dataset.edition = edition.id;
    applyVisualTheme(edition.theme);
    createRoot(root).render(_jsx(StrictMode, { children: application }));
}
