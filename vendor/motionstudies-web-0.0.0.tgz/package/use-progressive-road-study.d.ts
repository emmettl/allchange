import { type NationalRoadStudyManifest } from '@motionstudies/core/domain/road-day';
import type { DataUrlResolver } from './data-url.ts';
export declare function useProgressiveRoadStudy(manifestFile: string, active: boolean, time: number, resolveAssetUrl: DataUrlResolver): {
    manifest: NationalRoadStudyManifest | undefined;
    chunkReady: boolean;
    loading: boolean;
    unavailable: boolean;
    error: boolean;
    snapshot: import("@motionstudies/core/domain/road-day").NationalRoadStudySnapshot | undefined;
};
