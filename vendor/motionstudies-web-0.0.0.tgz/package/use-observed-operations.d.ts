import type { TransitOperationsSnapshot } from '@motionstudies/core/domain/operations';
export interface ObservedOperationsState {
    readonly snapshot?: TransitOperationsSnapshot;
    readonly loading: boolean;
    readonly error: boolean;
}
/** Poll after each response settles, retaining only the current source's data. */
export declare function useObservedOperations(endpoint: string, enabled: boolean, refreshMilliseconds?: number): ObservedOperationsState;
