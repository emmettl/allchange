export type DataUrlResolver = (fileName: string) => string;
/** The consumer supplies its asset root; packages do not own deployment paths. */
export declare function createDataUrlResolver(dataRoot: string): DataUrlResolver;
