import type { NetworkDayChunk, NetworkDayChunkDescriptor, NetworkDayManifest } from '@motionstudies/core/domain/network';
import type { DataUrlResolver } from './data-url.ts';
export declare function verifiedNetworkDayChunk(response: Response, descriptor: NetworkDayChunkDescriptor): Promise<NetworkDayChunk>;
export declare function useProgressiveNetworkDay(manifestFile: string, active: boolean, time: number, resolveAssetUrl: DataUrlResolver): {
    manifest: NetworkDayManifest | undefined;
    chunkReady: boolean;
    loading: boolean;
    unavailable: boolean;
    error: boolean;
    network: import("@motionstudies/core/domain/network").NetworkSnapshot | undefined;
};
