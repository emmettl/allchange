import { type AirDayManifest } from '@motionstudies/core/domain/air-day';
import type { DataUrlResolver } from './data-url.ts';
export declare function useProgressiveAirDay(manifestFile: string, active: boolean, time: number, resolveAssetUrl: DataUrlResolver): {
    manifest: AirDayManifest | undefined;
    chunkReady: boolean;
    loading: boolean;
    unavailable: boolean;
    error: boolean;
    snapshot: import("@motionstudies/core/domain/air").AirSnapshot | undefined;
};
