export interface LocalPerformanceSample {
    readonly fps: number;
    readonly slowFramePercent: number;
}
export declare function useLocalPerformance(enabled: boolean): LocalPerformanceSample | undefined;
