import { type ReactNode } from 'react';
export interface MobilePickerOption {
    value: string;
    label: ReactNode;
    detail?: ReactNode;
}
export interface MobilePickerProps {
    ariaLabel: string;
    className?: string;
    menuPlacement?: 'down' | 'up';
    onChange: (value: string) => void;
    options: readonly MobilePickerOption[];
    triggerLabel?: ReactNode;
    value: string;
}
export declare function MobilePicker({ ariaLabel, className, menuPlacement, onChange, options, triggerLabel, value, }: MobilePickerProps): import("react").JSX.Element;
