import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useEffect, useId, useRef, useState, } from 'react';
export function MobilePicker({ ariaLabel, className = '', menuPlacement = 'down', onChange, options, triggerLabel, value, }) {
    const [open, setOpen] = useState(false);
    const rootRef = useRef(null);
    const triggerRef = useRef(null);
    const optionRefs = useRef([]);
    const initialFocusIndex = useRef(0);
    const menuId = useId();
    const selectedIndex = Math.max(0, options.findIndex((option) => option.value === value));
    const selectedOption = options[selectedIndex];
    useEffect(() => {
        if (!open)
            return;
        const handlePointerDown = (event) => {
            if (!rootRef.current?.contains(event.target))
                setOpen(false);
        };
        const handleFocusIn = (event) => {
            if (!rootRef.current?.contains(event.target))
                setOpen(false);
        };
        document.addEventListener('pointerdown', handlePointerDown);
        document.addEventListener('focusin', handleFocusIn);
        return () => {
            document.removeEventListener('pointerdown', handlePointerDown);
            document.removeEventListener('focusin', handleFocusIn);
        };
    }, [open]);
    useEffect(() => {
        if (open)
            optionRefs.current[initialFocusIndex.current]?.focus();
    }, [open]);
    const openAt = (index) => {
        initialFocusIndex.current = index;
        setOpen(true);
    };
    const closeAndRestoreFocus = () => {
        setOpen(false);
        triggerRef.current?.focus();
    };
    const handleTriggerKeyDown = (event) => {
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            openAt(selectedIndex);
        }
        else if (event.key === 'ArrowUp') {
            event.preventDefault();
            openAt(options.length - 1);
        }
        else if (event.key === 'Home') {
            event.preventDefault();
            openAt(0);
        }
        else if (event.key === 'End') {
            event.preventDefault();
            openAt(options.length - 1);
        }
    };
    const handleOptionKeyDown = (event, index) => {
        let nextIndex;
        if (event.key === 'ArrowDown')
            nextIndex = (index + 1) % options.length;
        else if (event.key === 'ArrowUp') {
            nextIndex = (index - 1 + options.length) % options.length;
        }
        else if (event.key === 'Home')
            nextIndex = 0;
        else if (event.key === 'End')
            nextIndex = options.length - 1;
        else if (event.key === 'Escape') {
            event.preventDefault();
            closeAndRestoreFocus();
            return;
        }
        if (nextIndex !== undefined) {
            event.preventDefault();
            optionRefs.current[nextIndex]?.focus();
        }
    };
    return (_jsxs("div", { ref: rootRef, className: `mobile-picker mobile-picker--${menuPlacement}${className ? ` ${className}` : ''}`, children: [_jsxs("button", { ref: triggerRef, className: "mobile-picker__trigger", type: "button", "aria-label": ariaLabel, disabled: options.length === 0, "aria-haspopup": "listbox", "aria-controls": menuId, "aria-expanded": open, onClick: () => {
                    if (open)
                        setOpen(false);
                    else
                        openAt(selectedIndex);
                }, onKeyDown: handleTriggerKeyDown, children: [_jsx("span", { children: triggerLabel ?? selectedOption?.label }), _jsx("i", { "aria-hidden": "true" })] }), open && (_jsx("div", { id: menuId, className: "mobile-picker__menu", role: "listbox", "aria-label": ariaLabel, children: options.map((option, index) => (_jsxs("button", { ref: (element) => {
                        optionRefs.current[index] = element;
                    }, type: "button", role: "option", "aria-selected": option.value === value, onClick: () => {
                        onChange(option.value);
                        closeAndRestoreFocus();
                    }, onKeyDown: (event) => handleOptionKeyDown(event, index), children: [_jsx("span", { children: option.label }), option.detail && _jsx("small", { children: option.detail })] }, option.value))) }))] }));
}
