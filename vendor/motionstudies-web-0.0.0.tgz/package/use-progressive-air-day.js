import { useMemo } from 'react';
import { adjacentAirDayChunks, airDayChunkForTime, airSnapshotForDayChunk, } from '@motionstudies/core/domain/air-day';
import { useProgressiveChunks } from './use-progressive-chunks.js';
const adapter = {
    chunkForTime: airDayChunkForTime,
    adjacentChunks: adjacentAirDayChunks,
    readChunk: (response) => response.json(),
};
export function useProgressiveAirDay(manifestFile, active, time, resolveAssetUrl) {
    const { chunk, ...state } = useProgressiveChunks(manifestFile, active, time, resolveAssetUrl, adapter);
    const snapshot = useMemo(() => state.manifest ? airSnapshotForDayChunk(state.manifest, chunk) : undefined, [state.manifest, chunk]);
    return { ...state, snapshot };
}
