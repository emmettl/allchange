export interface RecordingOptions {
    readonly duration: number;
    readonly fileNamePrefix?: string;
    readonly onSaving: () => void;
    readonly onComplete: () => void;
}
export interface CanvasRecording {
    readonly stop: () => void;
    readonly cancel: () => void;
}
export declare function recordCanvas(canvas: HTMLCanvasElement, options: RecordingOptions): CanvasRecording;
