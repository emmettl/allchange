import { foldSearchText } from './search-text.js';
const ROAD_TERMS = 'motorway autobahn autoroute autostrada autostrasse';
function searchText(road) {
    return foldSearchText(`${road.label} ${road.officialLabel} ${road.description ?? ''} ${ROAD_TERMS}`);
}
export function searchRoadCorridors(roads, query, maximum = 5) {
    const foldedQuery = foldSearchText(query);
    if (!foldedQuery)
        return [];
    return roads
        .filter((road) => searchText(road).includes(foldedQuery))
        .sort((first, second) => {
        const firstText = searchText(first);
        const secondText = searchText(second);
        return (Number(secondText.startsWith(foldedQuery)) -
            Number(firstText.startsWith(foldedQuery)) ||
            (second.stationCount ?? 0) - (first.stationCount ?? 0) ||
            first.id.localeCompare(second.id, 'en', { numeric: true }));
    })
        .slice(0, maximum);
}
export function roadCorridorSearchValue(road) {
    return road.description ? `${road.label} · ${road.description}` : road.label;
}
