export const SERVICE_CATEGORIES = [
    { id: 'international', label: 'International', color: '#ffd166' },
    { id: 'intercity', label: 'IC', color: '#ff4fd8' },
    { id: 'interregio', label: 'IR', color: '#9d7bff' },
    { id: 'regional-express', label: 'RE', color: '#4fc3ff' },
    { id: 's-bahn', label: 'S-Bahn', color: '#7dffbb' },
    { id: 'regional', label: 'Regional', color: '#fff3a6' },
    { id: 'tram', label: 'Tram', color: '#ff6ea9' },
    { id: 'metro', label: 'Metro', color: '#a78bfa' },
    { id: 'bus', label: 'Bus', color: '#ff9f43' },
    { id: 'ferry', label: 'Ferry', color: '#48c6ef' },
    { id: 'cableway', label: 'Cableway', color: '#d7ff70' },
    { id: 'funicular', label: 'Funicular', color: '#f8f38d' },
    { id: 'other', label: 'Other', color: '#b9c1da' },
];
export const SERVICE_COLORS = Object.fromEntries(SERVICE_CATEGORIES.map((category) => [category.id, category.color]));
