import type { ServiceCategory } from './domain/network.ts';
export interface VisualTheme {
    readonly background: string;
    readonly ink: string;
    readonly muted: string;
    readonly line: string;
    readonly primary: string;
    readonly secondary: string;
    readonly panel: string;
    readonly air: string;
    readonly roadLight: string;
    readonly roadHeavy: string;
}
export declare const SERVICE_CATEGORIES: ReadonlyArray<{
    readonly id: ServiceCategory;
    readonly label: string;
    readonly color: string;
}>;
export declare const SERVICE_COLORS: Readonly<Record<ServiceCategory, string>>;
