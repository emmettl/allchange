export declare function foldSearchText(value: string): string;
