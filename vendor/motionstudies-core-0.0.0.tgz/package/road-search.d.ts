export interface RoadSearchCorridor {
    readonly id: string;
    readonly label: string;
    readonly officialLabel: string;
    readonly description?: string;
    readonly focus: readonly [longitude: number, latitude: number];
    readonly cameraScale: number;
    readonly stationCount?: number;
}
export declare function searchRoadCorridors<Road extends RoadSearchCorridor>(roads: readonly Road[], query: string, maximum?: number): readonly Road[];
export declare function roadCorridorSearchValue(road: RoadSearchCorridor): string;
