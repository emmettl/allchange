export interface AirSearchTrack {
    readonly id: string;
    readonly icaoAddress?: string;
    readonly callsign: string;
    readonly start: number;
    readonly end: number;
    readonly airportIds?: readonly string[];
}
export declare function airTrackSearchText(track: AirSearchTrack): string;
export declare function airTrackSearchValue(track: AirSearchTrack): string;
export declare function searchAirTracks<Track extends AirSearchTrack>(tracks: readonly Track[], searchQuery: string, time: number, limit?: number): readonly Track[];
