import type { AirTrack } from './air.ts';
export interface StudyAirport {
    readonly id: string;
    readonly name: string;
    readonly city: string;
    readonly mapLabel?: string;
    readonly iata: string;
    readonly icao: string;
    readonly longitude: number;
    readonly latitude: number;
    readonly approachRadiusKilometres: number;
    readonly maximumApproachAltitudeFeet: number;
}
export declare function airportSearchText(airport: StudyAirport): string;
export declare function searchAirports(airports: readonly StudyAirport[], searchQuery: string, limit?: number): readonly StudyAirport[];
export declare function airTrackServesAirport(track: AirTrack, airport: StudyAirport): boolean;
export declare function airportAirTrackIds(tracks: readonly AirTrack[], airport: StudyAirport): ReadonlySet<string>;
