import type { AirSnapshot, AirTrack } from './air.ts';
export interface AirDayAircraft {
    readonly id: string;
    readonly icaoAddress: string;
    readonly callsign: string;
    readonly start: number;
    readonly end: number;
    readonly airportIds?: readonly string[];
    readonly chunkIds: readonly string[];
}
export interface AirDayChunkDescriptor {
    readonly id: string;
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly path: string;
    readonly trackCount: number;
    readonly sampleCount: number;
}
export interface AirDayChunk {
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly tracks: readonly AirTrack[];
}
export interface AirDayManifest {
    readonly metadata: AirSnapshot['metadata'];
    readonly bounds: AirSnapshot['bounds'];
    readonly trackCount: number;
    readonly sampleCount: number;
    readonly aircraft: readonly AirDayAircraft[];
    readonly chunks: readonly AirDayChunkDescriptor[];
}
export declare function airDayChunkForTime(manifest: AirDayManifest, time: number): AirDayChunkDescriptor;
export declare function adjacentAirDayChunks(manifest: AirDayManifest, current: AirDayChunkDescriptor): readonly AirDayChunkDescriptor[];
export declare function airSnapshotForDayChunk(manifest: AirDayManifest, chunk?: AirDayChunk): AirSnapshot;
