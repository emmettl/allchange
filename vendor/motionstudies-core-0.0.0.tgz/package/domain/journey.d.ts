export interface JourneyStop {
    readonly name: string;
    readonly progress: number;
    readonly departure: string;
}
export interface Journey {
    readonly id: string;
    readonly service: string;
    readonly destination: string;
    readonly operator: string;
    readonly speedKmh: number;
    readonly stops: readonly JourneyStop[];
}
export interface JourneyPosition {
    readonly previous: JourneyStop;
    readonly next: JourneyStop;
    readonly legProgress: number;
}
export declare function positionOnJourney(journey: Journey, progress: number): JourneyPosition;
