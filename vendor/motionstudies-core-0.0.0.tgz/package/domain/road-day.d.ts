import { type RoadTrafficConditions } from './road.ts';
export type NationalRoadSiteValue = readonly [
    siteIndex: number,
    lightFlowPerHour: number,
    lightSpeedKmh: number,
    heavyFlowPerHour: number,
    heavySpeedKmh: number
];
export interface NationalRoadSection {
    readonly id: string;
    readonly road: string;
    readonly direction: 'positive' | 'negative';
    readonly fromSiteIndex: number;
    readonly toSiteIndex: number;
    readonly distanceKm: number;
}
export interface NationalRoadMinuteChunk {
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly minutes: readonly (readonly [
        time: number,
        values: readonly NationalRoadSiteValue[]
    ])[];
}
export interface NationalRoadChunkDescriptor {
    readonly id: string;
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly path: string;
    readonly minuteCount: number;
    readonly valueCount: number;
}
export interface NationalRoadStudyManifest {
    readonly metadata: {
        readonly publisher: string;
        readonly serviceDate: string;
        readonly windowStart: number;
        readonly windowEnd: number;
        readonly sourceUrl: string;
        readonly measurementSiteTableVersion: number;
        readonly measurementKind: 'recorded';
        readonly model: string;
        readonly sampleIntervalSeconds: number;
        readonly acceptedSites: number;
        readonly sections: number;
        readonly minimumSiteCoverage: number;
        readonly firstMeasurementTime: string;
        readonly lastMeasurementTime: string;
        readonly completeMinutes: number;
    };
    readonly siteIds: readonly string[];
    readonly sections: readonly NationalRoadSection[];
    readonly chunks: readonly NationalRoadChunkDescriptor[];
}
export interface NationalRoadStudySnapshot {
    readonly metadata: NationalRoadStudyManifest['metadata'];
    readonly siteIds: readonly string[];
    readonly sections: readonly NationalRoadSection[];
    readonly minutes: NationalRoadMinuteChunk['minutes'];
}
export declare function roadChunkForTime(manifest: NationalRoadStudyManifest, time: number): NationalRoadChunkDescriptor;
export declare function adjacentRoadChunks(manifest: NationalRoadStudyManifest, current: NationalRoadChunkDescriptor): readonly NationalRoadChunkDescriptor[];
export declare function roadSnapshotForChunk(manifest: NationalRoadStudyManifest, chunk?: NationalRoadMinuteChunk): NationalRoadStudySnapshot;
export declare function nationalRoadConditionsAtTime(snapshot: NationalRoadStudySnapshot, siteIndex: number, time: number): RoadTrafficConditions;
export declare function reconstructedNationalVehicleCount(snapshot: NationalRoadStudySnapshot, time: number, road?: string): number;
