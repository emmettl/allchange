export function buildRouteIndex(snapshot) {
    const records = new Map();
    for (const train of snapshot.trains) {
        const id = `${train.category}:${train.route}`;
        const record = records.get(id) ?? {
            name: train.route,
            category: train.category,
            trainIds: new Set(),
            stopIndexes: new Set(),
            headsigns: new Set(),
        };
        record.trainIds.add(train.id);
        train.stops.forEach(([stopIndex]) => record.stopIndexes.add(stopIndex));
        if (train.headsign)
            record.headsigns.add(train.headsign);
        records.set(id, record);
    }
    return [...records.entries()]
        .map(([id, record]) => ({
        id,
        name: record.name,
        category: record.category,
        trainIds: [...record.trainIds],
        stopIndexes: [...record.stopIndexes],
        headsigns: [...record.headsigns].sort((first, second) => first.localeCompare(second, 'de-CH')),
    }))
        .sort((first, second) => first.category.localeCompare(second.category, 'en') ||
        first.name.localeCompare(second.name, 'de-CH', { numeric: true }));
}
export function buildStationIndex(snapshot) {
    const records = new Map();
    snapshot.stops.forEach((stop, index) => {
        const record = records.get(stop[2]) ?? {
            stopIndexes: [],
            trainIds: new Set(),
            routes: new Map(),
            labelRank: stop[5],
        };
        record.stopIndexes.push(index);
        if (stop[5] !== undefined) {
            record.labelRank = Math.min(record.labelRank ?? Number.POSITIVE_INFINITY, stop[5]);
        }
        records.set(stop[2], record);
    });
    for (const train of snapshot.trains) {
        const visitedNames = new Set();
        for (const [stopIndex] of train.stops) {
            const name = snapshot.stops[stopIndex]?.[2];
            if (!name || visitedNames.has(name))
                continue;
            visitedNames.add(name);
            const record = records.get(name);
            if (!record)
                continue;
            record.trainIds.add(train.id);
            record.routes.set(`${train.category}:${train.route}`, {
                name: train.route,
                category: train.category,
            });
        }
    }
    return [...records.entries()]
        .filter(([, record]) => record.trainIds.size > 0)
        .map(([name, record]) => ({
        name,
        labelRank: record.labelRank,
        stopIndexes: record.stopIndexes,
        trainIds: [...record.trainIds],
        routes: [...record.routes.values()].sort((first, second) => first.name.localeCompare(second.name, 'de-CH')),
    }));
}
export function positionForTrain(train, time) {
    if (train.realtime?.status === 'cancelled' ||
        time < train.start ||
        time > train.end ||
        train.stops.length < 2) {
        return undefined;
    }
    for (let index = 1; index < train.stops.length; index += 1) {
        const previous = train.stops[index - 1];
        const next = train.stops[index];
        if (time <= previous[2]) {
            return { fromStop: previous[0], toStop: previous[0], progress: 0 };
        }
        if (time <= next[1]) {
            const duration = Math.max(1, next[1] - previous[2]);
            return {
                fromStop: previous[0],
                toStop: next[0],
                progress: Math.min(1, Math.max(0, (time - previous[2]) / duration)),
                segmentIndex: index - 1,
            };
        }
        if (time <= next[2]) {
            return { fromStop: next[0], toStop: next[0], progress: 0 };
        }
    }
    const last = train.stops.at(-1);
    return { fromStop: last[0], toStop: last[0], progress: 0 };
}
export function formatServiceTime(totalSeconds) {
    const normalized = ((Math.round(totalSeconds) % 86400) + 86400) % 86400;
    const hours = Math.floor(normalized / 3600);
    const minutes = Math.floor((normalized % 3600) / 60);
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}
