export type RoadTrafficSample = readonly [
    time: number,
    lightFlowPerHour: number,
    lightSpeedKmh: number,
    heavyFlowPerHour: number,
    heavySpeedKmh: number
];
export interface RoadTrafficDirection {
    readonly id: string;
    readonly label: string;
    readonly reverse: boolean;
    readonly detectorIds: readonly string[];
    readonly samples: readonly RoadTrafficSample[];
}
export interface RoadTrafficCorridor {
    readonly id: string;
    readonly name: string;
    readonly road: string;
    readonly distanceKm: number;
    readonly path: readonly (readonly [longitude: number, latitude: number])[];
    readonly directions: readonly RoadTrafficDirection[];
}
export interface RoadTrafficSnapshot {
    readonly metadata: {
        readonly publisher: string;
        readonly serviceDate: string;
        readonly windowStart: number;
        readonly windowEnd: number;
        readonly sourceUrl: string;
        readonly measurementSiteUrl: string;
        readonly measurementSiteTableVersion: number;
        readonly measurementSitePublishedAt: string;
        readonly measurementKind: 'representative-calibration' | 'recorded';
        readonly model: string;
        readonly note: string;
        readonly sampleIntervalSeconds: number;
        readonly visualSampleRate: number;
        readonly recording?: {
            readonly firstMeasurementTime: string;
            readonly lastMeasurementTime: string;
            readonly completeMinutes: number;
            readonly minimumDirectionCoverage: number;
        };
    };
    readonly corridors: readonly RoadTrafficCorridor[];
}
export interface RoadTopologyPath {
    readonly id: string;
    readonly road: string;
    readonly axisName: string;
    readonly position: string;
    readonly mainline: boolean;
    readonly points: readonly (readonly [longitude: number, latitude: number])[];
}
export interface RoadTopologySite {
    readonly id: string;
    readonly stationId: string;
    readonly direction: 'positive' | 'negative';
    readonly detectorIds: readonly string[];
    readonly carriageways: readonly string[];
    readonly coordinate: readonly [longitude: number, latitude: number];
    readonly match: {
        readonly confidence: 'high' | 'continuity' | 'authoritative' | 'review' | 'unmatched';
        readonly method?: 'neighbouring-counters' | 'federal-tmc';
        readonly tmcLocationCodes?: readonly string[];
        readonly tmcLocationTableVersions?: readonly string[];
        readonly distanceMetres?: number;
        readonly road?: string;
        readonly axisName?: string;
        readonly axisPosition?: string;
        readonly segmentId?: string;
        readonly mainline?: boolean;
        readonly projectedCoordinate?: readonly [longitude: number, latitude: number];
        readonly competingRoad?: string;
        readonly competingDistanceMetres?: number;
    };
}
export interface RoadTopologyRoad {
    readonly id: string;
    readonly label: string;
    readonly officialLabel: string;
    readonly description?: string;
    readonly bounds: {
        readonly minLongitude: number;
        readonly maxLongitude: number;
        readonly minLatitude: number;
        readonly maxLatitude: number;
    };
    readonly focus: readonly [longitude: number, latitude: number];
    readonly cameraScale: number;
    readonly pathCount: number;
    readonly stationCount: number;
    readonly directionalSiteCount: number;
    readonly sectionCount: number;
}
export interface RoadTopologySection {
    readonly id: string;
    readonly road: string;
    readonly direction: 'positive' | 'negative';
    readonly fromSiteId: string;
    readonly toSiteId: string;
    readonly fromCoordinate: readonly [longitude: number, latitude: number];
    readonly toCoordinate: readonly [longitude: number, latitude: number];
    readonly path?: readonly (readonly [longitude: number, latitude: number])[];
    readonly distanceKm: number;
}
export interface RoadTopologySnapshot {
    readonly metadata: {
        readonly publisher: string;
        readonly sourceUrl: string;
        readonly sourceAsset: string;
        readonly sourceCrs: string;
        readonly sourceDate: string;
        readonly sourceUpdated: string;
        readonly measurementSiteUrl: string;
        readonly measurementSiteTableVersion: number;
        readonly measurementSitePublishedAt: string;
        readonly tmcLocationUrl?: string;
        readonly tmcLocationTableVersion?: string;
        readonly model: string;
        readonly coverage: {
            readonly federalStations: number;
            readonly federalDetectorRecords: number;
            readonly usableDirectionalGroups: number;
            readonly matchedDirectionalGroups: number;
            readonly highConfidenceDirectionalGroups: number;
            readonly continuityResolvedDirectionalGroups: number;
            readonly authoritativeResolvedDirectionalGroups: number;
            readonly reviewDirectionalGroups: number;
            readonly unmatchedDirectionalGroups: number;
            readonly matchedStations: number;
            readonly medianMatchDistanceMetres: number;
            readonly p95MatchDistanceMetres: number;
            readonly roads: number;
            readonly axisSegments: number;
        };
    };
    readonly roads: readonly RoadTopologyRoad[];
    readonly paths: readonly RoadTopologyPath[];
    readonly sections: readonly RoadTopologySection[];
    readonly sites: readonly RoadTopologySite[];
}
export interface RoadTrafficConditions {
    readonly lightFlowPerHour: number;
    readonly lightSpeedKmh: number;
    readonly heavyFlowPerHour: number;
    readonly heavySpeedKmh: number;
}
export declare function roadConditionsAtTime(direction: RoadTrafficDirection, time: number): RoadTrafficConditions;
export declare function trafficDensity(flowPerHour: number, speedKmh: number): number;
export declare function reconstructedVehicleCount(snapshot: RoadTrafficSnapshot, time: number): number;
export declare function visualVehicleCount(flowPerHour: number, speedKmh: number, distanceKm: number, sampleRate: number, maximum: number): number;
export declare function roadDistanceTravelledKm(direction: RoadTrafficDirection, time: number, vehicle: 'light' | 'heavy'): number;
