import type { NetworkSnapshot } from './network.ts';
export type RealtimeTripRelationship = 'scheduled' | 'cancelled' | 'deleted' | 'added';
export interface RealtimeStopUpdate {
    readonly stopPosition?: number;
    readonly stopId?: string;
    readonly stopSequence?: number;
    readonly scheduleRelationship?: 'scheduled' | 'skipped' | 'no-data';
    readonly arrivalDelay?: number;
    readonly departureDelay?: number;
}
export interface RealtimeTripUpdate {
    readonly tripId: string;
    readonly startDate?: string;
    readonly scheduleRelationship?: RealtimeTripRelationship;
    readonly delaySeconds?: number;
    readonly stopTimeUpdates?: readonly RealtimeStopUpdate[];
}
export interface RealtimeSnapshot {
    readonly metadata: {
        readonly kind: 'fixture' | 'live';
        readonly generatedAt: string;
        readonly receivedAt?: string;
        readonly staticFeedVersion: string;
        readonly serviceDate: string;
        readonly sourceUrl: string;
        readonly model: string;
    };
    readonly updates: readonly RealtimeTripUpdate[];
}
export interface RealtimeApplication {
    readonly network: NetworkSnapshot;
    readonly compatible: boolean;
    readonly reason?: 'feed-version' | 'service-date';
    readonly summary: {
        readonly adjusted: number;
        readonly cancelled: number;
        readonly skippedStops: number;
        readonly unmatched: number;
    };
}
export declare function applyRealtimeSnapshot(network: NetworkSnapshot, realtime: RealtimeSnapshot): RealtimeApplication;
