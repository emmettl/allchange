import { foldSearchText } from '../search-text.js';
export function airportSearchText(airport) {
    return foldSearchText(`${airport.name} ${airport.city} ${airport.mapLabel ?? ''} ${airport.iata} ${airport.icao}`);
}
function airportMatchRank(airport, query) {
    const codes = [airport.iata, airport.icao].map(foldSearchText);
    const name = foldSearchText(airport.name);
    if (codes.includes(query) || name === query)
        return 0;
    if (codes.some((code) => code.startsWith(query)) || name.startsWith(query)) {
        return 1;
    }
    return 2;
}
export function searchAirports(airports, searchQuery, limit = 5) {
    const query = foldSearchText(searchQuery);
    if (!query)
        return [];
    return airports
        .filter((airport) => airportSearchText(airport).includes(query))
        .sort((first, second) => airportMatchRank(first, query) - airportMatchRank(second, query) ||
        first.name.localeCompare(second.name, 'en'))
        .slice(0, limit);
}
function coordinateDistanceKilometres(firstLongitude, firstLatitude, secondLongitude, secondLatitude) {
    const averageLatitude = ((firstLatitude + secondLatitude) * Math.PI) / 360;
    const east = (secondLongitude - firstLongitude) * 111.32 * Math.cos(averageLatitude);
    const north = (secondLatitude - firstLatitude) * 111.32;
    return Math.hypot(east, north);
}
export function airTrackServesAirport(track, airport) {
    if (track.airportIds?.includes(airport.id))
        return true;
    return track.samples.some(([, longitude, latitude, altitudeFeet]) => altitudeFeet <= airport.maximumApproachAltitudeFeet &&
        coordinateDistanceKilometres(longitude, latitude, airport.longitude, airport.latitude) <= airport.approachRadiusKilometres);
}
export function airportAirTrackIds(tracks, airport) {
    return new Set(tracks
        .filter((track) => airTrackServesAirport(track, airport))
        .map((track) => track.id));
}
