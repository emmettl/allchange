import type { NetworkTrain } from './network.ts';
export interface TrainTimeIndex {
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly bucketSeconds: number;
    readonly buckets: readonly (readonly NetworkTrain[])[];
}
/**
 * Groups trips into coarse time buckets so a full-day renderer only examines
 * services near the current clock time. Padding keeps recent trail samples in
 * the candidate set around trip boundaries.
 */
export declare function buildTrainTimeIndex(trains: readonly NetworkTrain[], windowStart: number, windowEnd: number, paddingSeconds?: number, bucketSeconds?: number): TrainTimeIndex;
export declare function trainsNearTime(index: TrainTimeIndex, time: number): readonly NetworkTrain[];
