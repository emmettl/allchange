export interface ObservedStopPrediction {
    readonly stopId: string;
    readonly stopName: string;
    readonly platformName?: string;
    readonly expectedArrival: string;
    readonly secondsToStop: number;
}
export interface ObservedTransitVehicle {
    readonly id: string;
    readonly lineId: string;
    readonly lineName: string;
    readonly modeName?: string;
    readonly destinationStopId?: string;
    readonly destinationName?: string;
    readonly direction?: string;
    readonly currentLocation?: string;
    readonly towards?: string;
    readonly observedAt: string;
    readonly predictions: readonly ObservedStopPrediction[];
}
export interface ObservedLineStatus {
    readonly lineId: string;
    readonly lineName: string;
    readonly severity: number;
    readonly severityDescription: string;
    readonly reason?: string;
}
export interface TransitOperationsSnapshot {
    readonly metadata: {
        readonly kind: 'observed-operations';
        readonly publisher: string;
        readonly sourceUrl: string;
        readonly collectedAt: string;
        readonly scheduledAt: string;
        readonly lineIds: readonly string[];
        readonly model: string;
    };
    readonly vehicles: readonly ObservedTransitVehicle[];
    readonly lineStatuses: readonly ObservedLineStatus[];
}
export interface TransitOperationsDayFrame {
    readonly time: number;
    readonly observedAt: string;
    readonly vehicles: readonly ObservedTransitVehicle[];
    readonly lineStatuses: readonly ObservedLineStatus[];
}
export interface TransitOperationsDayChunk {
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly frames: readonly TransitOperationsDayFrame[];
}
export interface TransitOperationsDayChunkDescriptor {
    readonly id: string;
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly path: string;
    readonly frameCount: number;
    readonly bytes: number;
    readonly sha256: string;
}
export interface TransitOperationsDayManifest {
    readonly metadata: {
        readonly kind: 'observed-operations-day';
        readonly publisher: string;
        readonly serviceDate: string;
        readonly timezone: string;
        readonly sourceUrl: string;
        readonly model: string;
        readonly note: string;
        readonly sampleIntervalSeconds: number;
        readonly completeMinutes: number;
        readonly longestGapSeconds: number;
        readonly lineIds: readonly string[];
    };
    readonly chunks: readonly TransitOperationsDayChunkDescriptor[];
}
export interface ObservedNetworkProjection {
    readonly snapshot: import('./network.ts').NetworkSnapshot;
    readonly serviceTime: number;
    readonly matchedVehicleCount: number;
    readonly unmatchedVehicleCount: number;
}
export declare function operationsServiceTime(snapshot: TransitOperationsSnapshot, timeZone: string): number;
export declare function operationsAgeSeconds(snapshot: TransitOperationsSnapshot, now?: number): number;
export declare function projectOperationsOntoNetwork(reference: import('./network.ts').NetworkSnapshot, operations: TransitOperationsSnapshot, serviceTime: number): ObservedNetworkProjection;
