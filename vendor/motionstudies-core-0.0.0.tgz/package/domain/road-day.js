import { trafficDensity } from './road.js';
export function roadChunkForTime(manifest, time) {
    const last = manifest.chunks.at(-1);
    const match = manifest.chunks.find((chunk) => time >= chunk.windowStart &&
        (time < chunk.windowEnd || (chunk === last && time <= chunk.windowEnd)));
    return match ?? (time < manifest.metadata.windowStart ? manifest.chunks[0] : last);
}
export function adjacentRoadChunks(manifest, current) {
    const index = manifest.chunks.findIndex((chunk) => chunk.id === current.id);
    return manifest.chunks.slice(Math.max(0, index - 1), index + 2);
}
export function roadSnapshotForChunk(manifest, chunk) {
    return {
        metadata: manifest.metadata,
        siteIds: manifest.siteIds,
        sections: manifest.sections,
        minutes: chunk?.minutes ?? [],
    };
}
function valueConditions(value) {
    return value
        ? {
            lightFlowPerHour: value[1],
            lightSpeedKmh: value[2],
            heavyFlowPerHour: value[3],
            heavySpeedKmh: value[4],
        }
        : {
            lightFlowPerHour: 0,
            lightSpeedKmh: 0,
            heavyFlowPerHour: 0,
            heavySpeedKmh: 0,
        };
}
function interpolate(from, to, progress) {
    return from + (to - from) * progress;
}
export function nationalRoadConditionsAtTime(snapshot, siteIndex, time) {
    const minutes = snapshot.minutes;
    if (!minutes.length)
        return valueConditions();
    const conditionsAt = (minuteIndex) => valueConditions(minutes[minuteIndex][1].find((value) => value[0] === siteIndex));
    if (time <= minutes[0][0])
        return conditionsAt(0);
    if (time >= minutes.at(-1)[0])
        return conditionsAt(minutes.length - 1);
    let high = 1;
    while (high < minutes.length && minutes[high][0] < time)
        high += 1;
    const low = high - 1;
    const from = conditionsAt(low);
    const to = conditionsAt(high);
    const progress = (time - minutes[low][0]) / (minutes[high][0] - minutes[low][0]);
    return {
        lightFlowPerHour: interpolate(from.lightFlowPerHour, to.lightFlowPerHour, progress),
        lightSpeedKmh: interpolate(from.lightSpeedKmh, to.lightSpeedKmh, progress),
        heavyFlowPerHour: interpolate(from.heavyFlowPerHour, to.heavyFlowPerHour, progress),
        heavySpeedKmh: interpolate(from.heavySpeedKmh, to.heavySpeedKmh, progress),
    };
}
export function reconstructedNationalVehicleCount(snapshot, time, road) {
    return Math.round(snapshot.sections.reduce((total, section) => {
        if (road && section.road !== road)
            return total;
        const from = nationalRoadConditionsAtTime(snapshot, section.fromSiteIndex, time);
        const to = nationalRoadConditionsAtTime(snapshot, section.toSiteIndex, time);
        const lightFlow = (from.lightFlowPerHour + to.lightFlowPerHour) / 2;
        const lightSpeed = (from.lightSpeedKmh + to.lightSpeedKmh) / 2;
        const heavyFlow = (from.heavyFlowPerHour + to.heavyFlowPerHour) / 2;
        const heavySpeed = (from.heavySpeedKmh + to.heavySpeedKmh) / 2;
        return (total +
            (trafficDensity(lightFlow, lightSpeed) +
                trafficDensity(heavyFlow, heavySpeed)) *
                section.distanceKm);
    }, 0));
}
