export type NetworkStop = readonly [
    longitude: number,
    latitude: number,
    name: string,
    platformCode?: string,
    sourceId?: string,
    labelRank?: number
];
export type NetworkEdge = readonly [from: number, to: number];
export type NetworkPathPoint = readonly [longitude: number, latitude: number];
export type NetworkPath = readonly NetworkPathPoint[];
export type TrainStop = readonly [stopIndex: number, arrival: number, departure: number];
export type ServiceCategory = 'international' | 'intercity' | 'interregio' | 'regional-express' | 's-bahn' | 'regional' | 'tram' | 'metro' | 'bus' | 'ferry' | 'cableway' | 'funicular' | 'other';
export interface NetworkTrain {
    readonly id: string;
    readonly route: string;
    readonly headsign: string;
    readonly shortName: string;
    readonly category: ServiceCategory;
    readonly mode?: string;
    readonly servicePattern?: 'local' | 'express';
    readonly start: number;
    readonly end: number;
    readonly stops: readonly TrainStop[];
    readonly pathSegments?: readonly (number | null)[];
    readonly realtime?: RealtimeTrainState;
    readonly operations?: ObservedTrainState;
}
export interface ObservedTrainState {
    readonly kind: 'prediction-derived';
    readonly observedAt: string;
    readonly vehicleId: string;
}
export interface RealtimeTrainState {
    readonly status: 'adjusted' | 'cancelled';
    readonly delaySeconds: number;
    readonly skippedStops: number;
    readonly generatedAt: string;
}
export interface NetworkSnapshot {
    readonly metadata: {
        readonly publisher: string;
        readonly feedVersion: string;
        readonly serviceDate: string;
        readonly windowStart: number;
        readonly windowEnd: number;
        readonly focusTime: number;
        readonly sourceUrl: string;
        readonly sourceSha256?: string;
        readonly retrievedAt?: string;
        readonly license?: string;
        readonly licenseUrl?: string;
        readonly model: string;
        readonly note: string;
        readonly modes?: readonly string[];
        readonly labelHierarchy?: {
            readonly model: string;
            readonly stationCount: number;
        };
        readonly localAgencyIds?: readonly string[];
        readonly localRouteIds?: readonly string[];
        readonly servicePatternStudy?: {
            readonly model: string;
            readonly localTrips: number;
            readonly expressTrips: number;
            readonly passEvents: readonly ServicePatternPassEvent[];
        };
        readonly interchangeStudy?: {
            readonly model: string;
            readonly complexes: readonly InterchangeComplex[];
        };
        readonly geometry?: {
            readonly publisher: string;
            readonly feedVersion: string;
            readonly sourceUrl: string;
            readonly sourceSha256?: string;
            readonly productUrl?: string;
            readonly model: string;
            readonly matchedSegments: number;
            readonly totalSegments: number;
            readonly resolvedStops?: number;
            readonly totalStops?: number;
            readonly simplificationToleranceMetres?: number;
        };
    };
    readonly bounds: {
        readonly minLongitude: number;
        readonly minLatitude: number;
        readonly maxLongitude: number;
        readonly maxLatitude: number;
    };
    readonly stops: readonly NetworkStop[];
    readonly edges: readonly NetworkEdge[];
    readonly paths?: readonly NetworkPath[];
    readonly edgePaths?: readonly (number | null)[];
    readonly trains: readonly NetworkTrain[];
}
export interface InterchangeLink {
    readonly fromStopId: string;
    readonly toStopId: string;
    readonly minimumTransferSeconds: number;
}
export interface InterchangeComplex {
    readonly id: string;
    readonly name: string;
    readonly longitude: number;
    readonly latitude: number;
    readonly stopIds: readonly string[];
    readonly links: readonly InterchangeLink[];
}
export interface ServicePatternPassEvent {
    readonly id: string;
    readonly localTrainId: string;
    readonly expressTrainId: string;
    readonly fromStopId: string;
    readonly toStopId: string;
    readonly time: number;
    readonly startDeltaSeconds: number;
    readonly endDeltaSeconds: number;
}
export interface NetworkDayChunkDescriptor {
    readonly id: string;
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly path: string;
    readonly tripCount: number;
    readonly bytes?: number;
    readonly sha256?: string;
}
export interface NetworkDayManifest {
    readonly metadata: NetworkSnapshot['metadata'];
    readonly bounds: NetworkSnapshot['bounds'];
    readonly stops: NetworkSnapshot['stops'];
    readonly edges: NetworkSnapshot['edges'];
    readonly paths?: NetworkSnapshot['paths'];
    readonly edgePaths?: NetworkSnapshot['edgePaths'];
    readonly tripCount: number;
    readonly chunks: readonly NetworkDayChunkDescriptor[];
}
export interface NetworkDayChunk {
    readonly windowStart: number;
    readonly windowEnd: number;
    readonly trains: readonly NetworkTrain[];
}
export interface StationRoute {
    readonly name: string;
    readonly category: ServiceCategory;
}
export interface StationIndexEntry {
    readonly name: string;
    readonly labelRank?: number;
    readonly stopIndexes: readonly number[];
    readonly trainIds: readonly string[];
    readonly routes: readonly StationRoute[];
}
export interface NetworkRouteIndexEntry {
    readonly id: string;
    readonly name: string;
    readonly category: ServiceCategory;
    readonly trainIds: readonly string[];
    readonly stopIndexes: readonly number[];
    readonly headsigns: readonly string[];
}
export declare function buildRouteIndex(snapshot: NetworkSnapshot): readonly NetworkRouteIndexEntry[];
export declare function buildStationIndex(snapshot: NetworkSnapshot): readonly StationIndexEntry[];
export interface TrainPosition {
    readonly fromStop: number;
    readonly toStop: number;
    readonly progress: number;
    readonly segmentIndex?: number;
}
export declare function positionForTrain(train: NetworkTrain, time: number): TrainPosition | undefined;
export declare function formatServiceTime(totalSeconds: number): string;
