import type { NetworkDayChunk, NetworkDayChunkDescriptor, NetworkDayManifest, NetworkSnapshot } from './network.ts';
export declare function dayChunkForTime(manifest: NetworkDayManifest, time: number): NetworkDayChunkDescriptor;
export declare function adjacentDayChunks(manifest: NetworkDayManifest, current: NetworkDayChunkDescriptor): readonly NetworkDayChunkDescriptor[];
export declare function networkSnapshotForDayChunk(manifest: NetworkDayManifest, chunk?: NetworkDayChunk): NetworkSnapshot;
