import type { NetworkSnapshot } from './network.ts';
/**
 * Combines independently loaded data layers without changing their source IDs.
 * This is intentionally a runtime composition: each source artifact retains an
 * independent payload budget and can remain outside the opening request graph.
 */
export declare function mergeNetworkLayers(snapshots: readonly NetworkSnapshot[]): NetworkSnapshot;
