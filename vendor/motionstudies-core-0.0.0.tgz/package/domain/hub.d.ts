import type { NetworkSnapshot, NetworkStop, ServiceCategory } from './network.ts';
export interface HubDefinition<HubId extends string = string> {
    readonly id: HubId;
    readonly name: string;
    readonly aliases?: readonly string[];
    readonly displayName: string;
    readonly character: string;
}
export interface HubCall {
    readonly id: string;
    readonly train: {
        readonly id: string;
        readonly route: string;
        readonly headsign: string;
        readonly shortName: string;
        readonly category: ServiceCategory;
    };
    readonly arrival: number;
    readonly departure: number;
    readonly hubStop: NetworkStop;
    readonly previousStop?: NetworkStop;
    readonly nextStop?: NetworkStop;
}
export type HubFlowOrientation = 'radial' | 'orbital';
export type HubFlowLens = 'all' | HubFlowOrientation;
export interface HubFlowSummary {
    readonly all: number;
    readonly radial: number;
    readonly orbital: number;
}
export interface HubDaySnapshot<HubId extends string = string> {
    readonly metadata: NetworkSnapshot['metadata'];
    readonly hubs: Readonly<Record<HubId, readonly HubCall[]>>;
}
export declare const UNASSIGNED_PLATFORM = "\u2014";
export type StationMotionPhase = 'approaching' | 'dwelling' | 'departing';
export interface StationMotion {
    readonly phase: StationMotionPhase;
    readonly progress: number;
}
export declare function platformCodeForCall(call: HubCall): string;
export declare function platformTrackForCall(call: HubCall): string;
export declare function platformsForCalls(calls: readonly HubCall[]): readonly string[];
export declare function stationMotionForCall(call: HubCall, time: number, horizon?: number, cycle?: number): StationMotion | undefined;
export declare function callsAtHub(snapshot: NetworkSnapshot, hub: HubDefinition): readonly HubCall[];
export declare function callsNearTime(calls: readonly HubCall[], time: number, horizon?: number, cycle?: number): readonly HubCall[];
export declare function nextHubCall(calls: readonly HubCall[], time: number): HubCall | undefined;
/**
 * Classify a movement by comparing its local path through a hub with the line
 * from a study centre to that hub. The absolute dot product makes the result
 * independent of service direction: inbound and outbound calls share a lens.
 */
export declare function hubFlowOrientation(call: HubCall, centre: readonly [longitude: number, latitude: number], radialThreshold?: number): HubFlowOrientation;
export declare function callsForHubFlowLens(calls: readonly HubCall[], lens: HubFlowLens, centre: readonly [longitude: number, latitude: number]): readonly HubCall[];
export declare function hubFlowSummary(calls: readonly HubCall[], centre: readonly [longitude: number, latitude: number]): HubFlowSummary;
/** A soft day/night envelope with transitions around 22:00 and 06:30. */
export declare function hubNightSignalMix(time: number): number;
