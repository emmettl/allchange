export type AirSample = readonly [
    time: number,
    longitude: number,
    latitude: number,
    altitudeFeet: number,
    groundSpeedKnots: number
];
export interface AirTrack {
    readonly id: string;
    readonly icaoAddress?: string;
    readonly callsign: string;
    readonly start: number;
    readonly end: number;
    readonly airportIds?: readonly string[];
    readonly samples: readonly AirSample[];
}
export interface AirSnapshot {
    readonly metadata: {
        readonly publisher: string;
        readonly serviceDate: string;
        readonly windowStart: number;
        readonly windowEnd: number;
        readonly sourceUrl: string;
        readonly license: string;
        readonly licenseUrl: string;
        readonly model: string;
        readonly note: string;
        readonly sampleIntervalSeconds: number;
    };
    readonly bounds: {
        readonly minLongitude: number;
        readonly minLatitude: number;
        readonly maxLongitude: number;
        readonly maxLatitude: number;
    };
    readonly tracks: readonly AirTrack[];
}
export interface AirPosition {
    readonly longitude: number;
    readonly latitude: number;
    readonly altitudeFeet: number;
    readonly groundSpeedKnots: number;
    readonly headingDegrees: number;
    readonly verticalRateFeetPerMinute: number;
}
export declare function headingBetweenSamples(from: AirSample, to: AirSample): number;
export declare function positionForAirTrack(track: AirTrack, time: number): AirPosition | undefined;
export declare function activeAirTracks(snapshot: AirSnapshot, time: number): readonly AirTrack[];
