export function spatialLayoutCoverage(network, layout) {
    const layoutStopIds = new Set(layout.stops.map(([sourceId]) => sourceId));
    const matchedStops = network.stops.reduce((count, stop) => count + Number(Boolean(stop[4] && layoutStopIds.has(stop[4]))), 0);
    const totalPaths = network.paths?.length ?? 0;
    const matchedPaths = Math.min(totalPaths, layout.paths.filter((path) => path.length >= 2).length);
    return {
        matchedStops,
        totalStops: network.stops.length,
        matchedPaths,
        totalPaths,
    };
}
