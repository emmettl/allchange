function interpolate(from, to, progress) {
    return from + (to - from) * progress;
}
export function roadConditionsAtTime(direction, time) {
    const samples = direction.samples;
    if (!samples.length) {
        return {
            lightFlowPerHour: 0,
            lightSpeedKmh: 0,
            heavyFlowPerHour: 0,
            heavySpeedKmh: 0,
        };
    }
    if (time <= samples[0][0]) {
        const [, lightFlowPerHour, lightSpeedKmh, heavyFlowPerHour, heavySpeedKmh] = samples[0];
        return { lightFlowPerHour, lightSpeedKmh, heavyFlowPerHour, heavySpeedKmh };
    }
    if (time >= samples[samples.length - 1][0]) {
        const [, lightFlowPerHour, lightSpeedKmh, heavyFlowPerHour, heavySpeedKmh] = samples[samples.length - 1];
        return { lightFlowPerHour, lightSpeedKmh, heavyFlowPerHour, heavySpeedKmh };
    }
    let low = 1;
    let high = samples.length - 1;
    while (low < high) {
        const middle = Math.floor((low + high) / 2);
        if (samples[middle][0] < time)
            low = middle + 1;
        else
            high = middle;
    }
    const from = samples[low - 1];
    const to = samples[low];
    const progress = (time - from[0]) / (to[0] - from[0]);
    return {
        lightFlowPerHour: interpolate(from[1], to[1], progress),
        lightSpeedKmh: interpolate(from[2], to[2], progress),
        heavyFlowPerHour: interpolate(from[3], to[3], progress),
        heavySpeedKmh: interpolate(from[4], to[4], progress),
    };
}
export function trafficDensity(flowPerHour, speedKmh) {
    return speedKmh > 0 ? Math.max(0, flowPerHour) / speedKmh : 0;
}
export function reconstructedVehicleCount(snapshot, time) {
    return Math.round(snapshot.corridors.reduce((total, corridor) => total +
        corridor.directions.reduce((directionTotal, direction) => {
            const conditions = roadConditionsAtTime(direction, time);
            return (directionTotal +
                (trafficDensity(conditions.lightFlowPerHour, conditions.lightSpeedKmh) +
                    trafficDensity(conditions.heavyFlowPerHour, conditions.heavySpeedKmh)) *
                    corridor.distanceKm);
        }, 0), 0));
}
export function visualVehicleCount(flowPerHour, speedKmh, distanceKm, sampleRate, maximum) {
    return Math.min(maximum, Math.max(0, Math.round(trafficDensity(flowPerHour, speedKmh) * distanceKm * sampleRate)));
}
export function roadDistanceTravelledKm(direction, time, vehicle) {
    const samples = direction.samples;
    if (samples.length < 2 || time <= samples[0][0])
        return 0;
    const speedIndex = vehicle === 'light' ? 2 : 4;
    const limit = Math.min(time, samples[samples.length - 1][0]);
    let distance = 0;
    for (let index = 1; index < samples.length; index += 1) {
        const from = samples[index - 1];
        const to = samples[index];
        if (from[0] >= limit)
            break;
        const segmentEnd = Math.min(limit, to[0]);
        const duration = segmentEnd - from[0];
        const progress = duration / (to[0] - from[0]);
        const endSpeed = interpolate(from[speedIndex], to[speedIndex], progress);
        distance += ((from[speedIndex] + endSpeed) / 2) * (duration / 3600);
        if (segmentEnd === limit)
            break;
    }
    return distance;
}
