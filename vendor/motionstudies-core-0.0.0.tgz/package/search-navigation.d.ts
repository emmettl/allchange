export type SearchNavigationKey = 'ArrowDown' | 'ArrowUp' | 'Home' | 'End';
export declare function nextSearchResultIndex(currentIndex: number, resultCount: number, key: SearchNavigationKey): number;
