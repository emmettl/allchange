import { type HubCall, type HubDefinition } from '@motionstudies/core/domain/hub';
import { type NetworkSnapshot, type ServiceCategory } from '@motionstudies/core/domain/network';
interface StationFlowSceneProps {
    readonly timeline: NetworkSnapshot['metadata'];
    readonly hub: HubDefinition;
    readonly calls: readonly HubCall[];
    readonly isPlaying: boolean;
    readonly time: number;
    /** Reports the scene clock while playing; paused scenes follow `time` without emitting. */
    readonly onTime: (time: number) => void;
    readonly playbackRate: number;
    readonly selectedCategory?: ServiceCategory;
    readonly platformPrefix: string;
}
export declare function StationFlowScene(props: StationFlowSceneProps): import("react").JSX.Element;
export {};
