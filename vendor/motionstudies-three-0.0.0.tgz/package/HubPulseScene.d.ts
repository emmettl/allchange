import type { HubCall, HubDefinition } from '@motionstudies/core/domain/hub';
import { type NetworkSnapshot, type ServiceCategory } from '@motionstudies/core/domain/network';
interface HubPulseSceneProps {
    readonly timeline: NetworkSnapshot['metadata'];
    readonly hub: HubDefinition;
    readonly calls: readonly HubCall[];
    readonly isPlaying: boolean;
    readonly time: number;
    /** Reports the scene clock while playing; paused scenes follow `time` without emitting. */
    readonly onTime: (time: number) => void;
    readonly playbackRate: number;
    readonly selectedCategory?: ServiceCategory;
    readonly showTaktOverlay: boolean;
    readonly nightMix?: number;
}
export declare function HubPulseScene(props: HubPulseSceneProps): import("react").JSX.Element;
export {};
