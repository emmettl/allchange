import type { NetworkSnapshot } from '@motionstudies/core/domain/network';
export interface EdgeTrafficWeights {
    readonly counts: readonly number[];
    readonly strengths: readonly number[];
    readonly referenceCount: number;
}
export declare function edgeTrafficWeights(snapshot: NetworkSnapshot): EdgeTrafficWeights;
