import type { ServiceCategory } from '@motionstudies/core/domain/network';
import { type MapCameraFraming } from './map-camera.ts';
export declare function regionalCameraHeight(cameraHeight: number, framing: MapCameraFraming): number;
export declare function vehicleIsVisibleAtZoom(category: ServiceCategory, cameraHeight: number, framing: MapCameraFraming, focused?: boolean): boolean;
export declare function localNetworkDetailAtZoom(cameraHeight: number, framing: MapCameraFraming): number;
