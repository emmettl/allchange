export const MAX_TRAIN_LABELS = 56;
export const TRAIN_LABEL_ARRIVAL_FADE_SECONDS = 1.6;
export function trainLabelIdentity(route, shortName) {
    const routeLabel = route.trim();
    const serviceLabel = shortName.trim();
    if (!routeLabel)
        return serviceLabel;
    if (!serviceLabel)
        return routeLabel;
    if (routeLabel.localeCompare(serviceLabel, undefined, {
        sensitivity: 'accent',
    }) === 0) {
        return routeLabel;
    }
    return `${routeLabel} · ${serviceLabel}`;
}
export function nonRailCategorySuppressesTrainLabels(airCategorySelected = false, roadCategorySelected = false) {
    return airCategorySelected || roadCategorySelected;
}
export function trainLabelArrivalOpacity(time, end, playbackRate) {
    if (time <= end)
        return 1;
    const timetableFadeSeconds = TRAIN_LABEL_ARRIVAL_FADE_SECONDS * Math.max(1, playbackRate);
    return Math.max(0, 1 - (time - end) / timetableFadeSeconds);
}
export function trainLabelScreenHeight(viewportWidth, selected, cameraHeight) {
    if (viewportWidth <= 600) {
        const overviewProgress = Math.min(1, Math.max(0, (cameraHeight - 18) / 12));
        const closeHeight = selected ? 52 : 44;
        return closeHeight - overviewProgress * 20;
    }
    return selected ? 46 : 38;
}
export function trainLabelScreenWidth(label, screenHeight) {
    return Math.min(screenHeight * 9, Math.max(screenHeight * 2.4, screenHeight * (1.2 + label.length * 0.2)));
}
const CATEGORY_PRIORITY = {
    international: 0,
    intercity: 1,
    interregio: 2,
    'regional-express': 3,
    's-bahn': 4,
    regional: 5,
    tram: 6,
    metro: 7,
    bus: 8,
    ferry: 9,
    funicular: 10,
    cableway: 11,
    other: 12,
};
export function trainLabelBudget(cameraHeight, mode) {
    if (mode === 'off')
        return 0;
    if (mode === 'on') {
        if (cameraHeight >= 30)
            return 18;
        if (cameraHeight >= 22)
            return 32;
        return MAX_TRAIN_LABELS;
    }
    if (cameraHeight >= 30)
        return 8;
    if (cameraHeight >= 22)
        return 16;
    return 32;
}
export function trainLabelPriority(category) {
    return CATEGORY_PRIORITY[category];
}
export function compareTrainLabelCandidates(first, second) {
    return (trainLabelPriority(first.category) - trainLabelPriority(second.category) ||
        Number(second.retained) - Number(first.retained) ||
        first.id.localeCompare(second.id, 'de-CH', { numeric: true }));
}
export function categoryIsVisibleInAutoMode(category, cameraHeight) {
    const priority = CATEGORY_PRIORITY[category];
    if (cameraHeight >= 30)
        return priority <= CATEGORY_PRIORITY.intercity;
    if (cameraHeight >= 22)
        return priority <= CATEGORY_PRIORITY['regional-express'];
    return true;
}
