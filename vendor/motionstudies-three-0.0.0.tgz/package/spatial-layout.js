import { pointAlongProjectedPath, prepareProjectedPath, } from './network-paths.js';
function layoutProjection(layout, targetWidth) {
    const width = Math.max(0.000001, layout.bounds.maxX - layout.bounds.minX);
    const centreX = (layout.bounds.minX + layout.bounds.maxX) / 2;
    const centreY = (layout.bounds.minY + layout.bounds.maxY) / 2;
    const scale = targetWidth / width;
    return ([x, y]) => [
        (x - centreX) * scale,
        0,
        -(y - centreY) * scale,
    ];
}
export function projectSpatialLayout(network, layout, geographicStops, geographicPaths, targetWidth = 51) {
    const project = layoutProjection(layout, targetWidth);
    const stopBySourceId = new Map(layout.stops.map(([sourceId, x, y]) => [
        sourceId,
        project([x, y]),
    ]));
    const stops = network.stops.map((stop, index) => {
        const sourceId = stop[4];
        return (sourceId ? stopBySourceId.get(sourceId) : undefined) ?? geographicStops[index];
    });
    const paths = geographicPaths.map((geographicPath, index) => {
        const coordinates = layout.paths[index];
        return coordinates?.length >= 2
            ? prepareProjectedPath(coordinates.map(project))
            : geographicPath;
    });
    const waterPaths = layout.context?.waterPaths
        ?.filter((path) => path.length >= 2)
        .map((path) => prepareProjectedPath(path.map(project))) ?? [];
    return {
        stops,
        paths,
        context: waterPaths.length > 0 ? { waterPaths } : undefined,
    };
}
function pointAt(path, index, count) {
    return (pointAlongProjectedPath(path, count <= 1 ? 0 : index / (count - 1)) ??
        path.points[0] ??
        [0, 0, 0]);
}
export function blendProjectedSpatialLayout(geographicStops, geographicPaths, alternate, mix) {
    if (!alternate || mix <= 0) {
        return { stops: geographicStops, paths: geographicPaths };
    }
    if (mix >= 1)
        return alternate;
    const progress = Math.min(1, Math.max(0, mix));
    const stops = geographicStops.map((from, index) => {
        const to = alternate.stops[index] ?? from;
        return [
            from[0] + (to[0] - from[0]) * progress,
            from[1] + (to[1] - from[1]) * progress,
            from[2] + (to[2] - from[2]) * progress,
        ];
    });
    const paths = geographicPaths.map((from, index) => {
        const to = alternate.paths[index] ?? from;
        const sampleCount = Math.max(2, Math.min(32, Math.max(from.points.length, to.points.length)));
        const points = Array.from({ length: sampleCount }, (_, pointIndex) => {
            const first = pointAt(from, pointIndex, sampleCount);
            const second = pointAt(to, pointIndex, sampleCount);
            return [
                first[0] + (second[0] - first[0]) * progress,
                first[1] + (second[1] - first[1]) * progress,
                first[2] + (second[2] - first[2]) * progress,
            ];
        });
        return prepareProjectedPath(points);
    });
    return { stops, paths, context: alternate.context };
}
