import type { AirPosition } from '@motionstudies/core/domain/air';
export interface AirProjection {
    readonly centreLongitude: number;
    readonly centreLatitude: number;
    readonly longitudeScale: number;
    readonly scale: number;
}
export type ProjectedAirPosition = readonly [x: number, y: number, z: number];
export declare function airAltitudeHeight(altitudeFeet: number): number;
export declare function projectAirPosition(position: Pick<AirPosition, 'longitude' | 'latitude' | 'altitudeFeet'>, projection: AirProjection): ProjectedAirPosition;
