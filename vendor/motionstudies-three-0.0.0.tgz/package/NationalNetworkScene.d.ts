import type { MapBoundary } from '@motionstudies/core/domain/boundary';
import type { StudyAirport } from '@motionstudies/core/domain/airport';
import type { MapWaterBodies } from '@motionstudies/core/domain/lakes';
import type { MapReferencePaths } from '@motionstudies/core/domain/map-reference';
import type { SpatialLayoutSnapshot } from '@motionstudies/core/domain/spatial-layout';
import type { RoadTopologySnapshot, RoadTrafficSnapshot } from '@motionstudies/core/domain/road';
import type { NationalRoadStudySnapshot } from '@motionstudies/core/domain/road-day';
import { type AirSnapshot, type AirTrack } from '@motionstudies/core/domain/air';
import { type NetworkSnapshot, type NetworkRouteIndexEntry, type NetworkTrain, type ServiceCategory, type StationIndexEntry } from '@motionstudies/core/domain/network';
import { type TrainLabelMode } from './train-labels.ts';
import { type MapCameraFraming } from './map-camera.ts';
export type MapCameraAction = 'zoom-in' | 'zoom-out' | 'reset' | 'reveal-station' | 'focus-road' | 'focus-location';
export interface MapCameraCommand {
    readonly id: number;
    readonly action: MapCameraAction;
    readonly focus?: readonly [longitude: number, latitude: number];
    readonly distanceScale?: number;
}
export interface NationalNetworkSceneProps {
    readonly boundary?: MapBoundary;
    readonly lakes?: MapWaterBodies;
    readonly referencePaths?: MapReferencePaths;
    readonly snapshot: NetworkSnapshot;
    readonly referenceSnapshot: NetworkSnapshot;
    readonly contextSnapshot?: NetworkSnapshot;
    readonly isPlaying: boolean;
    readonly time: number;
    readonly selectedTrain?: NetworkTrain;
    /** A small set of simultaneous journeys to compare without choosing a single train. */
    readonly comparisonTrains?: readonly NetworkTrain[];
    readonly comparisonColors?: readonly string[];
    /** Reports the scene clock while playing; paused scenes follow `time` without emitting. */
    readonly onTime: (time: number) => void;
    readonly cameraCommand?: MapCameraCommand;
    readonly playbackRate: number;
    readonly selectedCategory?: ServiceCategory;
    readonly selectedRoute?: NetworkRouteIndexEntry;
    readonly selectedStation?: StationIndexEntry;
    readonly onSelectStation?: (station: StationIndexEntry) => void;
    readonly stations: readonly StationIndexEntry[];
    readonly trainLabelMode: TrainLabelMode;
    readonly cameraFraming: MapCameraFraming;
    readonly airSnapshot?: AirSnapshot;
    readonly airCategorySelected?: boolean;
    readonly airports?: readonly StudyAirport[];
    readonly roadSnapshot?: RoadTrafficSnapshot;
    readonly nationalRoadSnapshot?: NationalRoadStudySnapshot;
    readonly roadTopology?: RoadTopologySnapshot;
    readonly roadCategorySelected?: boolean;
    readonly selectedRoadId?: string;
    readonly selectedAirTrack?: AirTrack;
    readonly selectedAirport?: StudyAirport;
    readonly onSelectAirTrack?: (trackId: string) => void;
    readonly spatialLayout?: SpatialLayoutSnapshot;
    readonly spatialLayoutMix?: number;
    readonly layoutTransitioning?: boolean;
    readonly routeColors?: Readonly<Record<string, string>>;
    /** Route identity may emerge independently of a spatial-layout morph. */
    readonly routeColorMix?: number;
    /** Optional flat, cased network-map treatment for a resolved topological layout. */
    readonly topologicalStyle?: 'luminous' | 'line-map';
    /** Strengthens aggregate edge flow when an edition deliberately pulls back. */
    readonly trafficOverviewEmphasis?: number;
    /** Optional edition-authored semantic tier ceiling; selected routes always win. */
    readonly stationLabelTierLimit?: number;
    /** Allows slower camera studies to hold a label set until movement truly settles. */
    readonly stationLabelSettleSeconds?: number;
}
export interface NetworkProjection {
    readonly centreLongitude: number;
    readonly centreLatitude: number;
    readonly longitudeScale: number;
    readonly scale: number;
}
export declare function NationalNetworkScene(props: NationalNetworkSceneProps): import("react").JSX.Element;
