export declare const VEHICLE_TRAIL_SEGMENTS = 3;
export declare const VEHICLE_TRAIL_STEP_SECONDS = 45;
export declare function vehicleTrailSampleTimes(time: number, segments?: number, stepSeconds?: number): readonly number[];
