export type ProjectedPathPoint = readonly [x: number, y: number, z: number];
export interface ProjectedNetworkPath {
    readonly points: readonly ProjectedPathPoint[];
    readonly cumulativeDistances: readonly number[];
    readonly length: number;
}
export declare function prepareProjectedPath(points: readonly ProjectedPathPoint[]): ProjectedNetworkPath;
export declare function pointAlongProjectedPath(path: ProjectedNetworkPath, progress: number): ProjectedPathPoint | undefined;
export declare function projectedPathRunsForward(path: ProjectedNetworkPath, from: ProjectedPathPoint): boolean;
export declare function pointAlongProjectedPathFrom(path: ProjectedNetworkPath, progress: number, from: ProjectedPathPoint): ProjectedPathPoint | undefined;
