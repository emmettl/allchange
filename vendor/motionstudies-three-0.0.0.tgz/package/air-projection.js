import * as THREE from 'three';
export function airAltitudeHeight(altitudeFeet) {
    return THREE.MathUtils.clamp(0.42 + altitudeFeet / 5_200, 0.42, 8.4);
}
export function projectAirPosition(position, projection) {
    return [
        (position.longitude - projection.centreLongitude) *
            projection.longitudeScale *
            projection.scale,
        airAltitudeHeight(position.altitudeFeet),
        -(position.latitude - projection.centreLatitude) * projection.scale,
    ];
}
