import type { ServiceCategory } from '@motionstudies/core/domain/network';
export type TrainLabelMode = 'auto' | 'on' | 'off';
export declare const MAX_TRAIN_LABELS = 56;
export declare const TRAIN_LABEL_ARRIVAL_FADE_SECONDS = 1.6;
export declare function trainLabelIdentity(route: string, shortName: string): string;
export declare function nonRailCategorySuppressesTrainLabels(airCategorySelected?: boolean, roadCategorySelected?: boolean): boolean;
export declare function trainLabelArrivalOpacity(time: number, end: number, playbackRate: number): number;
export declare function trainLabelScreenHeight(viewportWidth: number, selected: boolean, cameraHeight: number): number;
export declare function trainLabelScreenWidth(label: string, screenHeight: number): number;
export declare function trainLabelBudget(cameraHeight: number, mode: TrainLabelMode): number;
export declare function trainLabelPriority(category: ServiceCategory): number;
export interface TrainLabelCandidatePriority {
    readonly id: string;
    readonly category: ServiceCategory;
    readonly retained: boolean;
}
export declare function compareTrainLabelCandidates(first: TrainLabelCandidatePriority, second: TrainLabelCandidatePriority): number;
export declare function categoryIsVisibleInAutoMode(category: ServiceCategory, cameraHeight: number): boolean;
