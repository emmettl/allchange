import { type AirSnapshot } from '@motionstudies/core/domain/air';
import { type StudyAirport } from '@motionstudies/core/domain/airport';
import { type AirProjection } from './air-projection.ts';
import type { TrainLabelMode } from './train-labels.ts';
export declare function AirTrafficLayer({ snapshot, time, isPlaying, playbackRate, projection, airports, emphasizeAirports, selectedTrackId, selectedAirport, onSelectTrack, labelMode, subdued, }: {
    readonly snapshot: AirSnapshot;
    readonly time: number;
    readonly isPlaying: boolean;
    readonly playbackRate: number;
    readonly projection: AirProjection;
    readonly airports?: readonly StudyAirport[];
    readonly emphasizeAirports?: boolean;
    readonly selectedTrackId?: string;
    readonly selectedAirport?: StudyAirport;
    readonly onSelectTrack?: (trackId: string) => void;
    readonly labelMode: TrainLabelMode;
    readonly subdued?: boolean;
}): import("react").JSX.Element;
