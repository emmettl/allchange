import type { StationIndexEntry } from '@motionstudies/core/domain/network';
import { type MapCameraFraming } from './map-camera.ts';
export declare const MAX_STATION_LABELS = 96;
export declare const STATION_LABEL_SETTLE_SECONDS = 0.16;
export declare function stationLabelsCanRepopulate(stableSeconds: number, settleSeconds?: number): boolean;
export declare function stableStationLabelBudget(targetBudget: number, retainedCount: number, canRepopulate: boolean): number;
export interface StationScreenPoint {
    readonly index: number;
    readonly x: number;
    readonly y: number;
}
export interface StationLabelCandidatePriority {
    readonly name: string;
    readonly rank: number;
    readonly priority: number;
    readonly retained: boolean;
    readonly distance: number;
}
export declare function compareStationLabelCandidates(first: StationLabelCandidatePriority, second: StationLabelCandidatePriority): number;
export declare function stationTapRadius(pointerType: string): number;
export declare function stationIndexAtScreenPoint(x: number, y: number, stations: readonly StationScreenPoint[], radius: number): number | undefined;
export declare function stationLabelScreenHeight(selected: boolean, emphasised: boolean, labelRank?: number): number;
export declare function stationLabelOpacity(selected: boolean, emphasised: boolean, labelRank?: number): number;
export declare function stationLabelWithinTier(labelRank: number | undefined, tierLimit: number | undefined): boolean;
export declare function stationLabelScreenWidth(label: string, screenHeight: number): number;
export declare function stationLabelWorldHeight(cameraDepth: number, verticalFieldOfView: number, viewportHeight: number, screenHeight: number): number;
export declare function stationLabelCameraHeight(cameraHeight: number, framing: MapCameraFraming): number;
export declare function stationLabelText(name: string, framing: MapCameraFraming): string;
export declare function stationLabelBudget(cameraHeight: number): number;
export declare function stationLabelRankLimit(cameraHeight: number): number;
export declare function rankStationsForLabels(stations: readonly StationIndexEntry[]): readonly StationIndexEntry[];
