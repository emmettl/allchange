import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { createContext, useContext, useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { positionForAirTrack, } from '@motionstudies/core/domain/air';
import { positionForTrain, } from '@motionstudies/core/domain/network';
import { SERVICE_COLORS } from '@motionstudies/core/theme';
import { buildTrainTimeIndex, trainsNearTime, } from '@motionstudies/core/domain/train-time-index';
import { compareStationLabelCandidates, MAX_STATION_LABELS, rankStationsForLabels, stationIndexAtScreenPoint, stationLabelCameraHeight, stationLabelBudget, stationLabelRankLimit, stationLabelScreenHeight, stationLabelOpacity, stationLabelScreenWidth, stationLabelText, stationLabelWorldHeight, stationLabelsCanRepopulate, stationLabelWithinTier, stationTapRadius, stableStationLabelBudget, } from './station-labels.js';
import { categoryIsVisibleInAutoMode, compareTrainLabelCandidates, MAX_TRAIN_LABELS, nonRailCategorySuppressesTrainLabels, trainLabelArrivalOpacity, trainLabelBudget, trainLabelIdentity, trainLabelScreenHeight, trainLabelScreenWidth, } from './train-labels.js';
import { edgeTrafficWeights } from './traffic-weights.js';
import { VEHICLE_TRAIL_SEGMENTS, VEHICLE_TRAIL_STEP_SECONDS, vehicleTrailSampleTimes, } from './vehicle-trails.js';
import { applyMapZoom, ATLAS_MAP_FRAMING, homeMapDistanceScale, mapCameraDampingRate, mapCameraFieldOfView, mapPanScale, mapSelectionNeedsReveal, mapWheelZoomMultiplier, minimumMapDistanceScale, STATION_SELECTION_PULSE_COUNT, stationSelectionPulseFrame, } from './map-camera.js';
import { pointAlongProjectedPath, pointAlongProjectedPathFrom, prepareProjectedPath, projectedPathRunsForward, } from './network-paths.js';
import { createLakeAvoidingPathMap, lakeAvoidingPathForStops, } from './lake-aware-paths.js';
import { localNetworkDetailAtZoom, regionalCameraHeight, vehicleIsVisibleAtZoom, } from './regional-lod.js';
import { AirTrafficLayer } from './AirTrafficLayer.js';
import { projectAirPosition } from './air-projection.js';
import { RoadTrafficLayer } from './RoadTrafficLayer.js';
import { blendProjectedSpatialLayout, projectSpatialLayout, } from './spatial-layout.js';
const EMPTY_LAKE_AVOIDING_PATHS = new Map();
const LakeAvoidingPathsContext = createContext(EMPTY_LAKE_AVOIDING_PATHS);
const STATION_SURFACE_Y = 0.035;
function mixedRouteColor(category, routeName, routeColors, mix) {
    const identityColor = routeColors?.[routeName];
    if (!identityColor || mix <= 0)
        return SERVICE_COLORS[category];
    return `#${new THREE.Color(SERVICE_COLORS[category])
        .lerp(new THREE.Color(identityColor), THREE.MathUtils.clamp(mix, 0, 1))
        .getHexString()}`;
}
const MAP_LAYER = {
    selectionGlow: 6,
    selectionCore: 7,
    selectionStopGlow: 8,
    selectionStopCore: 9,
    vehicleGlow: 10,
    vehicleCore: 11,
    vehicleSpark: 12,
    focusMarkerGlow: 13,
    focusMarkerCore: 14,
    trainLabel: 16,
    stationLabel: 20,
};
function createNetworkProjection(snapshot) {
    const { bounds } = snapshot;
    const centreLongitude = (bounds.minLongitude + bounds.maxLongitude) / 2;
    const centreLatitude = (bounds.minLatitude + bounds.maxLatitude) / 2;
    const longitudeScale = Math.cos((centreLatitude * Math.PI) / 180);
    const projectedWidth = (bounds.maxLongitude - bounds.minLongitude) * longitudeScale;
    return {
        centreLongitude,
        centreLatitude,
        longitudeScale,
        scale: 51 / projectedWidth,
    };
}
function projectCoordinate([longitude, latitude], projection, height = 0) {
    return [
        (longitude - projection.centreLongitude) *
            projection.longitudeScale *
            projection.scale,
        height,
        -(latitude - projection.centreLatitude) * projection.scale,
    ];
}
function projectStops(snapshot, projection) {
    return snapshot.stops.map(([longitude, latitude]) => projectCoordinate([longitude, latitude], projection));
}
function projectPaths(snapshot, projection) {
    return (snapshot.paths ?? []).map((path) => prepareProjectedPath(path.map((coordinate) => projectCoordinate(coordinate, projection))));
}
function segmentPoints(train, segmentIndex, projectedStops, projectedPaths, lakeAvoidingPaths = EMPTY_LAKE_AVOIDING_PATHS) {
    const pathIndex = train.pathSegments?.[segmentIndex];
    if (pathIndex !== undefined && pathIndex !== null) {
        const path = projectedPaths[pathIndex];
        if (path?.points.length) {
            const fromIndex = train.stops[segmentIndex]?.[0];
            const from = fromIndex === undefined ? undefined : projectedStops[fromIndex];
            if (!from || projectedPathRunsForward(path, from))
                return path.points;
            return [...path.points].reverse();
        }
    }
    const fromIndex = train.stops[segmentIndex]?.[0];
    const toIndex = train.stops[segmentIndex + 1]?.[0];
    if (fromIndex === undefined || toIndex === undefined)
        return [];
    const detour = lakeAvoidingPathForStops(lakeAvoidingPaths, fromIndex, toIndex);
    if (detour)
        return detour.points;
    const from = projectedStops[fromIndex];
    const to = projectedStops[toIndex];
    return from && to ? [from, to] : [];
}
function appendLineSegments(positions, points, height) {
    for (let index = 1; index < points.length; index += 1) {
        const from = points[index - 1];
        const to = points[index];
        positions.push(from[0], height, from[2], to[0], height, to[2]);
    }
}
function routeSegmentKey(train, segmentIndex) {
    const fromIndex = train.stops[segmentIndex]?.[0];
    const toIndex = train.stops[segmentIndex + 1]?.[0];
    const pathIndex = train.pathSegments?.[segmentIndex];
    if (pathIndex !== undefined && pathIndex !== null)
        return `path:${pathIndex}`;
    if (fromIndex === undefined || toIndex === undefined) {
        return `missing:${train.id}:${segmentIndex}`;
    }
    return fromIndex < toIndex
        ? `${fromIndex}:${toIndex}`
        : `${toIndex}:${fromIndex}`;
}
function offsetProjectedPath(points, offset) {
    if (!offset || points.length < 2)
        return points;
    return points.map((point, index) => {
        const previous = points[Math.max(0, index - 1)];
        const next = points[Math.min(points.length - 1, index + 1)];
        const tangentX = next[0] - previous[0];
        const tangentZ = next[2] - previous[2];
        const length = Math.hypot(tangentX, tangentZ);
        if (!length)
            return point;
        return [
            point[0] - (tangentZ / length) * offset,
            point[1],
            point[2] + (tangentX / length) * offset,
        ];
    });
}
function canonicalInterchangeName(name) {
    return name
        .replace(/\s+\([^)]*\)$/i, '')
        .replace(/\s+/g, ' ')
        .trim();
}
function projectedTrainPosition(train, time, projectedStops, projectedPaths = [], lakeAvoidingPaths = EMPTY_LAKE_AVOIDING_PATHS) {
    const position = positionForTrain(train, time);
    if (!position)
        return undefined;
    const pathIndex = position.segmentIndex === undefined
        ? undefined
        : train.pathSegments?.[position.segmentIndex];
    const path = pathIndex === undefined || pathIndex === null
        ? undefined
        : projectedPaths[pathIndex];
    if (path) {
        const from = projectedStops[position.fromStop];
        const point = from
            ? pointAlongProjectedPathFrom(path, position.progress, from)
            : pointAlongProjectedPath(path, position.progress);
        if (point)
            return [point[0], 0.2, point[2]];
    }
    const detour = lakeAvoidingPathForStops(lakeAvoidingPaths, position.fromStop, position.toStop);
    if (detour) {
        const point = pointAlongProjectedPath(detour, position.progress);
        if (point)
            return [point[0], 0.2, point[2]];
    }
    const from = projectedStops[position.fromStop];
    const to = projectedStops[position.toStop];
    if (!from || !to)
        return undefined;
    return [
        THREE.MathUtils.lerp(from[0], to[0], position.progress),
        0.2,
        THREE.MathUtils.lerp(from[2], to[2], position.progress),
    ];
}
function NationalGround() {
    return (_jsxs("group", { position: [0, -0.11, 0], children: [_jsxs("mesh", { rotation: [-Math.PI / 2, 0, 0], children: [_jsx("planeGeometry", { args: [66, 56, 64, 48] }), _jsx("meshBasicMaterial", { color: "#090b1f", transparent: true, opacity: 0.7 })] }), _jsxs("mesh", { rotation: [-Math.PI / 2, 0, 0], position: [0, 0.015, 0], children: [_jsx("planeGeometry", { args: [66, 56, 64, 48] }), _jsx("meshBasicMaterial", { color: "#424b98", transparent: true, opacity: 0.1, wireframe: true })] })] }));
}
function LakeLayer({ lakes, projection, subdued, opacityScale = 1, }) {
    const geometry = useMemo(() => {
        const shapes = [];
        const shorelinePositions = [];
        for (const lake of lakes.lakes) {
            for (const polygon of lake.polygons) {
                const [outerRing, ...holes] = polygon;
                if (!outerRing || outerRing.length < 4)
                    continue;
                const outer = outerRing.map((coordinate) => {
                    const [x, , z] = projectCoordinate(coordinate, projection);
                    return new THREE.Vector2(x, z);
                });
                const shape = new THREE.Shape(outer);
                for (const holeRing of holes) {
                    const hole = holeRing.map((coordinate) => {
                        const [x, , z] = projectCoordinate(coordinate, projection);
                        return new THREE.Vector2(x, z);
                    });
                    if (hole.length >= 4)
                        shape.holes.push(new THREE.Path(hole));
                }
                shapes.push(shape);
                for (const ring of polygon) {
                    const projected = ring.map((coordinate) => projectCoordinate(coordinate, projection));
                    if (projected.length < 2)
                        continue;
                    const isClosed = projected[0][0] === projected.at(-1)?.[0] &&
                        projected[0][2] === projected.at(-1)?.[2];
                    appendLineSegments(shorelinePositions, isClosed ? projected : [...projected, projected[0]], 0);
                }
            }
        }
        const fill = new THREE.ShapeGeometry(shapes);
        fill.rotateX(Math.PI / 2);
        const shoreline = new THREE.BufferGeometry();
        shoreline.setAttribute('position', new THREE.Float32BufferAttribute(shorelinePositions, 3));
        return { fill, shoreline };
    }, [lakes.lakes, projection]);
    useEffect(() => () => {
        geometry.fill.dispose();
        geometry.shoreline.dispose();
    }, [geometry]);
    return (_jsxs("group", { position: [0, -0.072, 0], children: [_jsx("mesh", { geometry: geometry.fill, renderOrder: 1, children: _jsx("meshBasicMaterial", { color: "#08233b", transparent: true, opacity: (subdued ? 0.42 : 0.9) * opacityScale, depthWrite: false, side: THREE.DoubleSide, fog: false }) }), _jsx("mesh", { geometry: geometry.fill, position: [0, 0.007, 0], renderOrder: 1, children: _jsx("meshBasicMaterial", { color: "#20a9cb", transparent: true, opacity: (subdued ? 0.035 : 0.13) * opacityScale, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false, fog: false }) }), _jsx("lineSegments", { geometry: geometry.shoreline, position: [0, 0.014, 0], renderOrder: 2, children: _jsx("lineBasicMaterial", { color: "#54dff7", transparent: true, opacity: (subdued ? 0.06 : 0.31) * opacityScale, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, fog: false }) })] }));
}
function DiagramWaterLayer({ paths, opacity, }) {
    const geometry = useMemo(() => {
        const positions = [];
        paths.forEach((path) => appendLineSegments(positions, path.points, 0.025));
        const line = new THREE.BufferGeometry();
        line.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        const ribbons = paths
            .filter((path) => path.points.length >= 2)
            .map((path) => {
            const curve = new THREE.CatmullRomCurve3(path.points.map(([x, , z]) => new THREE.Vector3(x, 0.02, z)), false, 'centripetal');
            return new THREE.TubeGeometry(curve, Math.max(24, path.points.length * 6), 0.085, 5, false);
        });
        return { line, ribbons };
    }, [paths]);
    useEffect(() => () => {
        geometry.line.dispose();
        geometry.ribbons.forEach((ribbon) => ribbon.dispose());
    }, [geometry]);
    return (_jsxs("group", { children: [geometry.ribbons.map((ribbon, index) => (_jsx("mesh", { geometry: ribbon, renderOrder: 1, children: _jsx("meshBasicMaterial", { color: "#075277", transparent: true, opacity: opacity * 0.78, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }, index))), _jsx("lineSegments", { geometry: geometry.line, renderOrder: 2, children: _jsx("lineBasicMaterial", { color: "#55d6e8", transparent: true, opacity: opacity * 0.28, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) })] }));
}
function ReferencePathLayer({ references, projection, subdued, }) {
    const paths = useMemo(() => references.references.map((reference) => {
        const positions = [];
        for (const path of reference.paths) {
            appendLineSegments(positions, path.map((coordinate) => projectCoordinate(coordinate, projection)), 0.028);
        }
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
        return { ...reference, geometry };
    }), [projection, references.references]);
    useEffect(() => () => paths.forEach(({ geometry }) => geometry.dispose()), [paths]);
    return (_jsx("group", { children: paths.map(({ id, color, geometry }) => (_jsx("lineSegments", { geometry: geometry, renderOrder: 1, children: _jsx("lineBasicMaterial", { color: color ?? '#c9a9dd', transparent: true, opacity: subdued ? 0.04 : 0.2, depthWrite: false, toneMapped: false, fog: false }) }, id))) }));
}
function CountryBorder({ boundary, projection, subdued, opacityScale = 1, }) {
    const tubes = useMemo(() => {
        return boundary.rings.flatMap((ring, index) => {
            const coordinates = ring.length > 1 &&
                ring[0][0] === ring[ring.length - 1][0] &&
                ring[0][1] === ring[ring.length - 1][1]
                ? ring.slice(0, -1)
                : ring;
            if (coordinates.length < 4)
                return [];
            const points = coordinates.map((coordinate) => {
                const [x, y, z] = projectCoordinate(coordinate, projection, 0.075);
                return new THREE.Vector3(x, y, z);
            });
            const curve = new THREE.CatmullRomCurve3(points, true, 'centripetal', 0.5);
            const segments = THREE.MathUtils.clamp(points.length * 2, 24, 920);
            return [{
                    id: `${index}:${coordinates.length}`,
                    glow: new THREE.TubeGeometry(curve, segments, 0.13, 5, true),
                    core: new THREE.TubeGeometry(curve, segments, 0.026, 5, true),
                }];
        });
    }, [boundary.rings, projection]);
    useEffect(() => () => {
        tubes.forEach(({ glow, core }) => {
            glow.dispose();
            core.dispose();
        });
    }, [tubes]);
    return (_jsx("group", { children: tubes.map(({ id, glow, core }) => (_jsxs("group", { children: [_jsx("mesh", { geometry: glow, children: _jsx("meshBasicMaterial", { color: "#56e9ff", transparent: true, opacity: (subdued ? 0.018 : 0.12) * opacityScale, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, fog: false }) }), _jsx("mesh", { geometry: core, renderOrder: 2, children: _jsx("meshBasicMaterial", { color: "#b9fbff", transparent: true, opacity: (subdued ? 0.13 : 0.84) * opacityScale, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false, fog: false }) })] }, id))) }));
}
function RailGraph({ snapshot, projectedStops, projectedPaths, cameraFraming, subdued, lakeAvoidingPaths, showTraffic = true, routeColors, routeColorMix = 0, trafficOverviewEmphasis = 0, lineMapStyle = false, }) {
    const { camera } = useThree();
    const stationMaterial = useRef(null);
    const interchangeMaterial = useRef(null);
    const localNetworkMaterial = useRef(null);
    const stationTexture = useMemo(() => trainLightTexture('orb'), []);
    const diagramStationTexture = useMemo(() => diagramStopTexture(), []);
    const interchangeTexture = useMemo(() => diagramInterchangeTexture(), []);
    const railGeometry = useMemo(() => {
        const structuralPositions = [];
        const localPositions = [];
        snapshot.edges.forEach(([fromIndex, toIndex], edgeIndex) => {
            const from = projectedStops[fromIndex];
            const to = projectedStops[toIndex];
            if (!from || !to)
                return;
            const pathIndex = snapshot.edgePaths?.[edgeIndex];
            const path = pathIndex === undefined || pathIndex === null
                ? undefined
                : projectedPaths[pathIndex];
            const detour = lakeAvoidingPathForStops(lakeAvoidingPaths, fromIndex, toIndex);
            appendLineSegments(pathIndex === undefined || pathIndex === null
                ? structuralPositions
                : localPositions, path?.points ?? detour?.points ?? [from, to], 0);
        });
        const structural = new THREE.BufferGeometry();
        structural.setAttribute('position', new THREE.Float32BufferAttribute(structuralPositions, 3));
        const local = new THREE.BufferGeometry();
        local.setAttribute('position', new THREE.Float32BufferAttribute(localPositions, 3));
        return { structural, local };
    }, [
        lakeAvoidingPaths,
        projectedPaths,
        projectedStops,
        snapshot.edgePaths,
        snapshot.edges,
    ]);
    const stationGeometry = useMemo(() => {
        const positions = new Float32Array(projectedStops.length * 3);
        projectedStops.forEach((stop, index) => positions.set(stop, index * 3));
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        return geometry;
    }, [projectedStops]);
    const diagramStationGeometries = useMemo(() => {
        const stationRoutes = new Map();
        for (const train of snapshot.trains) {
            for (const [stopIndex] of train.stops) {
                const stop = snapshot.stops[stopIndex];
                if (!stop)
                    continue;
                const name = canonicalInterchangeName(stop[2]);
                const rank = stop[5] ?? Number.MAX_SAFE_INTEGER;
                const record = stationRoutes.get(name) ?? {
                    routes: new Set(),
                    stopIndex,
                    rank,
                };
                record.routes.add(train.route);
                if (rank < record.rank) {
                    record.stopIndex = stopIndex;
                    record.rank = rank;
                }
                stationRoutes.set(name, record);
            }
        }
        const stopPositions = [];
        const interchangePositions = [];
        for (const { routes, stopIndex } of stationRoutes.values()) {
            const stop = projectedStops[stopIndex];
            if (!stop)
                continue;
            const positions = routes.size < 2 ? stopPositions : interchangePositions;
            positions.push(stop[0], stop[1], stop[2]);
        }
        const stops = new THREE.BufferGeometry();
        stops.setAttribute('position', new THREE.Float32BufferAttribute(stopPositions, 3));
        const interchanges = new THREE.BufferGeometry();
        interchanges.setAttribute('position', new THREE.Float32BufferAttribute(interchangePositions, 3));
        return { stops, interchanges };
    }, [projectedStops, snapshot.stops, snapshot.trains]);
    useEffect(() => () => {
        stationTexture.dispose();
        diagramStationTexture.dispose();
        interchangeTexture.dispose();
    }, [diagramStationTexture, interchangeTexture, stationTexture]);
    useEffect(() => () => {
        railGeometry.structural.dispose();
        railGeometry.local.dispose();
        diagramStationGeometries.stops.dispose();
        diagramStationGeometries.interchanges.dispose();
    }, [diagramStationGeometries, railGeometry]);
    useFrame(() => {
        if (!stationMaterial.current || !localNetworkMaterial.current)
            return;
        const cameraScale = THREE.MathUtils.clamp(camera.position.y / 37, 0.02, 1);
        stationMaterial.current.size = 0.065 * cameraScale;
        stationMaterial.current.opacity =
            (subdued ? 0.055 : 0.4) *
                (lineMapStyle ? 1 - routeColorMix : 1 - routeColorMix * 0.9);
        if (interchangeMaterial.current) {
            interchangeMaterial.current.opacity =
                routeColorMix * (subdued ? 0.38 : 0.94);
        }
        const detail = localNetworkDetailAtZoom(camera.position.y, cameraFraming);
        const identityAttenuation = lineMapStyle
            ? 1 - routeColorMix
            : 1 - routeColorMix * 0.88;
        localNetworkMaterial.current.opacity =
            (subdued ? 0.008 + detail * 0.025 : 0.025 + detail * 0.115) *
                identityAttenuation;
    });
    return (_jsxs(_Fragment, { children: [_jsx("lineSegments", { geometry: railGeometry.structural, children: _jsx("lineBasicMaterial", { color: "#7296bb", transparent: true, opacity: (subdued ? 0.035 : 0.14) *
                        (lineMapStyle ? 1 - routeColorMix : 1 - routeColorMix * 0.88), blending: THREE.AdditiveBlending }) }), _jsx("lineSegments", { geometry: railGeometry.local, children: _jsx("lineBasicMaterial", { ref: localNetworkMaterial, color: "#7296bb", transparent: true, opacity: subdued ? 0.035 : 0.14, blending: THREE.AdditiveBlending }) }), showTraffic && (_jsx(TrafficFlowLayer, { snapshot: snapshot, projectedStops: projectedStops, projectedPaths: projectedPaths, lakeAvoidingPaths: lakeAvoidingPaths, subdued: subdued, identityMix: routeColorMix, overviewEmphasis: trafficOverviewEmphasis, suppressAtIdentity: lineMapStyle })), routeColors && routeColorMix > 0.001 && (_jsxs(_Fragment, { children: [_jsx(RouteIdentityLayer, { snapshot: snapshot, projectedStops: projectedStops, projectedPaths: projectedPaths, lakeAvoidingPaths: lakeAvoidingPaths, routeColors: routeColors, opacity: routeColorMix, subdued: subdued, lineMapStyle: lineMapStyle }), lineMapStyle && (_jsxs(_Fragment, { children: [_jsx("points", { geometry: diagramStationGeometries.stops, position: [0, STATION_SURFACE_Y + 0.09, 0], renderOrder: 5, children: _jsx("pointsMaterial", { color: "#fffdf4", map: diagramStationTexture, size: 4.2, transparent: true, opacity: routeColorMix * (subdued ? 0.42 : 0.96), alphaTest: 0.08, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) }), _jsx("points", { geometry: diagramStationGeometries.interchanges, position: [0, STATION_SURFACE_Y + 0.1, 0], renderOrder: 6, children: _jsx("pointsMaterial", { ref: interchangeMaterial, color: "#fffdf4", map: interchangeTexture, size: 11, transparent: true, opacity: routeColorMix * (subdued ? 0.5 : 0.98), alphaTest: 0.08, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) })] })), !lineMapStyle && (_jsx("points", { geometry: diagramStationGeometries.interchanges, position: [0, STATION_SURFACE_Y + 0.08, 0], renderOrder: 4, children: _jsx("pointsMaterial", { ref: interchangeMaterial, color: "#fffdf4", map: interchangeTexture, size: 0.32, transparent: true, opacity: routeColorMix * (subdued ? 0.38 : 0.94), alphaTest: 0.08, depthTest: false, depthWrite: false, sizeAttenuation: true, toneMapped: false, fog: false }) }))] })), _jsx("points", { geometry: stationGeometry, position: [0, STATION_SURFACE_Y, 0], children: _jsx("pointsMaterial", { ref: stationMaterial, color: "#a18cff", map: stationTexture, size: 0.065, transparent: true, opacity: subdued ? 0.055 : 0.4, alphaTest: 0.015, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true, toneMapped: false }) })] }));
}
function diagramRibbonGeometry(segments, halfWidth, height) {
    const positions = [];
    for (let index = 0; index < segments.length; index += 6) {
        const fromX = segments[index];
        const fromZ = segments[index + 2];
        const toX = segments[index + 3];
        const toZ = segments[index + 5];
        const deltaX = toX - fromX;
        const deltaZ = toZ - fromZ;
        const length = Math.hypot(deltaX, deltaZ);
        if (length < 0.0001)
            continue;
        const normalX = (-deltaZ / length) * halfWidth;
        const normalZ = (deltaX / length) * halfWidth;
        const capX = (deltaX / length) * halfWidth * 0.45;
        const capZ = (deltaZ / length) * halfWidth * 0.45;
        const ax = fromX - capX + normalX;
        const az = fromZ - capZ + normalZ;
        const bx = fromX - capX - normalX;
        const bz = fromZ - capZ - normalZ;
        const cx = toX + capX - normalX;
        const cz = toZ + capZ - normalZ;
        const dx = toX + capX + normalX;
        const dz = toZ + capZ + normalZ;
        positions.push(ax, height, az, bx, height, bz, cx, height, cz, ax, height, az, cx, height, cz, dx, height, dz);
    }
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    return geometry;
}
function RouteIdentityLayer({ snapshot, projectedStops, projectedPaths, lakeAvoidingPaths, routeColors, opacity, subdued, lineMapStyle = false, }) {
    const routes = useMemo(() => {
        const segmentRoutes = new Map();
        for (const train of snapshot.trains) {
            if (!routeColors[train.route])
                continue;
            for (let index = 1; index < train.stops.length; index += 1) {
                const key = routeSegmentKey(train, index - 1);
                const names = segmentRoutes.get(key) ?? new Set();
                names.add(train.route);
                segmentRoutes.set(key, names);
            }
        }
        const records = new Map();
        for (const train of snapshot.trains) {
            const color = routeColors[train.route];
            if (!color)
                continue;
            const record = records.get(train.route) ?? {
                color,
                positions: [],
                segments: new Set(),
            };
            for (let index = 1; index < train.stops.length; index += 1) {
                const key = routeSegmentKey(train, index - 1);
                if (record.segments.has(key))
                    continue;
                const points = segmentPoints(train, index - 1, projectedStops, projectedPaths, lakeAvoidingPaths);
                if (points.length < 2)
                    continue;
                record.segments.add(key);
                const sharedRoutes = [...(segmentRoutes.get(key) ?? [])].sort();
                const laneIndex = sharedRoutes.indexOf(train.route);
                const laneOffset = sharedRoutes.length < 2 || laneIndex < 0
                    ? 0
                    : (laneIndex - (sharedRoutes.length - 1) / 2) *
                        (lineMapStyle ? 0.24 : 0.11);
                appendLineSegments(record.positions, offsetProjectedPath(points, laneOffset), 0.075);
            }
            records.set(train.route, record);
        }
        return [...records.entries()].map(([name, record]) => {
            const geometry = new THREE.BufferGeometry();
            geometry.setAttribute('position', new THREE.Float32BufferAttribute(record.positions, 3));
            return {
                name,
                color: record.color,
                geometry,
                casing: lineMapStyle
                    ? diagramRibbonGeometry(record.positions, 0.16, 0.072)
                    : undefined,
                core: lineMapStyle
                    ? diagramRibbonGeometry(record.positions, 0.1, 0.078)
                    : undefined,
            };
        }).sort((first, second) => first.name.localeCompare(second.name, 'en'));
    }, [
        lakeAvoidingPaths,
        lineMapStyle,
        projectedPaths,
        projectedStops,
        routeColors,
        snapshot,
    ]);
    useEffect(() => () => routes.forEach(({ geometry, casing, core }) => {
        geometry.dispose();
        casing?.dispose();
        core?.dispose();
    }), [routes]);
    if (lineMapStyle) {
        return (_jsxs("group", { children: [routes.map(({ name, casing }) => casing ? (_jsx("mesh", { geometry: casing, renderOrder: 3, children: _jsx("meshBasicMaterial", { color: "#050510", transparent: true, opacity: opacity * (subdued ? 0.52 : 0.96), depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }, `casing:${name}`)) : null), routes.map(({ name, color, core }) => core ? (_jsx("mesh", { geometry: core, renderOrder: 4, children: _jsx("meshBasicMaterial", { color: color, transparent: true, opacity: opacity * (subdued ? 0.28 : 0.94), depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }, name)) : null)] }));
    }
    return (_jsx("group", { children: routes.map(({ name, color, geometry }) => (_jsx("lineSegments", { geometry: geometry, renderOrder: 3, children: _jsx("lineBasicMaterial", { color: color, transparent: true, opacity: opacity * (subdued ? 0.12 : 0.74), blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }, name))) }));
}
function TrafficFlowLayer({ snapshot, projectedStops, projectedPaths, lakeAvoidingPaths, subdued, identityMix = 0, overviewEmphasis = 0, suppressAtIdentity = false, }) {
    const pulseMaterial = useRef(null);
    const geometries = useMemo(() => {
        const { strengths } = edgeTrafficWeights(snapshot);
        const weightedPositions = [];
        const weightedColors = [];
        const pulsePositions = [];
        const pulseColors = [];
        const quiet = new THREE.Color('#18204a');
        const busy = new THREE.Color('#8dfaff');
        snapshot.edges.forEach(([fromIndex, toIndex], edgeIndex) => {
            const strength = strengths[edgeIndex] ?? 0;
            const from = projectedStops[fromIndex];
            const to = projectedStops[toIndex];
            if (!strength || !from || !to)
                return;
            const pathIndex = snapshot.edgePaths?.[edgeIndex];
            const path = pathIndex === undefined || pathIndex === null
                ? undefined
                : projectedPaths[pathIndex];
            const detour = lakeAvoidingPathForStops(lakeAvoidingPaths, fromIndex, toIndex);
            const points = path?.points ?? detour?.points ?? [from, to];
            const color = quiet.clone().lerp(busy, strength);
            color.multiplyScalar(0.2 + strength * 0.8);
            appendLineSegments(weightedPositions, points, 0);
            for (let index = 1; index < points.length; index += 1) {
                weightedColors.push(color.r, color.g, color.b, color.r, color.g, color.b);
            }
            if (strength >= 0.82) {
                appendLineSegments(pulsePositions, points, 0);
                for (let index = 1; index < points.length; index += 1) {
                    pulseColors.push(color.r, color.g, color.b, color.r, color.g, color.b);
                }
            }
        });
        const weighted = new THREE.BufferGeometry();
        weighted.setAttribute('position', new THREE.Float32BufferAttribute(weightedPositions, 3));
        weighted.setAttribute('color', new THREE.Float32BufferAttribute(weightedColors, 3));
        const pulse = new THREE.BufferGeometry();
        pulse.setAttribute('position', new THREE.Float32BufferAttribute(pulsePositions, 3));
        pulse.setAttribute('color', new THREE.Float32BufferAttribute(pulseColors, 3));
        return { weighted, pulse };
    }, [lakeAvoidingPaths, projectedPaths, projectedStops, snapshot]);
    useEffect(() => () => {
        geometries.weighted.dispose();
        geometries.pulse.dispose();
    }, [geometries]);
    useFrame(({ clock }) => {
        if (!pulseMaterial.current)
            return;
        const wave = 0.5 + Math.sin(clock.elapsedTime * 1.35) * 0.5;
        const identityAttenuation = suppressAtIdentity
            ? 1 - identityMix
            : 1 - identityMix * 0.72;
        pulseMaterial.current.opacity =
            (subdued ? 0.012 + wave * 0.012 : 0.1 + wave * 0.12) *
                identityAttenuation *
                (1 + overviewEmphasis * 1.15);
    });
    const identityAttenuation = suppressAtIdentity
        ? 1 - identityMix
        : 1 - identityMix * 0.78;
    return (_jsxs("group", { position: [0, 0.055, 0], children: [_jsx("lineSegments", { geometry: geometries.weighted, renderOrder: 1, children: _jsx("lineBasicMaterial", { vertexColors: true, transparent: true, opacity: (subdued ? 0.045 : 0.62) *
                        identityAttenuation *
                        (1 + overviewEmphasis * 1.2), blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }) }), _jsx("lineSegments", { geometry: geometries.pulse, renderOrder: 2, children: _jsx("lineBasicMaterial", { ref: pulseMaterial, vertexColors: true, transparent: true, opacity: subdued ? 0.035 : 0.16, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }) })] }));
}
function trainLightTexture(kind) {
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 96;
    const context = canvas.getContext('2d');
    if (context) {
        const gradient = context.createRadialGradient(43, 39, 0, 48, 48, 46);
        if (kind === 'halo') {
            gradient.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
            gradient.addColorStop(0.12, 'rgba(255, 255, 255, 0.72)');
            gradient.addColorStop(0.34, 'rgba(255, 255, 255, 0.3)');
            gradient.addColorStop(0.72, 'rgba(255, 255, 255, 0.07)');
            gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        }
        else if (kind === 'orb') {
            gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
            gradient.addColorStop(0.18, 'rgba(255, 255, 255, 0.98)');
            gradient.addColorStop(0.5, 'rgba(255, 255, 255, 0.78)');
            gradient.addColorStop(0.76, 'rgba(255, 255, 255, 0.3)');
            gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        }
        else {
            gradient.addColorStop(0, 'rgba(255, 255, 255, 1)');
            gradient.addColorStop(0.32, 'rgba(255, 255, 255, 0.96)');
            gradient.addColorStop(0.68, 'rgba(255, 255, 255, 0.18)');
            gradient.addColorStop(1, 'rgba(255, 255, 255, 0)');
        }
        context.fillStyle = gradient;
        context.fillRect(0, 0, canvas.width, canvas.height);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return texture;
}
function realtimeRingTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 96;
    const context = canvas.getContext('2d');
    if (context) {
        context.strokeStyle = 'rgba(255, 255, 255, 0.96)';
        context.lineWidth = 7;
        context.shadowColor = 'rgba(255, 255, 255, 0.8)';
        context.shadowBlur = 10;
        context.beginPath();
        context.arc(48, 48, 30, 0, Math.PI * 2);
        context.stroke();
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return texture;
}
function diagramStopTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 48;
    canvas.height = 48;
    const context = canvas.getContext('2d');
    if (context) {
        context.fillStyle = 'rgba(255, 253, 244, 1)';
        context.beginPath();
        context.arc(24, 24, 18, 0, Math.PI * 2);
        context.fill();
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return texture;
}
function diagramInterchangeTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 96;
    const context = canvas.getContext('2d');
    if (context) {
        context.fillStyle = 'rgba(255, 253, 244, 0.98)';
        context.beginPath();
        context.arc(48, 48, 31, 0, Math.PI * 2);
        context.fill();
        context.fillStyle = 'rgba(5, 6, 18, 0.98)';
        context.beginPath();
        context.arc(48, 48, 18, 0, Math.PI * 2);
        context.fill();
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return texture;
}
const VEHICLE_MARKER_KINDS = [
    'rail',
    'tram',
    'bus',
];
function vehicleMarkerKind(category) {
    if (category === 'tram')
        return 'tram';
    if (category === 'bus')
        return 'bus';
    return 'rail';
}
function vehicleGlyphTexture(kind) {
    const canvas = document.createElement('canvas');
    canvas.width = 96;
    canvas.height = 96;
    const context = canvas.getContext('2d');
    if (context) {
        context.strokeStyle = 'rgba(255, 255, 255, 0.98)';
        context.fillStyle = 'rgba(255, 255, 255, 1)';
        context.shadowColor = 'rgba(255, 255, 255, 0.75)';
        context.shadowBlur = 7;
        context.lineJoin = 'round';
        context.lineCap = 'round';
        if (kind === 'tram') {
            context.lineWidth = 9;
            context.beginPath();
            context.moveTo(48, 17);
            context.lineTo(76, 48);
            context.lineTo(48, 79);
            context.lineTo(20, 48);
            context.closePath();
            context.stroke();
            context.beginPath();
            context.arc(48, 48, 7, 0, Math.PI * 2);
            context.fill();
        }
        else {
            context.lineWidth = 15;
            context.beginPath();
            context.moveTo(25, 48);
            context.lineTo(71, 48);
            context.stroke();
            context.shadowBlur = 0;
            context.fillStyle = 'rgba(255, 255, 255, 0.72)';
            context.beginPath();
            context.arc(28, 48, 3.5, 0, Math.PI * 2);
            context.arc(68, 48, 3.5, 0, Math.PI * 2);
            context.fill();
        }
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return texture;
}
function SelectedRoute({ train, projectedStops, projectedPaths, color = SERVICE_COLORS[train.category], comparisonLayer, }) {
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const geometry = useMemo(() => {
        const points = [];
        for (let index = 0; index < train.stops.length - 1; index += 1) {
            segmentPoints(train, index, projectedStops, projectedPaths, lakeAvoidingPaths).forEach(([x, , z], pointIndex) => {
                if (index > 0 && pointIndex === 0)
                    return;
                const previous = points.at(-1);
                if (previous && Math.hypot(previous.x - x, previous.z - z) < 0.0001) {
                    return;
                }
                points.push(new THREE.Vector3(x, 0.12, z));
            });
        }
        const line = new THREE.BufferGeometry().setFromPoints(points);
        if (!comparisonLayer || points.length < 2)
            return { line };
        const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal');
        const coreRadius = comparisonLayer === 'foundation' ? 0.045 : 0.022;
        const glowRadius = comparisonLayer === 'foundation' ? 0.15 : 0.085;
        const segments = THREE.MathUtils.clamp(points.length * 2, 32, 720);
        return {
            line,
            core: new THREE.TubeGeometry(curve, segments, coreRadius, 5, false),
            glow: new THREE.TubeGeometry(curve, segments, glowRadius, 5, false),
        };
    }, [comparisonLayer, lakeAvoidingPaths, projectedPaths, projectedStops, train]);
    const material = useMemo(() => {
        const material = new THREE.LineBasicMaterial({
            color,
            transparent: true,
            opacity: 0.95,
            blending: THREE.NormalBlending,
            depthTest: false,
            depthWrite: false,
            toneMapped: false,
        });
        return material;
    }, [color]);
    const line = useMemo(() => new THREE.Line(geometry.line, material), [geometry.line, material]);
    useEffect(() => () => {
        geometry.line.dispose();
        geometry.core?.dispose();
        geometry.glow?.dispose();
        material.dispose();
    }, [geometry, material]);
    return (_jsxs("group", { children: [geometry.glow && (_jsx("mesh", { geometry: geometry.glow, renderOrder: MAP_LAYER.selectionGlow + (comparisonLayer === 'foreground' ? 2 : 0), children: _jsx("meshBasicMaterial", { color: color, transparent: true, opacity: comparisonLayer === 'foundation' ? 0.16 : 0.2, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) })), geometry.core && (_jsx("mesh", { geometry: geometry.core, renderOrder: MAP_LAYER.selectionCore + (comparisonLayer === 'foreground' ? 2 : 0), children: _jsx("meshBasicMaterial", { color: color, transparent: true, opacity: 0.88, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) })), _jsx("primitive", { object: line, renderOrder: MAP_LAYER.selectionCore + (comparisonLayer === 'foreground' ? 3 : 1) })] }));
}
function SelectedLinePaths({ route, snapshot, projectedStops, projectedPaths, color = SERVICE_COLORS[route.category], }) {
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const glowMaterial = useRef(null);
    const stopTextures = useMemo(() => ({
        halo: trainLightTexture('halo'),
        core: trainLightTexture('spark'),
    }), []);
    const geometries = useMemo(() => {
        const trainIds = new Set(route.trainIds);
        const usedEdges = new Set();
        const pathPositions = [];
        for (const train of snapshot.trains) {
            if (!trainIds.has(train.id))
                continue;
            for (let index = 1; index < train.stops.length; index += 1) {
                const firstIndex = train.stops[index - 1][0];
                const secondIndex = train.stops[index][0];
                const pathIndex = train.pathSegments?.[index - 1];
                const key = pathIndex === undefined || pathIndex === null
                    ? firstIndex < secondIndex
                        ? `${firstIndex}:${secondIndex}`
                        : `${secondIndex}:${firstIndex}`
                    : `path:${pathIndex}`;
                if (usedEdges.has(key))
                    continue;
                const points = segmentPoints(train, index - 1, projectedStops, projectedPaths, lakeAvoidingPaths);
                if (points.length < 2)
                    continue;
                usedEdges.add(key);
                appendLineSegments(pathPositions, points, 0.15);
            }
        }
        const stopPositions = route.stopIndexes.flatMap((stopIndex) => {
            const stop = projectedStops[stopIndex];
            return stop ? [stop[0], 0.19, stop[2]] : [];
        });
        const path = new THREE.BufferGeometry();
        path.setAttribute('position', new THREE.Float32BufferAttribute(pathPositions, 3));
        const stops = new THREE.BufferGeometry();
        stops.setAttribute('position', new THREE.Float32BufferAttribute(stopPositions, 3));
        return { path, stops };
    }, [
        projectedPaths,
        projectedStops,
        lakeAvoidingPaths,
        route.stopIndexes,
        route.trainIds,
        snapshot.trains,
    ]);
    useEffect(() => () => {
        geometries.path.dispose();
        geometries.stops.dispose();
    }, [geometries]);
    useEffect(() => () => {
        stopTextures.halo.dispose();
        stopTextures.core.dispose();
    }, [stopTextures]);
    useFrame(({ clock }) => {
        if (!glowMaterial.current)
            return;
        glowMaterial.current.opacity =
            0.12 + (Math.sin(clock.elapsedTime * 1.8) * 0.5 + 0.5) * 0.12;
    });
    return (_jsxs("group", { children: [_jsx("lineSegments", { geometry: geometries.path, renderOrder: MAP_LAYER.selectionCore, children: _jsx("lineBasicMaterial", { color: color, transparent: true, opacity: 0.96, blending: THREE.NormalBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }), _jsx("lineSegments", { geometry: geometries.path, renderOrder: MAP_LAYER.selectionGlow, children: _jsx("lineBasicMaterial", { ref: glowMaterial, color: color, transparent: true, opacity: 0.18, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }), _jsx("points", { geometry: geometries.stops, renderOrder: MAP_LAYER.selectionStopGlow, children: _jsx("pointsMaterial", { color: color, map: stopTextures.halo, size: 5.2, transparent: true, opacity: 0.3, alphaTest: 0.01, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) }), _jsx("points", { geometry: geometries.stops, renderOrder: MAP_LAYER.selectionStopCore, children: _jsx("pointsMaterial", { color: color, map: stopTextures.core, size: 2.1, transparent: true, opacity: 0.9, alphaTest: 0.02, blending: THREE.NormalBlending, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) })] }));
}
function stationCentre(station, projectedStops) {
    const centre = new THREE.Vector3();
    let count = 0;
    station.stopIndexes.forEach((stopIndex) => {
        const stop = projectedStops[stopIndex];
        if (!stop)
            return;
        centre.x += stop[0];
        centre.z += stop[2];
        count += 1;
    });
    if (count)
        centre.multiplyScalar(1 / count);
    return centre;
}
function stationLabelTexture(name, style = 'atlas') {
    const canvas = document.createElement('canvas');
    const measuringContext = canvas.getContext('2d');
    const font = `${style === 'line-map' ? '600 27px' : '500 30px'} "Helvetica Neue", Helvetica, Arial, sans-serif`;
    measuringContext?.save();
    if (measuringContext)
        measuringContext.font = font;
    const measuredWidth = measuringContext?.measureText(name).width ?? name.length * 19;
    measuringContext?.restore();
    canvas.width = Math.ceil(THREE.MathUtils.clamp(measuredWidth + (style === 'line-map' ? 28 : 86), style === 'line-map' ? 100 : 150, 760));
    canvas.height = style === 'line-map' ? 68 : 92;
    const context = canvas.getContext('2d');
    if (context) {
        context.font = font;
        context.textBaseline = 'middle';
        const textX = style === 'line-map' ? 13 : 62;
        const textY = canvas.height / 2;
        context.shadowColor = 'rgba(5, 4, 16, 0.96)';
        context.shadowBlur = style === 'line-map' ? 3 : 10;
        context.lineWidth = style === 'line-map' ? 5 : 7;
        context.strokeStyle = 'rgba(5, 4, 16, 0.96)';
        context.strokeText(name, textX, textY);
        context.fillStyle = '#f8f7ff';
        context.fillText(name, textX, textY);
        if (style === 'atlas') {
            context.beginPath();
            context.arc(31, 46, 6, 0, Math.PI * 2);
            context.fillStyle = '#8dfaff';
            context.shadowColor = '#8dfaff';
            context.shadowBlur = 18;
            context.fill();
        }
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return {
        texture,
        aspect: canvas.width / canvas.height,
        anchorX: style === 'line-map' ? 0 : 31 / canvas.width,
    };
}
function StationTapTarget({ stations, projectedStops, cameraFraming, onSelectStation, }) {
    const { camera, gl } = useThree();
    const rankedStations = useMemo(() => rankStationsForLabels(stations), [stations]);
    useEffect(() => {
        if (!onSelectStation)
            return;
        const element = gl.domElement;
        const activePointers = new Map();
        let multiPointerGesture = false;
        const onPointerDown = (event) => {
            if (event.pointerType === 'mouse' && event.button !== 0)
                return;
            activePointers.set(event.pointerId, {
                x: event.clientX,
                y: event.clientY,
                pointerType: event.pointerType,
            });
            if (activePointers.size > 1)
                multiPointerGesture = true;
            element.setPointerCapture(event.pointerId);
        };
        const finishPointer = (event, cancelled) => {
            const start = activePointers.get(event.pointerId);
            activePointers.delete(event.pointerId);
            const wasMultiPointerGesture = multiPointerGesture;
            if (activePointers.size === 0)
                multiPointerGesture = false;
            if (!start || cancelled || wasMultiPointerGesture)
                return;
            if (Math.hypot(event.clientX - start.x, event.clientY - start.y) > 10) {
                return;
            }
            const semanticHeight = stationLabelCameraHeight(camera.position.y, cameraFraming);
            const rankLimit = Math.min(rankedStations.length, stationLabelRankLimit(semanticHeight));
            const rect = element.getBoundingClientRect();
            const projected = new THREE.Vector3();
            const screenPoints = rankedStations
                .slice(0, rankLimit)
                .flatMap((station, index) => {
                projected.copy(stationCentre(station, projectedStops)).project(camera);
                if (projected.z < -1 ||
                    projected.z > 1 ||
                    projected.x < -1.05 ||
                    projected.x > 1.05 ||
                    projected.y < -1.05 ||
                    projected.y > 1.05) {
                    return [];
                }
                const x = (projected.x * 0.5 + 0.5) * rect.width;
                const y = (-projected.y * 0.5 + 0.5) * rect.height;
                const screenHeight = stationLabelScreenHeight(false, false);
                const labelWidth = stationLabelScreenWidth(stationLabelText(station.name, cameraFraming), screenHeight);
                const labelLeft = x - screenHeight * 0.34;
                return [
                    { index, x, y },
                    { index, x: labelLeft + labelWidth * 0.48, y },
                    { index, x: labelLeft + labelWidth * 0.86, y },
                ];
            });
            const selectedIndex = stationIndexAtScreenPoint(event.clientX - rect.left, event.clientY - rect.top, screenPoints, stationTapRadius(start.pointerType));
            const station = selectedIndex === undefined ? undefined : rankedStations[selectedIndex];
            if (station)
                onSelectStation(station);
        };
        const onPointerUp = (event) => finishPointer(event, false);
        const onPointerCancel = (event) => finishPointer(event, true);
        element.addEventListener('pointerdown', onPointerDown);
        element.addEventListener('pointerup', onPointerUp);
        element.addEventListener('pointercancel', onPointerCancel);
        return () => {
            element.removeEventListener('pointerdown', onPointerDown);
            element.removeEventListener('pointerup', onPointerUp);
            element.removeEventListener('pointercancel', onPointerCancel);
        };
    }, [camera, cameraFraming, gl, onSelectStation, projectedStops, rankedStations]);
    return null;
}
function StationLabels({ stations, snapshot, projectedStops, selectedRoute, selectedStation, selectedTrain, cameraFraming, layoutTransitioning = false, tierLimit, settleSeconds, hidden = false, lineMapMix = 0, }) {
    const { camera, size } = useThree();
    const sprites = useRef([]);
    const textures = useRef(new Map());
    const retainedStationNames = useRef(new Set());
    const previousCameraPosition = useRef(new THREE.Vector3());
    const previousCameraQuaternion = useRef(new THREE.Quaternion());
    const cameraWasSampled = useRef(false);
    const cameraStableSeconds = useRef(Number.POSITIVE_INFINITY);
    const lineMapLabels = lineMapMix >= 0.72;
    const routeStationNames = useMemo(() => {
        const stopIndexes = selectedTrain
            ? selectedTrain.stops.map(([stopIndex]) => stopIndex)
            : (selectedRoute?.stopIndexes ?? []);
        return new Set(stopIndexes
            .map((stopIndex) => snapshot.stops[stopIndex]?.[2])
            .filter((name) => Boolean(name)));
    }, [selectedRoute, selectedTrain, snapshot.stops]);
    const labels = useMemo(() => {
        const ranked = rankStationsForLabels(stations);
        const stationByName = new Map(ranked.map((station) => [station.name, station]));
        const ordered = [];
        const usedNames = new Set();
        const add = (station) => {
            if (!station || usedNames.has(station.name))
                return;
            usedNames.add(station.name);
            ordered.push(station);
        };
        add(selectedStation);
        routeStationNames.forEach((name) => add(stationByName.get(name)));
        ranked.forEach(add);
        return ordered.map((station) => {
            const centre = stationCentre(station, projectedStops);
            return {
                station,
                displayName: stationLabelText(station.name, cameraFraming),
                position: new THREE.Vector3(centre.x, STATION_SURFACE_Y, centre.z),
                rank: ranked.indexOf(station),
                emphasised: station.name === selectedStation?.name || routeStationNames.has(station.name),
            };
        });
    }, [cameraFraming, projectedStops, routeStationNames, selectedStation, stations]);
    useEffect(() => () => {
        textures.current.forEach(({ texture }) => texture.dispose());
        textures.current.clear();
    }, []);
    useEffect(() => {
        retainedStationNames.current.clear();
    }, [
        cameraFraming,
        lineMapLabels,
        selectedRoute,
        selectedStation,
        selectedTrain,
        tierLimit,
    ]);
    useFrame((_, delta) => {
        const semanticHeight = stationLabelCameraHeight(camera.position.y, cameraFraming);
        const cameraMoved = cameraWasSampled.current && (previousCameraPosition.current.distanceToSquared(camera.position) > 0.000025 ||
            1 - Math.abs(previousCameraQuaternion.current.dot(camera.quaternion)) > 0.000001);
        cameraWasSampled.current = true;
        previousCameraPosition.current.copy(camera.position);
        previousCameraQuaternion.current.copy(camera.quaternion);
        cameraStableSeconds.current = cameraMoved
            ? 0
            : cameraStableSeconds.current + delta;
        const canRepopulate = stationLabelsCanRepopulate(cameraStableSeconds.current, settleSeconds);
        const budget = stableStationLabelBudget(stationLabelBudget(semanticHeight), retainedStationNames.current.size, canRepopulate);
        const rankLimit = stationLabelRankLimit(semanticHeight);
        const projected = new THREE.Vector3();
        const viewPosition = new THREE.Vector3();
        const candidates = [];
        sprites.current.forEach((sprite) => {
            if (sprite)
                sprite.visible = false;
        });
        if (hidden) {
            retainedStationNames.current.clear();
            return;
        }
        labels.forEach((label, index) => {
            const retained = retainedStationNames.current.has(label.station.name);
            if ((selectedTrain || selectedRoute) && !label.emphasised)
                return;
            if (!label.emphasised &&
                !stationLabelWithinTier(label.station.labelRank, tierLimit))
                return;
            if (layoutTransitioning && !label.emphasised && !retained)
                return;
            if (!label.emphasised && !retained && !canRepopulate)
                return;
            if (!label.emphasised &&
                (label.rank < 0 || label.rank >= rankLimit) &&
                (canRepopulate || !retained))
                return;
            viewPosition.copy(label.position).applyMatrix4(camera.matrixWorldInverse);
            projected.copy(label.position).project(camera);
            if (projected.z < -1 ||
                projected.z > 1 ||
                projected.x < -1.08 ||
                projected.x > 1.08 ||
                projected.y < -1.08 ||
                projected.y > 1.08) {
                return;
            }
            candidates.push({
                index,
                x: (projected.x * 0.5 + 0.5) * size.width,
                y: (-projected.y * 0.5 + 0.5) * size.height,
                distance: camera.position.distanceTo(label.position),
                depth: Math.max(0.01, -viewPosition.z),
                priority: label.station.name === selectedStation?.name ? 0 : label.emphasised ? 1 : 2,
                rank: label.rank,
                retained,
            });
        });
        candidates.sort((first, second) => compareStationLabelCandidates({
            name: labels[first.index].station.name,
            rank: first.rank,
            priority: first.priority,
            retained: first.retained,
            distance: first.distance,
        }, {
            name: labels[second.index].station.name,
            rank: second.rank,
            priority: second.priority,
            retained: second.retained,
            distance: second.distance,
        }));
        const occupied = [];
        const visibleTextureNames = new Set();
        const nextRetainedStationNames = new Set();
        const verticalFieldOfView = camera instanceof THREE.PerspectiveCamera ? camera.fov : 44;
        let visible = 0;
        for (const candidate of candidates) {
            if (visible >= budget || visible >= MAX_STATION_LABELS)
                break;
            const label = labels[candidate.index];
            const selected = label.station.name === selectedStation?.name;
            const screenHeight = stationLabelScreenHeight(selected, label.emphasised, label.station.labelRank);
            const width = stationLabelScreenWidth(label.displayName, screenHeight);
            const labelLeft = lineMapLabels
                ? candidate.x + 3
                : candidate.x - screenHeight * 0.34;
            const box = {
                left: labelLeft,
                right: labelLeft + width,
                top: candidate.y - screenHeight * 0.5,
                bottom: candidate.y + screenHeight * 0.5,
            };
            const overlaps = occupied.some((other) => box.left < other.right + 5 &&
                box.right > other.left - 5 &&
                box.top < other.bottom + 4 &&
                box.bottom > other.top - 4);
            if (overlaps)
                continue;
            const sprite = sprites.current[visible];
            if (!sprite)
                continue;
            const textureKey = `${lineMapLabels ? 'line-map' : 'atlas'}:${label.station.name}`;
            let textureEntry = textures.current.get(textureKey);
            if (!textureEntry) {
                textureEntry = stationLabelTexture(label.displayName, lineMapLabels ? 'line-map' : 'atlas');
                textures.current.set(textureKey, textureEntry);
            }
            else {
                textures.current.delete(textureKey);
                textures.current.set(textureKey, textureEntry);
            }
            visibleTextureNames.add(textureKey);
            nextRetainedStationNames.add(label.station.name);
            sprite.visible = true;
            sprite.position.copy(label.position);
            sprite.center.set(textureEntry.anchorX, 0.5);
            const worldHeight = stationLabelWorldHeight(candidate.depth, verticalFieldOfView, size.height, screenHeight);
            sprite.scale.set(textureEntry.aspect * worldHeight, worldHeight, 1);
            const material = sprite.material;
            if (material.map !== textureEntry.texture) {
                material.map = textureEntry.texture;
                material.needsUpdate = true;
            }
            material.opacity = stationLabelOpacity(selected, label.emphasised, label.station.labelRank);
            occupied.push(box);
            visible += 1;
        }
        if (!layoutTransitioning) {
            retainedStationNames.current = nextRetainedStationNames;
        }
        if (textures.current.size > 192) {
            for (const [name, entry] of textures.current) {
                if (visibleTextureNames.has(name))
                    continue;
                entry.texture.dispose();
                textures.current.delete(name);
                if (textures.current.size <= 192)
                    break;
            }
        }
    });
    return (_jsx(_Fragment, { children: Array.from({ length: MAX_STATION_LABELS }, (_, index) => (_jsx("sprite", { ref: (sprite) => {
                sprites.current[index] = sprite;
            }, visible: false, renderOrder: MAP_LAYER.stationLabel, children: _jsx("spriteMaterial", { transparent: true, opacity: 0, depthTest: false, depthWrite: false, toneMapped: false }) }, index))) }));
}
function createTrainLabelTexture(label, color) {
    const canvas = document.createElement('canvas');
    const measuringContext = canvas.getContext('2d');
    const font = '500 27px "DM Mono", monospace';
    if (measuringContext)
        measuringContext.font = font;
    const measuredWidth = measuringContext?.measureText(label).width ?? label.length * 17;
    canvas.width = Math.ceil(THREE.MathUtils.clamp(measuredWidth + 88, 190, 720));
    canvas.height = 74;
    const context = canvas.getContext('2d');
    if (context) {
        context.fillStyle = 'rgba(5, 4, 16, 0.82)';
        context.beginPath();
        context.roundRect(5, 6, canvas.width - 10, canvas.height - 12, 10);
        context.fill();
        context.strokeStyle = 'rgba(193, 204, 255, 0.35)';
        context.lineWidth = 2;
        context.stroke();
        context.beginPath();
        context.arc(31, 37, 6, 0, Math.PI * 2);
        context.fillStyle = color;
        context.shadowColor = color;
        context.shadowBlur = 15;
        context.fill();
        context.font = font;
        context.textBaseline = 'middle';
        context.shadowColor = 'rgba(5, 4, 16, 0.95)';
        context.shadowBlur = 7;
        context.fillStyle = '#f8f7ff';
        context.fillText(label, 56, 38);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    texture.generateMipmaps = false;
    return { texture, aspect: canvas.width / canvas.height };
}
function trainLabelText(train, selected, compared = false) {
    const identity = trainLabelIdentity(train.route, train.shortName);
    const delay = train.realtime?.delaySeconds;
    const realtimeSuffix = train.realtime?.status === 'adjusted' && delay
        ? ` · ${delay > 0 ? '+' : '−'}${Math.round(Math.abs(delay) / 60)}′`
        : '';
    if (compared) {
        const comparisonIdentity = [train.shortName, train.servicePattern?.toUpperCase()]
            .filter(Boolean)
            .join(' · ');
        return `${comparisonIdentity || train.route}${realtimeSuffix} → ${train.headsign}`;
    }
    return selected
        ? `${identity}${realtimeSuffix} → ${train.headsign}`
        : `${identity}${realtimeSuffix}`;
}
function TrainLabels({ snapshot, projectedStops, projectedPaths, selectedTrain, comparisonTrains, selectedRoute, selectedStation, selectedCategory, airCategorySelected, roadCategorySelected, trainLabelMode, isPlaying, time, playbackRate, trainTimeIndex, cameraFraming, layoutTransitioning = false, routeColors, spatialLayoutMix = 0, routeColorMix = spatialLayoutMix, }) {
    const { camera, size } = useThree();
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const sprites = useRef([]);
    const textures = useRef(new Map());
    const retainedTrainIds = useRef(new Set());
    const localTime = useRef(time);
    const selectedStationTrainIds = useMemo(() => new Set(selectedStation?.trainIds ?? []), [selectedStation]);
    const selectedRouteTrainIds = useMemo(() => new Set(selectedRoute?.trainIds ?? []), [selectedRoute]);
    const comparisonTrainIds = useMemo(() => new Set(comparisonTrains?.map((train) => train.id) ?? []), [comparisonTrains]);
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useEffect(() => () => {
        textures.current.forEach(({ texture }) => texture.dispose());
        textures.current.clear();
    }, []);
    useFrame((_, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
            if (localTime.current > snapshot.metadata.windowEnd) {
                localTime.current = snapshot.metadata.windowStart;
            }
        }
        sprites.current.forEach((sprite) => {
            if (sprite)
                sprite.visible = false;
        });
        const semanticCameraHeight = regionalCameraHeight(camera.position.y, cameraFraming);
        const labelBudget = nonRailCategorySuppressesTrainLabels(airCategorySelected, roadCategorySelected)
            ? 0
            : comparisonTrains?.length
                ? trainLabelMode === 'off'
                    ? 0
                    : comparisonTrains.length
                : selectedTrain
                    ? trainLabelMode === 'off'
                        ? 0
                        : 1
                    : trainLabelBudget(semanticCameraHeight, trainLabelMode);
        if (!labelBudget) {
            retainedTrainIds.current.clear();
            return;
        }
        const projected = new THREE.Vector3();
        const viewPosition = new THREE.Vector3();
        const candidates = [];
        for (const train of trainsNearTime(trainTimeIndex, localTime.current)) {
            const selected = train.id === selectedTrain?.id || comparisonTrainIds.has(train.id);
            const retained = retainedTrainIds.current.has(train.id);
            if (comparisonTrains?.length && !selected)
                continue;
            if (selectedTrain && !selected)
                continue;
            if (layoutTransitioning && !selected && !retained)
                continue;
            if (selectedRoute && !selectedRouteTrainIds.has(train.id))
                continue;
            if (!selected && selectedStation && !selectedStationTrainIds.has(train.id))
                continue;
            if (!selected && selectedCategory && train.category !== selectedCategory)
                continue;
            const focused = Boolean(selected || selectedRoute || selectedStation || selectedCategory);
            if (!vehicleIsVisibleAtZoom(train.category, camera.position.y, cameraFraming, focused)) {
                continue;
            }
            if (!selected &&
                !focused &&
                !selectedCategory &&
                trainLabelMode === 'auto' &&
                !categoryIsVisibleInAutoMode(train.category, semanticCameraHeight)) {
                continue;
            }
            const arrivalOpacity = trainLabelArrivalOpacity(localTime.current, train.end, playbackRate);
            if (arrivalOpacity <= 0)
                continue;
            const position = projectedTrainPosition(train, Math.min(localTime.current, train.end), projectedStops, projectedPaths, lakeAvoidingPaths);
            if (!position)
                continue;
            projected.set(position[0], 0.76, position[2]);
            viewPosition.copy(projected).applyMatrix4(camera.matrixWorldInverse);
            projected.project(camera);
            if (projected.z < -1 ||
                projected.z > 1 ||
                projected.x < -1.08 ||
                projected.x > 1.08 ||
                projected.y < -1.08 ||
                projected.y > 1.08) {
                continue;
            }
            candidates.push({
                train,
                position,
                x: (projected.x * 0.5 + 0.5) * size.width,
                y: (-projected.y * 0.5 + 0.5) * size.height,
                depth: Math.max(0.01, -viewPosition.z),
                selected,
                retained,
                arrivalOpacity,
                comparisonIndex: comparisonTrains?.findIndex((candidate) => candidate.id === train.id) ?? -1,
            });
        }
        candidates.sort((first, second) => Number(second.selected) - Number(first.selected) ||
            compareTrainLabelCandidates({
                id: first.train.id,
                category: first.train.category,
                retained: first.retained,
            }, {
                id: second.train.id,
                category: second.train.category,
                retained: second.retained,
            }));
        const occupied = [];
        const visibleTextureKeys = new Set();
        const nextRetainedTrainIds = new Set();
        const verticalFieldOfView = camera instanceof THREE.PerspectiveCamera ? camera.fov : 44;
        let visible = 0;
        for (const candidate of candidates) {
            if (visible >= labelBudget || visible >= MAX_TRAIN_LABELS)
                break;
            const text = trainLabelText(candidate.train, candidate.selected, candidate.comparisonIndex >= 0);
            const screenHeight = trainLabelScreenHeight(size.width, candidate.selected, semanticCameraHeight);
            const width = trainLabelScreenWidth(text, screenHeight);
            const box = {
                left: candidate.x - width / 2,
                right: candidate.x + width / 2,
                top: candidate.y - screenHeight / 2,
                bottom: candidate.y + screenHeight / 2,
            };
            const overlaps = occupied.some((other) => box.left < other.right + 5 &&
                box.right > other.left - 5 &&
                box.top < other.bottom + 4 &&
                box.bottom > other.top - 4);
            if (overlaps && !candidate.selected)
                continue;
            const sprite = sprites.current[visible];
            if (!sprite)
                continue;
            const textureKey = `${candidate.train.category}:${text}`;
            let textureEntry = textures.current.get(textureKey);
            if (!textureEntry) {
                textureEntry = createTrainLabelTexture(text, mixedRouteColor(candidate.train.category, candidate.train.route, routeColors, routeColorMix));
                textures.current.set(textureKey, textureEntry);
            }
            else {
                textures.current.delete(textureKey);
                textures.current.set(textureKey, textureEntry);
            }
            visibleTextureKeys.add(textureKey);
            nextRetainedTrainIds.add(candidate.train.id);
            sprite.visible = true;
            const comparisonOffset = candidate.comparisonIndex < 0
                ? 0
                : candidate.comparisonIndex === 0
                    ? -0.22
                    : 0.22;
            sprite.position.set(candidate.position[0], 0.76 + comparisonOffset, candidate.position[2]);
            const worldHeight = stationLabelWorldHeight(candidate.depth, verticalFieldOfView, size.height, screenHeight);
            sprite.scale.set(textureEntry.aspect * worldHeight, worldHeight, 1);
            const material = sprite.material;
            if (material.map !== textureEntry.texture) {
                material.map = textureEntry.texture;
                material.needsUpdate = true;
            }
            material.opacity = (candidate.selected ? 1 : 0.9) * candidate.arrivalOpacity;
            occupied.push(box);
            visible += 1;
        }
        if (!layoutTransitioning) {
            retainedTrainIds.current = nextRetainedTrainIds;
        }
        if (textures.current.size > 180) {
            for (const [key, entry] of textures.current) {
                if (visibleTextureKeys.has(key))
                    continue;
                entry.texture.dispose();
                textures.current.delete(key);
                if (textures.current.size <= 180)
                    break;
            }
        }
    });
    return (_jsx(_Fragment, { children: Array.from({ length: MAX_TRAIN_LABELS }, (_, index) => (_jsx("sprite", { ref: (sprite) => {
                sprites.current[index] = sprite;
            }, visible: false, renderOrder: MAP_LAYER.trainLabel, children: _jsx("spriteMaterial", { transparent: true, opacity: 0, depthTest: false, depthWrite: false, toneMapped: false }) }, index))) }));
}
function SelectedStationRouteLayer({ category, pathGeometry, stopGeometry, haloTexture, coreTexture, }) {
    const glowMaterial = useRef(null);
    useFrame(({ clock }) => {
        if (!glowMaterial.current)
            return;
        const pulse = Math.sin(clock.elapsedTime * 1.55) * 0.5 + 0.5;
        glowMaterial.current.opacity = 0.18 + pulse * 0.13;
    });
    const color = SERVICE_COLORS[category];
    return (_jsxs("group", { children: [_jsx("lineSegments", { geometry: pathGeometry, renderOrder: MAP_LAYER.selectionCore, children: _jsx("lineBasicMaterial", { color: color, transparent: true, opacity: 1, blending: THREE.NormalBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }), _jsx("lineSegments", { geometry: pathGeometry, renderOrder: MAP_LAYER.selectionGlow, children: _jsx("lineBasicMaterial", { ref: glowMaterial, color: "#ffffff", transparent: true, opacity: 0.24, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false }) }), _jsx("points", { geometry: stopGeometry, renderOrder: MAP_LAYER.selectionStopGlow, children: _jsx("pointsMaterial", { color: color, map: haloTexture, size: 4.2, transparent: true, opacity: 0.36, alphaTest: 0.01, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) }), _jsx("points", { geometry: stopGeometry, renderOrder: MAP_LAYER.selectionStopCore, children: _jsx("pointsMaterial", { color: "#ffffff", map: coreTexture, size: 1.7, transparent: true, opacity: 0.88, alphaTest: 0.02, blending: THREE.NormalBlending, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) })] }));
}
function SelectedStationPulse({ centre }) {
    const meshes = useRef([]);
    const materials = useRef([]);
    const origin = useMemo(() => new THREE.Vector3(centre.x, 0.29, centre.z), [centre]);
    useFrame(({ camera, clock, size }) => {
        if (!(camera instanceof THREE.PerspectiveCamera) || size.height <= 0)
            return;
        const distance = camera.position.distanceTo(origin);
        const visibleWorldHeight = 2 * distance * Math.tan(THREE.MathUtils.degToRad(camera.fov * 0.5));
        const worldUnitsPerPixel = visibleWorldHeight / size.height;
        for (let index = 0; index < STATION_SELECTION_PULSE_COUNT; index += 1) {
            const mesh = meshes.current[index];
            const material = materials.current[index];
            if (!mesh || !material)
                continue;
            const frame = stationSelectionPulseFrame(clock.elapsedTime, index);
            mesh.scale.setScalar(frame.radiusPixels * worldUnitsPerPixel);
            material.opacity = frame.opacity;
        }
    });
    return (_jsx("group", { position: origin, children: Array.from({ length: STATION_SELECTION_PULSE_COUNT }, (_, index) => (_jsxs("mesh", { ref: (mesh) => {
                meshes.current[index] = mesh;
            }, rotation: [Math.PI / 2, 0, 0], renderOrder: MAP_LAYER.focusMarkerGlow, children: [_jsx("torusGeometry", { args: [1, 0.026, 6, 72] }), _jsx("meshBasicMaterial", { ref: (material) => {
                        materials.current[index] = material;
                    }, color: "#8dfaff", transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false, fog: false })] }, index))) }));
}
function SelectedStationRoutes({ station, snapshot, projectedStops, projectedPaths, selectedCategory, }) {
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const textures = useMemo(() => ({
        halo: trainLightTexture('halo'),
        core: trainLightTexture('spark'),
    }), []);
    const lines = useMemo(() => {
        const trainIds = new Set(station.trainIds);
        const pathsByCategory = new Map();
        const stopsByCategory = new Map();
        for (const train of snapshot.trains) {
            if (!trainIds.has(train.id))
                continue;
            if (selectedCategory && train.category !== selectedCategory)
                continue;
            const categoryPaths = pathsByCategory.get(train.category) ?? new Map();
            const categoryStops = stopsByCategory.get(train.category) ?? new Set();
            train.stops.forEach(([stopIndex]) => categoryStops.add(stopIndex));
            for (let index = 1; index < train.stops.length; index += 1) {
                const firstIndex = train.stops[index - 1][0];
                const secondIndex = train.stops[index][0];
                const pathIndex = train.pathSegments?.[index - 1];
                const key = pathIndex === undefined || pathIndex === null
                    ? firstIndex < secondIndex
                        ? `${firstIndex}:${secondIndex}`
                        : `${secondIndex}:${firstIndex}`
                    : `path:${pathIndex}`;
                if (categoryPaths.has(key))
                    continue;
                const points = segmentPoints(train, index - 1, projectedStops, projectedPaths, lakeAvoidingPaths);
                if (points.length < 2)
                    continue;
                const positions = [];
                appendLineSegments(positions, points, 0.14);
                categoryPaths.set(key, positions);
            }
            pathsByCategory.set(train.category, categoryPaths);
            stopsByCategory.set(train.category, categoryStops);
        }
        return [...pathsByCategory.entries()].map(([category, paths]) => {
            const pathGeometry = new THREE.BufferGeometry();
            pathGeometry.setAttribute('position', new THREE.Float32BufferAttribute([...paths.values()].flat(), 3));
            const stopPositions = [...(stopsByCategory.get(category) ?? [])].flatMap((stopIndex) => {
                const stop = projectedStops[stopIndex];
                return stop ? [stop[0], 0.2, stop[2]] : [];
            });
            const stopGeometry = new THREE.BufferGeometry();
            stopGeometry.setAttribute('position', new THREE.Float32BufferAttribute(stopPositions, 3));
            return { category, pathGeometry, stopGeometry };
        });
    }, [
        projectedPaths,
        projectedStops,
        lakeAvoidingPaths,
        selectedCategory,
        snapshot.trains,
        station.trainIds,
    ]);
    useEffect(() => () => lines.forEach(({ pathGeometry, stopGeometry }) => {
        pathGeometry.dispose();
        stopGeometry.dispose();
    }), [lines]);
    useEffect(() => () => {
        textures.halo.dispose();
        textures.core.dispose();
    }, [textures]);
    const centre = useMemo(() => stationCentre(station, projectedStops), [projectedStops, station]);
    const centreGeometry = useMemo(() => {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute([centre.x, 0.3, centre.z], 3));
        return geometry;
    }, [centre]);
    useEffect(() => () => centreGeometry.dispose(), [centreGeometry]);
    return (_jsxs(_Fragment, { children: [lines.map(({ category, pathGeometry, stopGeometry }) => (_jsx(SelectedStationRouteLayer, { category: category, pathGeometry: pathGeometry, stopGeometry: stopGeometry, haloTexture: textures.halo, coreTexture: textures.core }, category))), _jsx(SelectedStationPulse, { centre: centre }), _jsx("points", { geometry: centreGeometry, renderOrder: MAP_LAYER.focusMarkerGlow, children: _jsx("pointsMaterial", { color: "#8dfaff", map: textures.halo, size: 25, transparent: true, opacity: 0.78, alphaTest: 0.01, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) }), _jsx("points", { geometry: centreGeometry, renderOrder: MAP_LAYER.focusMarkerCore, children: _jsx("pointsMaterial", { color: "#ffffff", map: textures.core, size: 5.4, transparent: true, opacity: 1, alphaTest: 0.02, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, sizeAttenuation: false, toneMapped: false, fog: false }) }), _jsxs("group", { position: [centre.x, 0.28, centre.z], children: [_jsxs("mesh", { rotation: [Math.PI / 2, 0, 0], children: [_jsx("torusGeometry", { args: [0.48, 0.055, 8, 48] }), _jsx("meshBasicMaterial", { color: "#ffffff", blending: THREE.AdditiveBlending })] }), _jsxs("mesh", { children: [_jsx("sphereGeometry", { args: [0.14, 12, 12] }), _jsx("meshStandardMaterial", { color: "#ffffff", emissive: "#8dfaff", emissiveIntensity: 5 })] }), _jsx("pointLight", { color: "#8dfaff", intensity: 7, distance: 5 })] })] }));
}
function TrainSwarm({ snapshot, projectedStops, projectedPaths, selectedTrain, comparisonTrains, selectedRoute, isPlaying, time, onTime, playbackRate, selectedCategory, airCategorySelected, selectedStation, trainTimeIndex, cameraFraming, routeColors, spatialLayoutMix = 0, routeColorMix = spatialLayoutMix, }) {
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const points = useRef(null);
    const glow = useRef(null);
    const localTime = useRef(time);
    const lastReport = useRef(0);
    const selectedStationTrainIds = useMemo(() => new Set(selectedStation?.trainIds ?? []), [selectedStation]);
    const selectedRouteTrainIds = useMemo(() => new Set(selectedRoute?.trainIds ?? []), [selectedRoute]);
    const comparisonTrainIds = useMemo(() => new Set(comparisonTrains?.map((train) => train.id) ?? []), [comparisonTrains]);
    const lightTextures = useMemo(() => ({
        halo: trainLightTexture('halo'),
        orb: trainLightTexture('orb'),
        spark: trainLightTexture('spark'),
        realtime: realtimeRingTexture(),
        tram: vehicleGlyphTexture('tram'),
        bus: vehicleGlyphTexture('bus'),
    }), []);
    const palette = useMemo(() => Object.fromEntries(Object.entries(SERVICE_COLORS).map(([category, color]) => [
        category,
        new THREE.Color(color),
    ])), []);
    const trainPalette = useMemo(() => new Map(snapshot.trains.map((train) => [
        train.id,
        new THREE.Color(mixedRouteColor(train.category, train.route, routeColors, routeColorMix)),
    ])), [routeColorMix, routeColors, snapshot.trains]);
    const geometries = useMemo(() => {
        const categoryCounts = {
            rail: 0,
            tram: 0,
            bus: 0,
        };
        snapshot.trains.forEach((train) => {
            categoryCounts[vehicleMarkerKind(train.category)] += 1;
        });
        return Object.fromEntries(VEHICLE_MARKER_KINDS.map((kind) => {
            const geometry = new THREE.BufferGeometry();
            const length = categoryCounts[kind] * 3;
            geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(length), 3));
            geometry.setAttribute('color', new THREE.BufferAttribute(new Float32Array(length), 3));
            geometry.setDrawRange(0, 0);
            return [kind, geometry];
        }));
    }, [snapshot.trains]);
    const realtimeGeometry = useMemo(() => {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(snapshot.trains.length * 3), 3));
        geometry.setDrawRange(0, 0);
        return geometry;
    }, [snapshot.trains]);
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useEffect(() => () => {
        lightTextures.halo.dispose();
        lightTextures.orb.dispose();
        lightTextures.spark.dispose();
        lightTextures.realtime.dispose();
        lightTextures.tram.dispose();
        lightTextures.bus.dispose();
    }, [lightTextures]);
    useEffect(() => () => {
        Object.values(geometries).forEach((geometry) => geometry.dispose());
        realtimeGeometry.dispose();
    }, [geometries, realtimeGeometry]);
    useFrame((state, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
            if (localTime.current > snapshot.metadata.windowEnd) {
                localTime.current = snapshot.metadata.windowStart;
            }
        }
        const activeCounts = {
            rail: 0,
            tram: 0,
            bus: 0,
        };
        let activeRealtimeCount = 0;
        for (const train of trainsNearTime(trainTimeIndex, localTime.current)) {
            const focused = Boolean(selectedTrain?.id === train.id ||
                comparisonTrainIds.has(train.id) ||
                (selectedRoute && selectedRouteTrainIds.has(train.id)) ||
                (selectedStation && selectedStationTrainIds.has(train.id)) ||
                selectedCategory === train.category);
            if (!vehicleIsVisibleAtZoom(train.category, state.camera.position.y, cameraFraming, focused)) {
                continue;
            }
            const position = projectedTrainPosition(train, localTime.current, projectedStops, projectedPaths, lakeAvoidingPaths);
            if (!position)
                continue;
            const markerKind = vehicleMarkerKind(train.category);
            const mutableGeometry = geometries[markerKind];
            const positionAttribute = mutableGeometry.getAttribute('position');
            const colorAttribute = mutableGeometry.getAttribute('color');
            const mutablePositions = positionAttribute.array;
            const mutableColors = colorAttribute.array;
            const offset = activeCounts[markerKind] * 3;
            mutablePositions.set(position, offset);
            const color = trainPalette.get(train.id) ?? palette[train.category] ?? palette.other;
            const stationIncludesTrain = !selectedStation || selectedStationTrainIds.has(train.id);
            const categoryIncludesTrain = !selectedCategory || selectedCategory === train.category;
            const routeIncludesTrain = !selectedRoute || selectedRouteTrainIds.has(train.id);
            const intensity = airCategorySelected
                ? 0.025
                : comparisonTrains?.length
                    ? comparisonTrainIds.has(train.id)
                        ? 1
                        : 0.025
                    : selectedTrain
                        ? selectedTrain.id === train.id
                            ? 1
                            : 0.025
                        : !stationIncludesTrain || !categoryIncludesTrain || !routeIncludesTrain
                            ? 0.025
                            : 1;
            mutableColors[offset] = color.r * intensity;
            mutableColors[offset + 1] = color.g * intensity;
            mutableColors[offset + 2] = color.b * intensity;
            activeCounts[markerKind] += 1;
            if (train.realtime?.status === 'adjusted' || train.operations) {
                const realtimePositions = realtimeGeometry.getAttribute('position')
                    .array;
                realtimePositions.set(position, activeRealtimeCount * 3);
                activeRealtimeCount += 1;
            }
        }
        VEHICLE_MARKER_KINDS.forEach((kind) => {
            const mutableGeometry = geometries[kind];
            mutableGeometry.getAttribute('position').needsUpdate = true;
            mutableGeometry.getAttribute('color').needsUpdate = true;
            mutableGeometry.setDrawRange(0, activeCounts[kind]);
        });
        realtimeGeometry.getAttribute('position').needsUpdate = true;
        realtimeGeometry.setDrawRange(0, activeRealtimeCount);
        if (points.current)
            points.current.frustumCulled = false;
        if (glow.current)
            glow.current.frustumCulled = false;
        // A paused scene follows the consumer's clock, including in linked views.
        if (isPlaying && state.clock.elapsedTime - lastReport.current > 0.1) {
            lastReport.current = state.clock.elapsedTime;
            onTime(localTime.current);
        }
    });
    return (_jsxs(_Fragment, { children: [VEHICLE_MARKER_KINDS.map((kind) => {
                const isCityVehicle = kind === 'tram' || kind === 'bus';
                const glyphTexture = kind === 'tram'
                    ? lightTextures.tram
                    : kind === 'bus'
                        ? lightTextures.bus
                        : lightTextures.orb;
                return (_jsxs("group", { children: [_jsx("points", { ref: kind === 'rail' ? glow : undefined, geometry: geometries[kind], frustumCulled: false, renderOrder: MAP_LAYER.vehicleGlow, children: _jsx("pointsMaterial", { vertexColors: true, map: lightTextures.halo, size: isCityVehicle ? 7.5 : 9, transparent: true, opacity: selectedTrain ||
                                    selectedRoute ||
                                    selectedCategory ||
                                    selectedStation ||
                                    airCategorySelected
                                    ? 0.055
                                    : isCityVehicle
                                        ? 0.11
                                        : 0.15, alphaTest: 0.005, depthTest: false, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: false, toneMapped: false }) }), _jsx("points", { ref: kind === 'rail' ? points : undefined, geometry: geometries[kind], frustumCulled: false, renderOrder: MAP_LAYER.vehicleCore, children: _jsx("pointsMaterial", { vertexColors: true, map: glyphTexture, size: kind === 'rail' ? 4.6 : 6.2, transparent: true, opacity: isCityVehicle ? 0.95 : 0.9, alphaTest: 0.035, depthTest: false, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: false, toneMapped: false }) }), kind === 'rail' && (_jsx("points", { geometry: geometries[kind], frustumCulled: false, renderOrder: MAP_LAYER.vehicleSpark, children: _jsx("pointsMaterial", { vertexColors: true, map: lightTextures.spark, size: 1.8, transparent: true, opacity: 1, alphaTest: 0.025, depthTest: false, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: false, toneMapped: false }) }))] }, kind));
            }), _jsx("points", { geometry: realtimeGeometry, frustumCulled: false, renderOrder: MAP_LAYER.focusMarkerGlow, children: _jsx("pointsMaterial", { color: "#8dfaff", map: lightTextures.realtime, size: 10, transparent: true, opacity: 0.9, alphaTest: 0.02, depthTest: false, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: false, toneMapped: false }) })] }));
}
function VehicleTrails({ snapshot, projectedStops, projectedPaths, selectedTrain, comparisonTrains, selectedRoute, selectedCategory, airCategorySelected, selectedStation, isPlaying, time, playbackRate, trainTimeIndex, cameraFraming, routeColors, spatialLayoutMix = 0, routeColorMix = spatialLayoutMix, }) {
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const localTime = useRef(time);
    const lastUpdate = useRef(-1);
    const selectedStationTrainIds = useMemo(() => new Set(selectedStation?.trainIds ?? []), [selectedStation]);
    const selectedRouteTrainIds = useMemo(() => new Set(selectedRoute?.trainIds ?? []), [selectedRoute]);
    const comparisonTrainIds = useMemo(() => new Set(comparisonTrains?.map((train) => train.id) ?? []), [comparisonTrains]);
    const palette = useMemo(() => Object.fromEntries(Object.entries(SERVICE_COLORS).map(([category, color]) => [
        category,
        new THREE.Color(color),
    ])), []);
    const trainPalette = useMemo(() => new Map(snapshot.trains.map((train) => [
        train.id,
        new THREE.Color(mixedRouteColor(train.category, train.route, routeColors, routeColorMix)),
    ])), [routeColorMix, routeColors, snapshot.trains]);
    const geometries = useMemo(() => Array.from({ length: VEHICLE_TRAIL_SEGMENTS }, () => {
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(snapshot.trains.length * 6), 3));
        geometry.setAttribute('color', new THREE.BufferAttribute(new Float32Array(snapshot.trains.length * 6), 3));
        geometry.setDrawRange(0, 0);
        return geometry;
    }), [snapshot.trains.length]);
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useEffect(() => () => {
        geometries.forEach((geometry) => geometry.dispose());
    }, [geometries]);
    useFrame(({ clock, camera }, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
            if (localTime.current > snapshot.metadata.windowEnd) {
                localTime.current = snapshot.metadata.windowStart;
            }
        }
        if (clock.elapsedTime - lastUpdate.current < 1 / 30)
            return;
        lastUpdate.current = clock.elapsedTime;
        const sampleTimes = vehicleTrailSampleTimes(localTime.current);
        const segmentCounts = new Array(VEHICLE_TRAIL_SEGMENTS).fill(0);
        const positionArrays = geometries.map((geometry) => geometry.getAttribute('position').array);
        const colorArrays = geometries.map((geometry) => geometry.getAttribute('color').array);
        for (const train of trainsNearTime(trainTimeIndex, localTime.current)) {
            if (airCategorySelected)
                continue;
            if (comparisonTrains?.length && !comparisonTrainIds.has(train.id))
                continue;
            if (selectedTrain && train.id !== selectedTrain.id)
                continue;
            if (selectedRoute && !selectedRouteTrainIds.has(train.id))
                continue;
            if (selectedCategory && train.category !== selectedCategory)
                continue;
            if (selectedStation && !selectedStationTrainIds.has(train.id))
                continue;
            if (!vehicleIsVisibleAtZoom(train.category, camera.position.y, cameraFraming, Boolean(selectedTrain || selectedRoute || selectedCategory || selectedStation))) {
                continue;
            }
            const samples = sampleTimes.map((sampleTime) => projectedTrainPosition(train, sampleTime, projectedStops, projectedPaths, lakeAvoidingPaths));
            const color = trainPalette.get(train.id) ?? palette[train.category] ?? palette.other;
            for (let index = 0; index < VEHICLE_TRAIL_SEGMENTS; index += 1) {
                const current = samples[index];
                const previous = samples[index + 1];
                if (!current || !previous)
                    continue;
                const distanceSquared = (current[0] - previous[0]) ** 2 +
                    (current[2] - previous[2]) ** 2;
                if (distanceSquared < 0.000001)
                    continue;
                const offset = segmentCounts[index] * 6;
                positionArrays[index].set(current, offset);
                positionArrays[index].set(previous, offset + 3);
                colorArrays[index].set([color.r, color.g, color.b, color.r, color.g, color.b], offset);
                segmentCounts[index] += 1;
            }
        }
        geometries.forEach((geometry, index) => {
            geometry.getAttribute('position').needsUpdate = true;
            geometry.getAttribute('color').needsUpdate = true;
            geometry.setDrawRange(0, segmentCounts[index] * 2);
        });
    });
    const opacity = [0.4, 0.22, 0.1];
    return (_jsx("group", { position: [0, -0.035, 0], children: geometries.map((geometry, index) => (_jsx("lineSegments", { geometry: geometry, frustumCulled: false, renderOrder: 3 + index, children: _jsx("lineBasicMaterial", { vertexColors: true, transparent: true, opacity: opacity[index], blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }) }, index))) }));
}
function SelectedTrainMarker({ train, time, projectedStops, projectedPaths, color = SERVICE_COLORS[train.category], }) {
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const marker = useRef(null);
    useFrame((state) => {
        if (!marker.current)
            return;
        const position = projectedTrainPosition(train, time, projectedStops, projectedPaths, lakeAvoidingPaths);
        marker.current.visible = Boolean(position);
        if (!position)
            return;
        marker.current.position.set(...position);
        const pulse = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.12;
        marker.current.scale.setScalar(pulse);
    });
    return (_jsxs("group", { ref: marker, children: [_jsxs("mesh", { renderOrder: MAP_LAYER.focusMarkerCore, children: [_jsx("sphereGeometry", { args: [0.24, 12, 12] }), _jsx("meshStandardMaterial", { color: "#ffffff", emissive: color, emissiveIntensity: 4, transparent: true, opacity: 1, depthTest: false, depthWrite: false })] }), _jsx("pointLight", { color: color, intensity: 7, distance: 4.5 })] }));
}
function NetworkCamera({ selectedTrain, time, isPlaying, playbackRate, projectedStops, projectedPaths, cameraCommand, selectedStation, cameraFraming, mapFocus, selectedAirTrack, airProjection, spatialLayoutMix = 0, }) {
    const { camera, gl, size } = useThree();
    const lakeAvoidingPaths = useContext(LakeAvoidingPathsContext);
    const desiredPosition = useMemo(() => new THREE.Vector3(0, 37, 26), []);
    const desiredTarget = useMemo(() => new THREE.Vector3(), []);
    const currentTarget = useMemo(() => new THREE.Vector3(), []);
    const mapTarget = useRef(new THREE.Vector3());
    const distanceScale = useRef(1);
    const localTime = useRef(time);
    const directTouch = useRef(false);
    const lastCommand = useRef(0);
    const viewportAspect = size.height > 0 ? size.width / size.height : 1;
    const minimumDistanceScale = minimumMapDistanceScale(cameraFraming, viewportAspect);
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useEffect(() => {
        if (!(camera instanceof THREE.PerspectiveCamera) || size.height <= 0)
            return;
        const fieldOfView = mapCameraFieldOfView(viewportAspect);
        const focalLength = (0.5 * camera.getFilmHeight()) /
            Math.tan(THREE.MathUtils.degToRad(fieldOfView * 0.5));
        camera.setFocalLength(focalLength);
    }, [camera, size.height, viewportAspect]);
    useEffect(() => {
        distanceScale.current = Math.max(minimumDistanceScale, distanceScale.current);
    }, [minimumDistanceScale]);
    useEffect(() => {
        mapTarget.current.copy(mapFocus);
        distanceScale.current = homeMapDistanceScale(cameraFraming);
    }, [cameraFraming, mapFocus]);
    useEffect(() => {
        if (!cameraCommand || cameraCommand.id === lastCommand.current)
            return;
        lastCommand.current = cameraCommand.id;
        if (cameraCommand.action === 'reset') {
            mapTarget.current.copy(mapFocus);
            distanceScale.current = homeMapDistanceScale(cameraFraming);
            return;
        }
        if (cameraCommand.action === 'reveal-station') {
            if (!selectedStation)
                return;
            const centre = stationCentre(selectedStation, projectedStops);
            camera.updateMatrixWorld();
            if (cameraCommand.distanceScale !== undefined ||
                mapSelectionNeedsReveal(centre.clone().project(camera))) {
                mapTarget.current.copy(centre);
            }
            if (cameraCommand.distanceScale !== undefined) {
                distanceScale.current = Math.max(minimumDistanceScale, cameraCommand.distanceScale);
            }
            return;
        }
        if (cameraCommand.action === 'focus-road' ||
            cameraCommand.action === 'focus-location') {
            if (!cameraCommand.focus)
                return;
            const [x, , z] = projectCoordinate(cameraCommand.focus, airProjection);
            mapTarget.current.set(x, 0, z);
            distanceScale.current = Math.max(minimumDistanceScale, cameraCommand.distanceScale ?? 0.58);
            return;
        }
        const multiplier = cameraCommand.action === 'zoom-in' ? 0.78 : 1.28;
        distanceScale.current = applyMapZoom(distanceScale.current, multiplier, minimumDistanceScale);
    }, [
        camera,
        cameraCommand,
        cameraFraming,
        airProjection,
        mapFocus,
        minimumDistanceScale,
        projectedStops,
        selectedStation,
    ]);
    useEffect(() => {
        const element = gl.domElement;
        const pointers = new Map();
        let pinchDistance;
        const onPointerDown = (event) => {
            if (selectedTrain || selectedAirTrack || (event.pointerType === 'mouse' && event.button !== 0))
                return;
            pointers.set(event.pointerId, {
                x: event.clientX,
                y: event.clientY,
                pointerType: event.pointerType,
            });
            if (event.pointerType === 'touch')
                directTouch.current = true;
            element.setPointerCapture(event.pointerId);
        };
        const onPointerMove = (event) => {
            const previous = pointers.get(event.pointerId);
            if (!previous || selectedTrain || selectedAirTrack)
                return;
            pointers.set(event.pointerId, {
                x: event.clientX,
                y: event.clientY,
                pointerType: previous.pointerType,
            });
            if (pointers.size === 1) {
                const panScale = mapPanScale(distanceScale.current, previous.pointerType);
                mapTarget.current.x -= (event.clientX - previous.x) * panScale;
                mapTarget.current.z -= (event.clientY - previous.y) * panScale;
                mapTarget.current.x = THREE.MathUtils.clamp(mapTarget.current.x, -25, 25);
                mapTarget.current.z = THREE.MathUtils.clamp(mapTarget.current.z, -16, 16);
            }
            else if (pointers.size === 2) {
                const [first, second] = [...pointers.values()];
                const nextDistance = Math.hypot(first.x - second.x, first.y - second.y);
                if (pinchDistance && nextDistance > 0) {
                    distanceScale.current = applyMapZoom(distanceScale.current, pinchDistance / nextDistance, minimumDistanceScale);
                }
                pinchDistance = nextDistance;
            }
            event.preventDefault();
        };
        const onPointerUp = (event) => {
            pointers.delete(event.pointerId);
            directTouch.current = [...pointers.values()].some((pointer) => pointer.pointerType === 'touch');
            if (pointers.size < 2)
                pinchDistance = undefined;
        };
        const onWheel = (event) => {
            if (selectedTrain || selectedAirTrack)
                return;
            distanceScale.current = applyMapZoom(distanceScale.current, mapWheelZoomMultiplier(event.deltaY, event.deltaMode), minimumDistanceScale);
            event.preventDefault();
        };
        element.addEventListener('pointerdown', onPointerDown);
        element.addEventListener('pointermove', onPointerMove);
        element.addEventListener('pointerup', onPointerUp);
        element.addEventListener('pointercancel', onPointerUp);
        element.addEventListener('wheel', onWheel, { passive: false });
        return () => {
            element.removeEventListener('pointerdown', onPointerDown);
            element.removeEventListener('pointermove', onPointerMove);
            element.removeEventListener('pointerup', onPointerUp);
            element.removeEventListener('pointercancel', onPointerUp);
            element.removeEventListener('wheel', onWheel);
        };
    }, [gl, minimumDistanceScale, selectedAirTrack, selectedTrain]);
    useFrame((_, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
        }
        const trainPosition = selectedTrain
            ? projectedTrainPosition(selectedTrain, localTime.current, projectedStops, projectedPaths, lakeAvoidingPaths)
            : undefined;
        const airState = selectedAirTrack
            ? positionForAirTrack(selectedAirTrack, localTime.current)
            : undefined;
        const airPosition = airState
            ? projectAirPosition(airState, airProjection)
            : undefined;
        const diagramMix = THREE.MathUtils.clamp(spatialLayoutMix, 0, 1);
        if (trainPosition) {
            desiredTarget.set(trainPosition[0], 0, trainPosition[2]);
            desiredPosition.set(trainPosition[0] + THREE.MathUtils.lerp(4.2, 0.6, diagramMix), THREE.MathUtils.lerp(4.8, 12, diagramMix), trainPosition[2] + THREE.MathUtils.lerp(6.5, 0.8, diagramMix));
        }
        else if (airPosition && airState) {
            const heading = THREE.MathUtils.degToRad(airState.headingDegrees);
            const forwardX = Math.sin(heading);
            const forwardZ = -Math.cos(heading);
            desiredTarget.set(...airPosition);
            desiredPosition.set(airPosition[0] - forwardX * 5.5 + 2.4, airPosition[1] + 4.2, airPosition[2] - forwardZ * 5.5 + 2.4);
        }
        else {
            desiredTarget.copy(mapTarget.current);
            desiredPosition.set(mapTarget.current.x, THREE.MathUtils.lerp(37, 43, diagramMix) * distanceScale.current, mapTarget.current.z +
                THREE.MathUtils.lerp(26, 1.2, diagramMix) * distanceScale.current);
        }
        const damping = 1 -
            Math.exp(-delta *
                mapCameraDampingRate(Boolean(trainPosition || airPosition), directTouch.current));
        camera.position.lerp(desiredPosition, damping);
        currentTarget.lerp(desiredTarget, damping);
        camera.lookAt(currentTarget);
        camera.updateMatrixWorld();
    }, -1);
    return null;
}
function NetworkWorld(props) {
    const projection = useMemo(() => createNetworkProjection(props.referenceSnapshot), [props.referenceSnapshot]);
    const geographicStops = useMemo(() => projectStops(props.snapshot, projection), [projection, props.snapshot]);
    const geographicPaths = useMemo(() => projectPaths(props.snapshot, projection), [projection, props.snapshot]);
    const alternateLayout = useMemo(() => props.spatialLayout
        ? projectSpatialLayout(props.snapshot, props.spatialLayout, geographicStops, geographicPaths)
        : undefined, [geographicPaths, geographicStops, props.snapshot, props.spatialLayout]);
    const projectedLayout = useMemo(() => blendProjectedSpatialLayout(geographicStops, geographicPaths, alternateLayout, props.spatialLayoutMix ?? 0), [
        alternateLayout,
        geographicPaths,
        geographicStops,
        props.spatialLayoutMix,
    ]);
    const projectedStops = projectedLayout.stops;
    const projectedPaths = projectedLayout.paths;
    const contextProjectedStops = useMemo(() => props.contextSnapshot
        ? projectStops(props.contextSnapshot, projection)
        : undefined, [projection, props.contextSnapshot]);
    const contextProjectedPaths = useMemo(() => props.contextSnapshot
        ? projectPaths(props.contextSnapshot, projection)
        : undefined, [projection, props.contextSnapshot]);
    const projectedLakeRings = useMemo(() => props.lakes?.lakes.flatMap((lake) => lake.polygons.flatMap((polygon) => {
        const outerRing = polygon[0];
        return outerRing
            ? [
                outerRing.map((coordinate) => projectCoordinate(coordinate, projection)),
            ]
            : [];
    })) ?? [], [projection, props.lakes]);
    const lakeAvoidingPaths = useMemo(() => {
        if ((props.spatialLayoutMix ?? 0) > 0)
            return EMPTY_LAKE_AVOIDING_PATHS;
        return createLakeAvoidingPathMap(props.snapshot.edges, props.snapshot.edgePaths, projectedStops, projectedLakeRings);
    }, [
        projectedLakeRings,
        projectedStops,
        props.snapshot.edgePaths,
        props.snapshot.edges,
        props.spatialLayoutMix,
    ]);
    const mapFocus = useMemo(() => {
        const { bounds } = props.snapshot;
        const centre = [
            (bounds.minLongitude + bounds.maxLongitude) / 2,
            (bounds.minLatitude + bounds.maxLatitude) / 2,
        ];
        const [x, , z] = projectCoordinate(centre, projection);
        return new THREE.Vector3(x, 0, z);
    }, [projection, props.snapshot]);
    const hasContext = Boolean(props.contextSnapshot && contextProjectedStops);
    const trainTimeIndex = useMemo(() => buildTrainTimeIndex(props.snapshot.trains, props.snapshot.metadata.windowStart, props.snapshot.metadata.windowEnd, VEHICLE_TRAIL_SEGMENTS * VEHICLE_TRAIL_STEP_SECONDS), [props.snapshot]);
    const routeColorMix = props.routeColorMix ?? props.spatialLayoutMix ?? 0;
    const selectedTrainRouteColor = props.selectedTrain
        ? mixedRouteColor(props.selectedTrain.category, props.selectedTrain.route, props.routeColors, routeColorMix)
        : undefined;
    const selectedLineRouteColor = props.selectedRoute
        ? mixedRouteColor(props.selectedRoute.category, props.selectedRoute.name, props.routeColors, routeColorMix)
        : undefined;
    const comparisonTrainIds = new Set(props.comparisonTrains?.map((train) => train.id) ?? []);
    const hasComparison = comparisonTrainIds.size > 0;
    const comparisonColors = props.comparisonTrains?.map((train, index) => props.comparisonColors?.[index] ??
        mixedRouteColor(train.category, train.route, props.routeColors, routeColorMix));
    return (_jsxs(LakeAvoidingPathsContext.Provider, { value: lakeAvoidingPaths, children: [_jsx("fog", { attach: "fog", args: ['#050410', 34, 69] }), _jsx("ambientLight", { intensity: 0.85, color: "#7d87ff" }), _jsx(NationalGround, {}), props.lakes && (_jsx(LakeLayer, { lakes: props.lakes, projection: projection, opacityScale: 1 - (props.spatialLayoutMix ?? 0), subdued: Boolean(props.selectedTrain ||
                    hasComparison ||
                    props.selectedRoute ||
                    props.selectedStation ||
                    props.selectedCategory ||
                    props.airCategorySelected ||
                    props.roadCategorySelected ||
                    props.selectedRoadId) })), projectedLayout.context?.waterPaths && (_jsx(DiagramWaterLayer, { paths: projectedLayout.context.waterPaths, opacity: props.spatialLayoutMix ?? 0 })), props.boundary && (_jsx(CountryBorder, { boundary: props.boundary, projection: projection, opacityScale: 1 - (props.spatialLayoutMix ?? 0), subdued: Boolean(props.selectedTrain ||
                    hasComparison ||
                    props.selectedRoute ||
                    props.selectedStation ||
                    props.selectedCategory ||
                    props.airCategorySelected ||
                    props.roadCategorySelected ||
                    props.selectedRoadId ||
                    hasContext) })), props.referencePaths && (_jsx(ReferencePathLayer, { references: props.referencePaths, projection: projection, subdued: Boolean(props.selectedTrain ||
                    hasComparison ||
                    props.selectedRoute ||
                    props.selectedStation ||
                    props.selectedCategory) })), props.contextSnapshot && contextProjectedStops && contextProjectedPaths && (_jsx(RailGraph, { snapshot: props.contextSnapshot, projectedStops: contextProjectedStops, projectedPaths: contextProjectedPaths, cameraFraming: ATLAS_MAP_FRAMING, subdued: true, lakeAvoidingPaths: EMPTY_LAKE_AVOIDING_PATHS, showTraffic: false })), _jsx(RailGraph, { snapshot: props.snapshot, projectedStops: projectedStops, projectedPaths: projectedPaths, cameraFraming: props.cameraFraming, lakeAvoidingPaths: lakeAvoidingPaths, subdued: Boolean(props.selectedTrain ||
                    hasComparison ||
                    props.selectedRoute ||
                    props.selectedStation ||
                    props.selectedCategory ||
                    props.airCategorySelected ||
                    props.roadCategorySelected ||
                    props.selectedRoadId), routeColors: props.routeColors, routeColorMix: routeColorMix, trafficOverviewEmphasis: props.trafficOverviewEmphasis, lineMapStyle: props.topologicalStyle === 'line-map' }), (props.roadSnapshot || props.roadTopology) && (_jsx(RoadTrafficLayer, { snapshot: props.roadSnapshot, nationalSnapshot: props.nationalRoadSnapshot, topology: props.roadTopology, time: props.time, isPlaying: props.isPlaying, playbackRate: props.playbackRate, projection: projection, selectedRoadId: props.selectedRoadId, subdued: Boolean(props.selectedTrain ||
                    hasComparison ||
                    props.selectedRoute ||
                    props.selectedStation ||
                    props.selectedCategory ||
                    props.airCategorySelected) })), props.airSnapshot && (_jsx(AirTrafficLayer, { snapshot: props.airSnapshot, time: props.time, isPlaying: props.isPlaying, playbackRate: props.playbackRate, projection: projection, airports: props.airports, emphasizeAirports: props.airCategorySelected, selectedTrackId: props.selectedAirTrack?.id, selectedAirport: props.selectedAirport, onSelectTrack: props.onSelectAirTrack, labelMode: props.trainLabelMode, subdued: Boolean(props.selectedTrain ||
                    hasComparison ||
                    props.selectedRoute ||
                    props.selectedStation ||
                    props.selectedCategory ||
                    props.roadCategorySelected) })), props.selectedTrain && (_jsxs(_Fragment, { children: [_jsx(SelectedRoute, { train: props.selectedTrain, projectedStops: projectedStops, projectedPaths: projectedPaths, color: selectedTrainRouteColor }), _jsx(SelectedTrainMarker, { train: props.selectedTrain, time: props.time, projectedStops: projectedStops, projectedPaths: projectedPaths })] })), props.comparisonTrains?.map((train, index) => (_jsxs("group", { children: [_jsx(SelectedRoute, { train: train, projectedStops: projectedStops, projectedPaths: projectedPaths, color: comparisonColors?.[index], comparisonLayer: index === 0 ? 'foundation' : 'foreground' }), _jsx(SelectedTrainMarker, { train: train, time: props.time, projectedStops: projectedStops, projectedPaths: projectedPaths, color: comparisonColors?.[index] })] }, `comparison:${train.id}`))), props.selectedRoute && (_jsx(SelectedLinePaths, { route: props.selectedRoute, snapshot: props.snapshot, projectedStops: projectedStops, projectedPaths: projectedPaths, color: selectedLineRouteColor })), props.selectedStation && !hasComparison && (_jsx(SelectedStationRoutes, { station: props.selectedStation, snapshot: props.snapshot, projectedStops: projectedStops, projectedPaths: projectedPaths, selectedCategory: props.selectedCategory })), _jsx(VehicleTrails, { ...props, projectedStops: projectedStops, projectedPaths: projectedPaths, trainTimeIndex: trainTimeIndex }), _jsx(TrainSwarm, { ...props, projectedStops: projectedStops, projectedPaths: projectedPaths, trainTimeIndex: trainTimeIndex }), _jsx(TrainLabels, { ...props, projectedStops: projectedStops, projectedPaths: projectedPaths, trainTimeIndex: trainTimeIndex }), _jsx(StationLabels, { stations: props.stations, snapshot: props.snapshot, projectedStops: projectedStops, selectedRoute: props.selectedRoute, selectedStation: props.selectedStation, selectedTrain: props.selectedTrain, cameraFraming: props.cameraFraming, layoutTransitioning: props.layoutTransitioning, tierLimit: props.stationLabelTierLimit, settleSeconds: props.stationLabelSettleSeconds, hidden: props.airCategorySelected, lineMapMix: props.topologicalStyle === 'line-map'
                    ? props.spatialLayoutMix
                    : 0 }), _jsx(StationTapTarget, { stations: props.stations, projectedStops: projectedStops, cameraFraming: props.cameraFraming, onSelectStation: props.airCategorySelected ? undefined : props.onSelectStation }), _jsx(NetworkCamera, { selectedTrain: props.selectedTrain, time: props.time, isPlaying: props.isPlaying, playbackRate: props.playbackRate, projectedStops: projectedStops, projectedPaths: projectedPaths, cameraCommand: props.cameraCommand, selectedStation: props.selectedStation, cameraFraming: props.cameraFraming, mapFocus: mapFocus, selectedAirTrack: props.selectedAirTrack, airProjection: projection, spatialLayoutMix: props.spatialLayoutMix })] }));
}
export function NationalNetworkScene(props) {
    return (_jsxs(Canvas, { camera: { position: [0, 37, 26], fov: 44, near: 0.1, far: 120 }, dpr: [1, 1.65], gl: { antialias: true, alpha: false }, children: [_jsx("color", { attach: "background", args: ['#050410'] }), _jsx(NetworkWorld, { ...props })] }));
}
