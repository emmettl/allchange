import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useFrame } from '@react-three/fiber';
import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { roadConditionsAtTime, roadDistanceTravelledKm, visualVehicleCount, } from '@motionstudies/core/domain/road';
import { nationalRoadConditionsAtTime, } from '@motionstudies/core/domain/road-day';
import { createGlowPointTexture } from './glow-point-texture.js';
const LIGHT_COLOR = new THREE.Color('#fff1cf');
const HEAVY_COLOR = new THREE.Color('#ff9d52');
const MAX_LIGHT_PER_DIRECTION = 110;
const MAX_HEAVY_PER_DIRECTION = 32;
const MAX_NATIONAL_LIGHT = 1_500;
const MAX_NATIONAL_HEAVY = 520;
function RoadTopology({ snapshot, projection, subdued, selectedRoadId, }) {
    const pointTexture = useMemo(() => createGlowPointTexture(), []);
    const geometry = useMemo(() => {
        const mainlinePoints = [];
        const connectorPoints = [];
        const selectedMainlinePoints = [];
        const selectedConnectorPoints = [];
        for (const path of snapshot.paths) {
            const target = path.mainline ? mainlinePoints : connectorPoints;
            const selectedTarget = path.mainline
                ? selectedMainlinePoints
                : selectedConnectorPoints;
            for (let index = 1; index < path.points.length; index += 1) {
                const first = projectRoadCoordinate(path.points[index - 1], projection, 0.065);
                const second = projectRoadCoordinate(path.points[index], projection, 0.065);
                target.push(first, second);
                if (path.road === selectedRoadId)
                    selectedTarget.push(first, second);
            }
        }
        const seenStations = new Set();
        const seenSelectedStations = new Set();
        const selectedSitePoints = [];
        const sitePoints = snapshot.sites.flatMap((site) => {
            if ((site.match.confidence !== 'high' &&
                site.match.confidence !== 'continuity' &&
                site.match.confidence !== 'authoritative') ||
                !site.match.projectedCoordinate ||
                seenStations.has(site.stationId)) {
                return [];
            }
            seenStations.add(site.stationId);
            const point = projectRoadCoordinate(site.match.projectedCoordinate, projection, 0.085);
            if (site.match.road === selectedRoadId &&
                !seenSelectedStations.has(site.stationId)) {
                selectedSitePoints.push(point);
                seenSelectedStations.add(site.stationId);
            }
            return [point];
        });
        return {
            mainline: new THREE.BufferGeometry().setFromPoints(mainlinePoints),
            connectors: new THREE.BufferGeometry().setFromPoints(connectorPoints),
            sites: new THREE.BufferGeometry().setFromPoints(sitePoints),
            selectedMainline: new THREE.BufferGeometry().setFromPoints(selectedMainlinePoints),
            selectedConnectors: new THREE.BufferGeometry().setFromPoints(selectedConnectorPoints),
            selectedSites: new THREE.BufferGeometry().setFromPoints(selectedSitePoints),
        };
    }, [projection, selectedRoadId, snapshot.paths, snapshot.sites]);
    useEffect(() => () => {
        geometry.mainline.dispose();
        geometry.connectors.dispose();
        geometry.sites.dispose();
        geometry.selectedMainline.dispose();
        geometry.selectedConnectors.dispose();
        geometry.selectedSites.dispose();
    }, [geometry]);
    useEffect(() => () => pointTexture.dispose(), [pointTexture]);
    return (_jsxs("group", { children: [_jsx("lineSegments", { geometry: geometry.connectors, renderOrder: 3, children: _jsx("lineBasicMaterial", { color: "#bc8058", transparent: true, opacity: selectedRoadId ? 0.003 : subdued ? 0.008 : 0.018, depthWrite: false }) }), _jsx("lineSegments", { geometry: geometry.mainline, renderOrder: 3, children: _jsx("lineBasicMaterial", { color: "#ffb36b", transparent: true, opacity: selectedRoadId ? 0.008 : subdued ? 0.018 : 0.062, blending: THREE.AdditiveBlending, depthWrite: false }) }), _jsx("points", { geometry: geometry.sites, renderOrder: 4, children: _jsx("pointsMaterial", { map: pointTexture, color: "#ffd18d", size: 0.1, sizeAttenuation: true, transparent: true, opacity: selectedRoadId ? 0.05 : subdued ? 0.08 : 0.34, alphaTest: 0.015, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }) }), selectedRoadId && (_jsxs(_Fragment, { children: [_jsx("lineSegments", { geometry: geometry.selectedConnectors, renderOrder: 7, children: _jsx("lineBasicMaterial", { color: "#ff9d52", transparent: true, opacity: 0.22, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false }) }), _jsx("lineSegments", { geometry: geometry.selectedMainline, renderOrder: 8, children: _jsx("lineBasicMaterial", { color: "#fff1cf", transparent: true, opacity: 0.92, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false }) }), _jsx("points", { geometry: geometry.selectedSites, renderOrder: 9, children: _jsx("pointsMaterial", { map: pointTexture, color: "#ffbc70", size: 0.15, sizeAttenuation: true, transparent: true, opacity: 0.86, alphaTest: 0.015, blending: THREE.AdditiveBlending, depthTest: false, depthWrite: false, toneMapped: false }) })] }))] }));
}
function projectRoadCoordinate(coordinate, projection, height = 0.11) {
    return new THREE.Vector3((coordinate[0] - projection.centreLongitude) *
        projection.longitudeScale *
        projection.scale, height, -(coordinate[1] - projection.centreLatitude) * projection.scale);
}
function RoadDirectionFlow({ snapshot, corridor, direction, curve, time, isPlaying, playbackRate, subdued, }) {
    const localTime = useRef(time);
    const lightsRef = useRef(null);
    const heavyRef = useRef(null);
    const transformRef = useRef(new THREE.Object3D());
    const pointRef = useRef(new THREE.Vector3());
    const aheadRef = useRef(new THREE.Vector3());
    const tangentRef = useRef(new THREE.Vector3());
    const vehicleAxisRef = useRef(new THREE.Vector3(0, 1, 0));
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useFrame((_, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
            if (localTime.current > snapshot.metadata.windowEnd) {
                localTime.current = snapshot.metadata.windowStart;
            }
        }
        const conditions = roadConditionsAtTime(direction, localTime.current);
        const transform = transformRef.current;
        const point = pointRef.current;
        const ahead = aheadRef.current;
        const tangent = tangentRef.current;
        const vehicleAxis = vehicleAxisRef.current;
        const lightCount = visualVehicleCount(conditions.lightFlowPerHour, conditions.lightSpeedKmh, corridor.distanceKm, snapshot.metadata.visualSampleRate, MAX_LIGHT_PER_DIRECTION);
        const heavyCount = visualVehicleCount(conditions.heavyFlowPerHour, conditions.heavySpeedKmh, corridor.distanceKm, snapshot.metadata.visualSampleRate * 1.7, MAX_HEAVY_PER_DIRECTION);
        const updateMesh = (mesh, count, vehicle) => {
            if (!mesh)
                return;
            const travelled = roadDistanceTravelledKm(direction, localTime.current, vehicle);
            for (let index = 0; index < count; index += 1) {
                const offset = (index + (vehicle === 'heavy' ? 0.37 : 0.08)) / Math.max(1, count);
                let progress = (offset + travelled / corridor.distanceKm) % 1;
                if (direction.reverse)
                    progress = 1 - progress;
                curve.getPointAt(progress, point);
                const aheadProgress = (progress + (direction.reverse ? -0.001 : 0.001) + 1) % 1;
                curve.getPointAt(aheadProgress, ahead);
                transform.position.copy(point);
                transform.position.x += direction.reverse ? -0.045 : 0.045;
                tangent.copy(ahead).sub(point).normalize();
                transform.quaternion.setFromUnitVectors(vehicleAxis, tangent);
                const pulse = 0.88 + 0.12 * Math.sin(index * 2.31 + localTime.current * 0.045);
                transform.scale.setScalar(pulse);
                transform.updateMatrix();
                mesh.setMatrixAt(index, transform.matrix);
            }
            mesh.count = count;
            mesh.instanceMatrix.needsUpdate = true;
        };
        updateMesh(lightsRef.current, lightCount, 'light');
        updateMesh(heavyRef.current, heavyCount, 'heavy');
    });
    return (_jsxs(_Fragment, { children: [_jsxs("instancedMesh", { ref: lightsRef, args: [undefined, undefined, MAX_LIGHT_PER_DIRECTION], renderOrder: 5, frustumCulled: false, children: [_jsx("capsuleGeometry", { args: [0.027, 0.16, 3, 5] }), _jsx("meshBasicMaterial", { color: LIGHT_COLOR, transparent: true, opacity: subdued ? 0.07 : 0.84, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })] }), _jsxs("instancedMesh", { ref: heavyRef, args: [undefined, undefined, MAX_HEAVY_PER_DIRECTION], renderOrder: 5, frustumCulled: false, children: [_jsx("capsuleGeometry", { args: [0.045, 0.24, 3, 5] }), _jsx("meshBasicMaterial", { color: HEAVY_COLOR, transparent: true, opacity: subdued ? 0.06 : 0.78, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })] })] }));
}
function NationalRoadTrafficFlow({ snapshot, topology, projection, time, isPlaying, playbackRate, selectedRoadId, subdued, }) {
    const localTime = useRef(time);
    const lightsRef = useRef(null);
    const heavyRef = useRef(null);
    const transform = useMemo(() => new THREE.Object3D(), []);
    const point = useMemo(() => new THREE.Vector3(), []);
    const ahead = useMemo(() => new THREE.Vector3(), []);
    const tangent = useMemo(() => new THREE.Vector3(), []);
    const vehicleAxis = useMemo(() => new THREE.Vector3(0, 1, 0), []);
    const conditionCache = useRef(new Map());
    const sections = useMemo(() => {
        const topologyById = new Map(topology.sections.map((section) => [section.id, section]));
        return snapshot.sections.flatMap((section) => {
            if (selectedRoadId && section.road !== selectedRoadId)
                return [];
            const topologySection = topologyById.get(section.id);
            if (!topologySection)
                return [];
            const coordinates = topologySection.path ?? [
                topologySection.fromCoordinate,
                topologySection.toCoordinate,
            ];
            const points = coordinates.map((coordinate) => projectRoadCoordinate(coordinate, projection, 0.12));
            const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal', 0.5);
            return [{ ...section, curve }];
        });
    }, [projection, selectedRoadId, snapshot.sections, topology.sections]);
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useFrame((_, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
            if (localTime.current > snapshot.metadata.windowEnd) {
                localTime.current = snapshot.metadata.windowStart;
            }
        }
        let lightIndex = 0;
        let heavyIndex = 0;
        conditionCache.current.clear();
        const conditionsFor = (siteIndex) => {
            const existing = conditionCache.current.get(siteIndex);
            if (existing)
                return existing;
            const value = nationalRoadConditionsAtTime(snapshot, siteIndex, localTime.current);
            conditionCache.current.set(siteIndex, value);
            return value;
        };
        const update = (mesh, section, count, speedKmh, vehicle) => {
            if (!mesh || !count || !section.distanceKm)
                return;
            for (let index = 0; index < count; index += 1) {
                const maximum = vehicle === 'light' ? MAX_NATIONAL_LIGHT : MAX_NATIONAL_HEAVY;
                if ((vehicle === 'light' ? lightIndex : heavyIndex) >= maximum)
                    return;
                const targetIndex = vehicle === 'light' ? lightIndex++ : heavyIndex++;
                const seed = ((targetIndex * 0.61803398875) % 1 + index / count) % 1;
                const travelled = ((localTime.current - snapshot.metadata.windowStart) * speedKmh) / 3_600;
                const progress = (seed + travelled / section.distanceKm) % 1;
                section.curve.getPointAt(progress, point);
                section.curve.getPointAt(Math.min(1, progress + 0.003), ahead);
                transform.position.copy(point);
                transform.quaternion.setFromUnitVectors(vehicleAxis, tangent.copy(ahead).sub(point).normalize());
                transform.scale.setScalar(0.82 + 0.18 * Math.sin(targetIndex * 1.71 + localTime.current * 0.035));
                transform.updateMatrix();
                mesh.setMatrixAt(targetIndex, transform.matrix);
            }
        };
        for (const section of sections) {
            const from = conditionsFor(section.fromSiteIndex);
            const to = conditionsFor(section.toSiteIndex);
            const lightFlow = (from.lightFlowPerHour + to.lightFlowPerHour) / 2;
            const lightSpeed = (from.lightSpeedKmh + to.lightSpeedKmh) / 2;
            const heavyFlow = (from.heavyFlowPerHour + to.heavyFlowPerHour) / 2;
            const heavySpeed = (from.heavySpeedKmh + to.heavySpeedKmh) / 2;
            update(lightsRef.current, section, Math.min(3, Math.round(lightFlow / (selectedRoadId ? 550 : 1_100))), lightSpeed, 'light');
            update(heavyRef.current, section, Math.min(2, Math.round(heavyFlow / (selectedRoadId ? 180 : 320))), heavySpeed, 'heavy');
        }
        if (lightsRef.current) {
            lightsRef.current.count = lightIndex;
            lightsRef.current.instanceMatrix.needsUpdate = true;
        }
        if (heavyRef.current) {
            heavyRef.current.count = heavyIndex;
            heavyRef.current.instanceMatrix.needsUpdate = true;
        }
    });
    return (_jsxs(_Fragment, { children: [_jsxs("instancedMesh", { ref: lightsRef, args: [undefined, undefined, MAX_NATIONAL_LIGHT], renderOrder: 10, frustumCulled: false, children: [_jsx("capsuleGeometry", { args: [0.022, 0.12, 3, 5] }), _jsx("meshBasicMaterial", { color: LIGHT_COLOR, transparent: true, opacity: subdued ? 0.1 : selectedRoadId ? 0.92 : 0.58, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })] }), _jsxs("instancedMesh", { ref: heavyRef, args: [undefined, undefined, MAX_NATIONAL_HEAVY], renderOrder: 10, frustumCulled: false, children: [_jsx("capsuleGeometry", { args: [0.035, 0.18, 3, 5] }), _jsx("meshBasicMaterial", { color: HEAVY_COLOR, transparent: true, opacity: subdued ? 0.08 : selectedRoadId ? 0.86 : 0.52, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false })] })] }));
}
export function RoadTrafficLayer({ snapshot, topology, time, isPlaying, playbackRate, projection, subdued = false, selectedRoadId, nationalSnapshot, }) {
    const corridors = useMemo(() => (snapshot?.corridors ?? []).map((corridor) => {
        const points = corridor.path.map((coordinate) => projectRoadCoordinate(coordinate, projection));
        const curve = new THREE.CatmullRomCurve3(points, false, 'centripetal', 0.5);
        const roadPoints = curve.getPoints(180);
        const roadSegments = roadPoints.flatMap((point, index) => index ? [roadPoints[index - 1], point] : []);
        const road = new THREE.BufferGeometry().setFromPoints(roadSegments);
        return { corridor, curve, road };
    }), [projection, snapshot?.corridors]);
    useEffect(() => () => corridors.forEach(({ road }) => road.dispose()), [corridors]);
    return (_jsxs("group", { children: [topology && (_jsx(RoadTopology, { snapshot: topology, projection: projection, subdued: subdued, selectedRoadId: selectedRoadId })), nationalSnapshot && topology && (_jsx(NationalRoadTrafficFlow, { snapshot: nationalSnapshot, topology: topology, projection: projection, time: time, isPlaying: isPlaying, playbackRate: playbackRate, selectedRoadId: selectedRoadId, subdued: subdued })), !nationalSnapshot && snapshot && corridors.map(({ corridor, curve, road }) => {
                const corridorRoad = corridor.road.replace(/^A/, 'N');
                const corridorSubdued = subdued || Boolean(selectedRoadId && selectedRoadId !== corridorRoad);
                return (_jsxs("group", { children: [_jsx("lineSegments", { geometry: road, renderOrder: 4, children: _jsx("lineBasicMaterial", { color: "#c78a60", transparent: true, opacity: corridorSubdued ? 0.012 : 0.15, depthWrite: false }) }), corridor.directions.map((direction) => (_jsx(RoadDirectionFlow, { snapshot: snapshot, corridor: corridor, direction: direction, curve: curve, time: time, isPlaying: isPlaying, playbackRate: playbackRate, subdued: corridorSubdued }, direction.id)))] }, corridor.id));
            })] }));
}
