import type { TrainLabelMode } from './train-labels.ts';
export declare const MAX_AIR_LABELS = 20;
export declare function airLabelBudget(cameraHeight: number, mode: TrainLabelMode, selected: boolean): number;
export declare function airLabelScreenHeight(viewportWidth: number, selected: boolean, cameraHeight: number): number;
export declare function airLabelScreenWidth(label: string, screenHeight: number): number;
export interface AirLabelCandidatePriority {
    readonly id: string;
    readonly callsign: string;
    readonly retained: boolean;
}
export declare function compareAirLabelCandidates(first: AirLabelCandidatePriority, second: AirLabelCandidatePriority): number;
