import { type ProjectedNetworkPath, type ProjectedPathPoint } from './network-paths.ts';
export type LakeAvoidingPathMap = ReadonlyMap<string, ProjectedNetworkPath>;
export declare function lakeAvoidingPath(first: ProjectedPathPoint, second: ProjectedPathPoint, lakeRings: readonly (readonly ProjectedPathPoint[])[]): readonly ProjectedPathPoint[] | undefined;
export declare function createLakeAvoidingPathMap(edges: readonly (readonly [number, number])[], edgePaths: readonly (number | null)[] | undefined, projectedStops: readonly ProjectedPathPoint[], lakeRings: readonly (readonly ProjectedPathPoint[])[]): LakeAvoidingPathMap;
export declare function lakeAvoidingPathForStops(paths: LakeAvoidingPathMap, fromIndex: number, toIndex: number): ProjectedNetworkPath | undefined;
