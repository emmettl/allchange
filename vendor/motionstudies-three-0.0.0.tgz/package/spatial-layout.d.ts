import type { NetworkSnapshot } from '@motionstudies/core/domain/network';
import type { SpatialLayoutSnapshot } from '@motionstudies/core/domain/spatial-layout';
import { type ProjectedNetworkPath, type ProjectedPathPoint } from './network-paths.ts';
export interface ProjectedSpatialLayout {
    readonly stops: readonly ProjectedPathPoint[];
    readonly paths: readonly ProjectedNetworkPath[];
    readonly context?: {
        readonly waterPaths: readonly ProjectedNetworkPath[];
    };
}
export declare function projectSpatialLayout(network: NetworkSnapshot, layout: SpatialLayoutSnapshot, geographicStops: readonly ProjectedPathPoint[], geographicPaths: readonly ProjectedNetworkPath[], targetWidth?: number): ProjectedSpatialLayout;
export declare function blendProjectedSpatialLayout(geographicStops: readonly ProjectedPathPoint[], geographicPaths: readonly ProjectedNetworkPath[], alternate: ProjectedSpatialLayout | undefined, mix: number): ProjectedSpatialLayout;
