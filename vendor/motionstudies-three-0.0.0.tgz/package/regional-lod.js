import { homeMapDistanceScale, } from './map-camera.js';
export function regionalCameraHeight(cameraHeight, framing) {
    return framing.localDetailHierarchy
        ? cameraHeight / homeMapDistanceScale(framing)
        : cameraHeight;
}
export function vehicleIsVisibleAtZoom(category, cameraHeight, framing, focused = false) {
    if (focused || !framing.localDetailHierarchy)
        return true;
    const relativeHeight = regionalCameraHeight(cameraHeight, framing);
    if (category === 'bus')
        return relativeHeight < 22;
    if (category === 'tram')
        return relativeHeight < 30;
    return true;
}
export function localNetworkDetailAtZoom(cameraHeight, framing) {
    if (!framing.localDetailHierarchy)
        return 1;
    const relativeHeight = regionalCameraHeight(cameraHeight, framing);
    return Math.min(1, Math.max(0, (32 - relativeHeight) / 12));
}
