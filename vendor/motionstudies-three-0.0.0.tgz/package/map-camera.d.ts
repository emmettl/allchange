export declare const MIN_MAP_DISTANCE_SCALE = 0.02;
export declare const MAX_MAP_DISTANCE_SCALE = 1.18;
export interface MapCameraFraming {
    readonly homeDistanceScale: number;
    readonly minimumDistanceScale: number;
    readonly portraitMinimumDistanceScale?: number;
    readonly localDetailHierarchy?: boolean;
    readonly stationLabelHeightScale?: number;
    readonly stationLabelPrefix?: string;
    readonly stationLabelPrimaryName?: string;
}
export declare const ATLAS_MAP_FRAMING: MapCameraFraming;
/**
 * Keeps roughly the same horizontal map coverage when the canvas becomes
 * portrait-shaped. A fixed vertical FOV makes a national map look accidentally
 * magnified on phones because the horizontal FOV collapses with the aspect ratio.
 */
export declare function mapCameraFieldOfView(viewportAspect: number): number;
export declare function homeMapDistanceScale(framing: MapCameraFraming): number;
export declare function minimumMapDistanceScale(framing: MapCameraFraming, viewportAspect: number): number;
export declare function mapPanScale(distanceScale: number, pointerType: string): number;
export declare function mapCameraDampingRate(followingTrain: boolean, directTouch: boolean): number;
interface ProjectedMapPoint {
    readonly x: number;
    readonly y: number;
    readonly z: number;
}
export declare const STATION_SELECTION_PULSE_COUNT = 3;
interface StationSelectionPulseFrame {
    readonly radiusPixels: number;
    readonly opacity: number;
}
/** A staggered, steadily expanding signal with a soft exponential tail. */
export declare function stationSelectionPulseFrame(elapsedSeconds: number, ringIndex: number): StationSelectionPulseFrame;
/**
 * Treats a selected place close to the edge as out of view as well. The small
 * inset leaves room for its marker and label instead of merely keeping the
 * station's centre one pixel inside the canvas.
 */
export declare function mapSelectionNeedsReveal(point: ProjectedMapPoint): boolean;
export declare function mapWheelZoomMultiplier(deltaY: number, deltaMode?: number): number;
/**
 * Keeps zoom direct through the useful range, then eases asymptotically toward the
 * limits. Repeated wheel or pinch input can approach an edge but never push the map
 * through the scene fog.
 */
export declare function applyMapZoom(current: number, multiplier: number, minimumScale?: number): number;
export {};
