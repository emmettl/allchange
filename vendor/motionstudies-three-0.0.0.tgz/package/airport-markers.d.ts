import type { StudyAirport } from '@motionstudies/core/domain/airport';
import type { TrainLabelMode } from './train-labels.ts';
export declare function airportsForMap(airports: readonly StudyAirport[], emphasised: boolean, selectedAirport?: StudyAirport): readonly StudyAirport[];
export declare function airportLabelsAreVisible(labelMode: TrainLabelMode): boolean;
