import { type RoadTopologySnapshot, type RoadTrafficSnapshot } from '@motionstudies/core/domain/road';
import { type NationalRoadStudySnapshot } from '@motionstudies/core/domain/road-day';
import type { NetworkProjection } from './NationalNetworkScene.tsx';
export declare function RoadTrafficLayer({ snapshot, topology, time, isPlaying, playbackRate, projection, subdued, selectedRoadId, nationalSnapshot, }: {
    readonly snapshot?: RoadTrafficSnapshot;
    readonly topology?: RoadTopologySnapshot;
    readonly time: number;
    readonly isPlaying: boolean;
    readonly playbackRate: number;
    readonly projection: NetworkProjection;
    readonly subdued?: boolean;
    readonly selectedRoadId?: string;
    readonly nationalSnapshot?: NationalRoadStudySnapshot;
}): import("react").JSX.Element;
