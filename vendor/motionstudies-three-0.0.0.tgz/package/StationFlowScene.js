import { Fragment as _Fragment, jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Canvas, useFrame } from '@react-three/fiber';
import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { platformTrackForCall, platformsForCalls, stationMotionForCall, UNASSIGNED_PLATFORM, } from '@motionstudies/core/domain/hub';
import { SERVICE_COLORS } from '@motionstudies/core/theme';
import { createGlowPointTexture } from './glow-point-texture.js';
const flowHorizon = 6 * 60;
const trackLength = 43;
function rowPosition(index, count) {
    const spacing = Math.min(1.18, 19 / Math.max(1, count - 1));
    return (index - (count - 1) / 2) * spacing;
}
function approachSide(hubStop, neighbourStop, fallback) {
    if (!neighbourStop)
        return fallback % 2 === 0 ? -1 : 1;
    const longitudeScale = Math.cos((hubStop[1] * Math.PI) / 180);
    const eastWest = (neighbourStop[0] - hubStop[0]) * longitudeScale;
    const northSouth = neighbourStop[1] - hubStop[1];
    return eastWest + northSouth * 0.38 < 0 ? -1 : 1;
}
function createPlatformTexture(platform, platformPrefix) {
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 96;
    const context = canvas.getContext('2d');
    if (context) {
        context.clearRect(0, 0, canvas.width, canvas.height);
        context.font = '600 38px "DM Mono", monospace';
        context.textAlign = 'center';
        context.textBaseline = 'middle';
        context.shadowColor = '#8dfaff';
        context.shadowBlur = 18;
        context.fillStyle = '#dffeff';
        context.fillText(platform === UNASSIGNED_PLATFORM
            ? `${platformPrefix} ?`
            : `${platformPrefix} ${platform}`, 128, 48);
    }
    const texture = new THREE.CanvasTexture(canvas);
    texture.colorSpace = THREE.SRGBColorSpace;
    texture.minFilter = THREE.LinearFilter;
    return texture;
}
function PlatformPlan({ platforms, platformPrefix, }) {
    const labels = useMemo(() => platforms.map((platform) => createPlatformTexture(platform, platformPrefix)), [platformPrefix, platforms]);
    useEffect(() => () => {
        labels.forEach((label) => label.dispose());
    }, [labels]);
    const depth = Math.max(5, Math.abs(rowPosition(platforms.length - 1, platforms.length)) * 2 + 3);
    return (_jsxs("group", { children: [_jsxs("mesh", { rotation: [-Math.PI / 2, 0, 0], position: [0, -0.08, 0], children: [_jsx("planeGeometry", { args: [58, depth + 8, 48, Math.max(12, platforms.length * 2)] }), _jsx("meshBasicMaterial", { color: "#202448", wireframe: true, transparent: true, opacity: 0.075 })] }), platforms.map((platform, index) => {
                const z = rowPosition(index, platforms.length);
                const assigned = platform !== UNASSIGNED_PLATFORM;
                return (_jsxs("group", { position: [0, 0, z], children: [_jsxs("mesh", { position: [0, 0.015, -0.2], children: [_jsx("boxGeometry", { args: [trackLength, 0.025, 0.034] }), _jsx("meshBasicMaterial", { color: assigned ? '#5f78b8' : '#4e526c', transparent: true, opacity: 0.55 })] }), _jsxs("mesh", { position: [0, 0.015, 0.2], children: [_jsx("boxGeometry", { args: [trackLength, 0.025, 0.034] }), _jsx("meshBasicMaterial", { color: assigned ? '#5f78b8' : '#4e526c', transparent: true, opacity: 0.55 })] }), _jsxs("mesh", { position: [0, -0.015, 0], children: [_jsx("boxGeometry", { args: [trackLength - 4, 0.025, 0.31] }), _jsx("meshBasicMaterial", { color: assigned ? '#34375d' : '#272938', transparent: true, opacity: 0.34 })] }), _jsx("sprite", { position: [-23.2, 0.58, 0], scale: [3.2, 1.2, 1], children: _jsx("spriteMaterial", { map: labels[index], transparent: true, depthTest: false, opacity: assigned ? 0.9 : 0.46 }) })] }, platform));
            }), _jsxs("mesh", { position: [0, 0.13, 0], children: [_jsx("boxGeometry", { args: [0.72, 0.13, depth + 1.5] }), _jsx("meshStandardMaterial", { color: "#382b63", emissive: "#ff5edb", emissiveIntensity: 1.8, transparent: true, opacity: 0.46 })] }), _jsx("pointLight", { color: "#ff5edb", intensity: 4.5, distance: 11, position: [0, 2, 0] })] }));
}
function StationTraffic({ calls, platforms, isPlaying, time, onTime, timeline, playbackRate, selectedCategory, }) {
    const points = useRef(null);
    const glow = useRef(null);
    const localTime = useRef(time);
    const lastReport = useRef(0);
    const pointTexture = useMemo(() => createGlowPointTexture(), []);
    const platformRows = useMemo(() => new Map(platforms.map((platform, index) => [
        platform,
        rowPosition(index, platforms.length),
    ])), [platforms]);
    const palette = useMemo(() => Object.fromEntries(Object.entries(SERVICE_COLORS).map(([category, color]) => [
        category,
        new THREE.Color(color),
    ])), []);
    const geometry = useMemo(() => {
        const next = new THREE.BufferGeometry();
        next.setAttribute('position', new THREE.BufferAttribute(new Float32Array(calls.length * 3), 3));
        next.setAttribute('color', new THREE.BufferAttribute(new Float32Array(calls.length * 3), 3));
        next.setDrawRange(0, 0);
        return next;
    }, [calls.length]);
    useEffect(() => {
        localTime.current = time;
    }, [time]);
    useEffect(() => () => geometry.dispose(), [geometry]);
    useEffect(() => () => pointTexture.dispose(), [pointTexture]);
    useFrame((state, delta) => {
        if (isPlaying) {
            localTime.current += delta * playbackRate;
            if (localTime.current > timeline.windowEnd) {
                localTime.current = timeline.windowStart;
            }
        }
        const positions = geometry.getAttribute('position');
        const colors = geometry.getAttribute('color');
        const positionArray = positions.array;
        const colorArray = colors.array;
        let active = 0;
        calls.forEach((call, index) => {
            const motion = stationMotionForCall(call, localTime.current, flowHorizon, timeline.windowEnd - timeline.windowStart);
            if (!motion)
                return;
            const previousSide = approachSide(call.hubStop, call.previousStop, index);
            const nextSide = approachSide(call.hubStop, call.nextStop, index + 1);
            const x = motion.phase === 'approaching'
                ? previousSide * (1 - motion.progress) * 20
                : motion.phase === 'departing'
                    ? nextSide * motion.progress * 20
                    : Math.sin(index * 2.7) * 0.19;
            const z = platformRows.get(platformTrackForCall(call)) ?? 0;
            const offset = active * 3;
            positionArray[offset] = x;
            positionArray[offset + 1] = motion.phase === 'dwelling' ? 0.38 : 0.24;
            positionArray[offset + 2] = z;
            const color = palette[call.train.category] ?? palette.other;
            const intensity = selectedCategory && selectedCategory !== call.train.category ? 0.025 : 1;
            colorArray[offset] = color.r * intensity;
            colorArray[offset + 1] = color.g * intensity;
            colorArray[offset + 2] = color.b * intensity;
            active += 1;
        });
        positions.needsUpdate = true;
        colors.needsUpdate = true;
        geometry.setDrawRange(0, active);
        if (points.current)
            points.current.frustumCulled = false;
        if (glow.current)
            glow.current.frustumCulled = false;
        // A paused scene follows the consumer's clock.
        if (isPlaying && state.clock.elapsedTime - lastReport.current > 0.1) {
            lastReport.current = state.clock.elapsedTime;
            onTime(localTime.current);
        }
    });
    return (_jsxs(_Fragment, { children: [_jsx("points", { ref: glow, geometry: geometry, children: _jsx("pointsMaterial", { map: pointTexture, vertexColors: true, size: 1.32, transparent: true, opacity: 0.19, depthWrite: false, blending: THREE.AdditiveBlending }) }), _jsx("points", { ref: points, geometry: geometry, children: _jsx("pointsMaterial", { map: pointTexture, vertexColors: true, size: 0.3, transparent: true, opacity: 1, depthWrite: false, blending: THREE.AdditiveBlending }) })] }));
}
function StationWorld(props) {
    return (_jsxs(_Fragment, { children: [_jsx("fog", { attach: "fog", args: ['#050410', 25, 69] }), _jsx("ambientLight", { intensity: 0.72, color: "#7879d8" }), _jsx(PlatformPlan, { platforms: props.platforms, platformPrefix: props.platformPrefix }), _jsx(StationTraffic, { ...props, platforms: props.platforms }), _jsx("object3D", { name: props.hub.id })] }));
}
export function StationFlowScene(props) {
    const platforms = useMemo(() => platformsForCalls(props.calls), [props.calls]);
    const cameraHeight = Math.max(25, platforms.length * 1.15);
    return (_jsxs(Canvas, { camera: { position: [0, cameraHeight, 29], fov: 43, near: 0.1, far: 90 }, dpr: [1, 1.65], gl: { antialias: true, alpha: false }, children: [_jsx("color", { attach: "background", args: ['#050410'] }), _jsx(StationWorld, { ...props, platforms: platforms })] }));
}
