import * as THREE from 'three';
export declare function createGlowPointTexture(): THREE.CanvasTexture;
