export function airportsForMap(airports, emphasised, selectedAirport) {
    if (!emphasised)
        return selectedAirport ? [selectedAirport] : [];
    if (!selectedAirport || airports.some(({ id }) => id === selectedAirport.id)) {
        return airports;
    }
    return [...airports, selectedAirport];
}
export function airportLabelsAreVisible(labelMode) {
    return labelMode !== 'off';
}
